
param($Timer) # Input bindings are passed in via param block.
$currentUTCtime = (Get-Date).ToUniversalTime()
Write-Host "================================================="
Write-Host "Starting the function! Time:$($currentUTCtime)"
#region variables
$debug = $false
if ($env:DEBUG -eq 1) { $debug = $true }
$tenant_name = $env:AAD_TENANT_NAME # e.g "ecsdevelop.onmicrosoft.com"
$tenant_id = $env:AAD_TENANT_ID # e.g "dd0cfd15-4558-4b12-8bad-ea26984fc417"
$sub_id = $env:SUB_ID  # e.g "c7b91736-ddd0-4c81-b0c3-da28d3264520"
$rg_hub = $env:HUB_RG  # e.g "ecp-itg-rng1-hub"
$rg = $env:SERVICE_RG  # e.g "ecp-itg-rng1-hub-processing"
$uami_client_id = $env:USER_ASSIGNED_IDENTITY_CLIENT_ID
$record_type = "A"
$records = New-Object System.Collections.ArrayList
$kv_resource_name = $env:INFOBLOX_KEYVAULT_NAME
$infoblox_url = $env:INFOBLOX_URL # e.g https://int-dns.dmz.ige or https://165.12.252.53 
$infoblox_wapi_ver = $env:INFOBLOX_WAPI_VER # e.g "v2.11"
$infoblox_user = $env:INFOBLOX_USER
$infoblox_attribute_EA_AZURE_DevOps = $env:DEPARTMENT_ACRONYM
$infoblox_ignore_dns_zones_string = $env:INFOBLOX_IGNORE_DNS_ZONES
$infoblox_set_desired_state = $true # This is for efficiency

# if this is false, then it will force add all HUB Azure A-Records to be written in infoblox even if the record already exists. Dont worry infoblox wount mind resending all.
if ($env:INFOBLOX_SET_DESIRED_STATE -eq 0) {
    $infoblox_set_desired_state = $false
}
If ($infoblox_ignore_dns_zones_string) {
    try {
        $infoblox_ignore_dns_zones = $infoblox_ignore_dns_zones_string.split(',')

        if ($infoblox_ignore_dns_zones) {
            Write-Host "`t Azure DNS Ignore Count:[$($infoblox_ignore_dns_zones.Count)] Ignore DNS Names:[$($infoblox_ignore_dns_zones)]"
        }
        else {
            Write-Host "`t Azure DNS Ignore List has NO RECORDS!"
        }
    }
    catch {
        Write-Host "`t Azure DNS Ignore LIST NOT FOUND"
    }
}

#endregion variables

#region powershell_functions
#----------------------------------------------------------------------------------------------------------------------------------
# Start TODO: These Functions should not be here. Need to add them in a module. Then module loaded in this function \module folder
# TODO: load these as module later in this function
#-----------------------------------------------------------------------------------------------------------------------------------

# Return all the flatened A-Records from the Azure PrivateDNS
function Get-AzurePrivateDNSRescords($resourceGroup, $recordType = "A") {
    
    $recordsToReturn = New-Object System.Collections.ArrayList
    $zones = Get-AzPrivateDnsZone -ResourceGroupName $resourceGroup
    ForEach ($zone in $zones) {
        if ($infoblox_ignore_dns_zones -contains $zone.Name) {
            if ($debug) { Write-Host "`t Ignoring this AzurePrivateDNSZone:[$($zone.Name)]" } # as it is in the ignore list variable 'INFOBLOX_IGNORE_DNS_ZONES'. You can choose to add or delete the Application Variable list.
            continue
        }
        $recordset = Get-AzPrivateDnsRecordSet -Zone $zone | where { $_.RecordType -eq $recordType }
        Foreach ($record in $recordset) {
            foreach ($ip in $record.Records) {
                # it is possible there are 2x IP in one record. so flatten it!
                $info = [PSCustomObject]@{
                    name              = $record.Name
                    resourceId        = $record.Id
                    zoneName          = $record.ZoneName
                    resourceGroupName = $record.ResourceGroupName
                    ttl               = $record.ttl
                    recordType        = $record.RecordType
                    metadata          = $record.MetaData
                    ipv4Address       = $ip.Ipv4Address
                    fqdn              = "$($record.Name).$($record.ZoneName)"
                }
                $null = $recordsToReturn.Add($info)
            }
        }
    }
    
    Write-Host "AzurePrivateDNSZones Found:[$($zones.Count)] in Resource Group:[$resourceGroup] with Total A-Record Count:[$($recordsToReturn.Count)]."
    return $recordsToReturn
}

function Get-RecordsInfoblox($searchItem, $useWildCard = $false, $ignoreFilterAndGetAll = $false, $InfobloxAttr_EA_AZURE_Node, $infobloxUrl = "https://int-dns.dmz.ige", $infobloxWapiVerisonNumber = "v2.11") {
    # GET
    # $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("D:\home\data\edt-privatednsrecords\SharedServicesMerged.cer")
    $result = ""
    if ($ignoreFilterAndGetAll) {
        $filter = ""
    }
    elseif ($useWildCard) {
        # wildcard with case ignored
        $filter = "name~:=$($searchItem)&*EA_Azure_Node:=$($InfobloxAttr_EA_AZURE_Node)&"
    }
    else {
        #exact match with case ignored
        $filter = "name:=$($searchItem)&*EA_Azure_Node:=$($InfobloxAttr_EA_AZURE_Node)&"
    }

    # if using filter than make sure there are values
    if ($filter) {
        if (!$InfobloxAttr_EA_AZURE_Node) {
            $err = "You need to provide the EDT NODE RG where the PrivateDNS exists. Cannot Get"
            throw $err
            Write-Host $err
            exit
        }
    }    
    $url = "$($infobloxUrl)/wapi/$($infobloxWapiVerisonNumber)/record:a?$($filter)_max_results=9999&_return_fields=name,ipv4addr&_return_as_object=1"  ##$url = "$($infobloxUrl)/wapi/$($infobloxWapiVerisonNumber)/record:a?$($filter)_max_results=9999&_return_fields=name,ipv4addr&_return_as_object=1" 
    try {
        if ($debug) { Write-Host "Going to Get-RecordsInfoblox URL:[$($url)]." }
        $get = Invoke-RestMethod -Uri $url -Method GET -Credential $creds -SkipCertificateCheck #-Certificate $cert 
        $result = $get.result | Sort-Object name | Select-Object name, ipv4addr, _ref
        if ($debug) { Write-Host "`t Got IP:[$($result.ipv4addr)] Names:[$($result.name)]." }
    }
    catch {
        $err = "Unable to Get-RecordsInfoblox = [$url] Error:[$_]"
        Write-Host $err -ForegroundColor "red"
        $result = ""
    }
    return $result
}

function Set-RecordInfoblox($record, $force = $true, $InfobloxAttr_EA_AZURE_DevOps, $InfobloxAttr_EA_AZURE_User, $InfobloxAttr_EA_AZURE_Node, $AADName, $infobloxUrl = "https://int-dns.dmz.ige", $infobloxWapiVerisonNumber = "v2.11") {
    $fqdn = $record.fqdn
    $ip = $record.Ipv4Address
    $resourceId = $record.resourceId

    # Set Default vaules
    if ( !($InfobloxAttr_EA_AZURE_DevOps) -or ($InfobloxAttr_EA_AZURE_DevOps -notin ('TSD', 'DSD', 'FWO')) ) {
        $InfobloxAttr_EA_AZURE_DevOps = 'TSD' # before you add more depatments , make sure gateway team has added this value in Extensible attributes in infoblox appliance
        Write-Host  "Could not find value for the Department , defaulting to value:[$InfobloxAttr_EA_AZURE_DevOps]"
    }
    
    # Should we do a Get check?
    if (!$force) {
        #dont check if force is selected will save extra api call too
        $status = Get-RecordsInfoblox -searchItem $fqdn -useWildCard $false -InfobloxAttr_EA_AZURE_Node $InfobloxAttr_EA_AZURE_Node -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver
        if ($status) {
            Write-Host "fqdn:[$fqdn] Already exists for Node RG:[$InfobloxAttr_EA_AZURE_Node]! Nothing Done.. "
            exit
        }
    }

    Write-Host "InfoBlox User:[$InfobloxAttr_EA_AZURE_User] Creating IP:[$ip] FQDN:[$fqdn] for Node RG:[$InfobloxAttr_EA_AZURE_Node] ...." -BackgroundColor DarkCyan
    $body = @{
        name     = $fqdn
        ipv4addr = $ip
        view     = "Internal"
        extattrs = @{ "EA_Azure_DevOps" = @{value = $InfobloxAttr_EA_AZURE_DevOps }; "EA_Azure_User" = @{value = $InfobloxAttr_EA_AZURE_User }; "EA_Azure_Node" = @{value = $InfobloxAttr_EA_AZURE_Node } }
        comment  = "The AAD:[$AADName]. DNS Resource ID:[$resourceId]"
            
    }
    $bodyJson = $body | ConvertTo-Json
    #Write-Host $bodyJson
    $url = "$($infobloxUrl)/wapi/$($infobloxWapiVerisonNumber)/record:a?_return_as_object=1"
    #Write-Host "SET url:[$url]"
    try {
        $create = Invoke-RestMethod -Uri $url -Method POST -Credential $creds -ContentType "application/json" -Body $bodyJson -SkipCertificateCheck
        Write-Host "`t Created _ref:[$($create.result)]" -ForegroundColor Green
    }
    catch {
        $err = "`t ERROR ! Creating IP:[$ip] FQDN:[$fqdn] URL:[$url] ERROR:[$_]"
        Write-Host $err -ForegroundColor "red" 
    }
}

function Remove-RecordInfoblox($record, $useWildCard = $false, $InfobloxAttr_EA_AZURE_User, $InfobloxAttr_EA_AZURE_Node, $infobloxUrl = "https://int-dns.dmz.ige", $infobloxWapiVerisonNumber = "v2.11") {
    $fqdn = $record.name
    $ip = $record.ipv4addr

    Write-Host "IP:[$ip] FQDN:[$fqdn] checking if exists...." -BackgroundColor DarkCyan 
    $ref = Get-RecordsInfoblox -searchItem $fqdn -useWildCard $useWildCard -InfobloxAttr_EA_AZURE_Node $InfobloxAttr_EA_AZURE_Node -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver

    if (!$ref) {
        Write-Host "IP:[$ip] FQDN:[$fqdn] doesnt Exist! NOTHING Done!" -BackgroundColor DarkYellow
        return
    }

    if ($debug) { Write-Host "Infoblox Return [$returnName - $returnIp]" }
    try {
        $returnName = $ref.name
        $returnIp = $ref.ipv4addr
        $returnRef = $ref._ref
        if (($returnName -eq $fqdn) -and ( $returnIp -eq $ip )) {
            $url = "$($infobloxUrl)/wapi/$($infobloxWapiVerisonNumber)/$($returnRef)?_return_as_object=1" # $ref = e.g "record:a/ZG5zLmJpbmRfYSQuMS5uZXQuYXp1cmUudmF1bHQucHJpdmF0ZWxpbmsscHV0eW91cnJlc291cmNlbmFtZWhlcmUsMTAuODMuNS4xMzY:putyourresourcenamehere.privatelink.vault.azure.net/Internal"
            if ($debug) { Write-Host "InfoBlox User:[$InfobloxAttr_EA_AZURE_User] IP:[$ip] FQDN:[$fqdn] Exists. Preparing to Delete ref:[$($returnRef)]" -ForegroundColor DarkCyan }
            $delete = Invoke-RestMethod -Uri $url -Method DELETE -Credential $creds -SkipCertificateCheck 
            Write-Host "InfoBlox User:[$InfobloxAttr_EA_AZURE_User] has Deleted IP:[$ip] FQDN:[$fqdn] [$delete]" -ForegroundColor DarkCyan
        }
    }
    catch {
        $err = "`t ERROR ! Deleting IP:[$ip] FQDN:[$fqdn] [$_]" 
        Write-Host $err -ForegroundColor "red" 
    }
}

# --------------------------------------------------------------------------------------------------------------------------------
# Finished :TODO . Powershell Functions loaded in memory. Now run the actual code.
# --------------------------------------------------------------------------------------------------------------------------------
#endregion powershell_functions

#region connect_azure
try {
    Write-Host "Going to connect with UAMI:[$uami_client_id] Tenant:[$tenant_name - $tenant_id] Sub_id:[$sub_id] HUB:[$rg_hub] ABOVENODE:[$rg]"
    Connect-AzAccount -Identity -AccountId $uami_client_id -TenantId $tenant_id -SubscriptionId $sub_id # Run on the virtual machine   
    Write-Host "Going to Get Keyvault:[$($kv_resource_name)] with UAMI:[$uami_client_id]"
    $kv_obj = Get-AzResource -Name $kv_resource_name -ResourceGroupName $rg
    $kv_secret_name = $infoblox_user #"Azure-$($tenant_name.split('.')[0])"    
}
catch {
    $err = "ERROR CONNECTING to Azure... Nothing done! Exiting... ERROR:$[$_]"
    Write-Host $err -ForegroundColor Red
    if ($debug) { Write-Host $err }
    $creds = $null
    throw $err
    exit
}

#endregion connect_azure

#region last_run_a_records
try {
    $localDir = "D:\home\data\edt-privatednsrecords"
    $localFilePath = "$($localDir)\arecords.json"
    if (Test-Path -Path $localFilePath -PathType Leaf) {
        # Read from local file stored in function app
        $lastRunRecords = Get-Content $localFilePath | Out-String | ConvertFrom-Json
        Write-Host "Last run there was [$($lastRunRecords.count)] Records in Azure."
    }
}
catch {
    Write-Host "No Last Run Found"
    $lastRunRecords = ""
}
#endregion last_run_a_records

#region get_a_records

$records = Get-AzurePrivateDNSRescords -resourceGroup $rg_hub -recordType $record_type
if (!$records) {
    $err = "Error no Private DNS Records Found in Azure ResourceGroup:[$rg_hub] Subid:[$sub_id]. No need to run this function!"
    if ($debug) { Write-Host $err }
    throw $err
    exit
}

#endregion get_a_records

#region set_infoblox
if ($infoblox_set_desired_state) {
    Write-Host "------------------------"
    Write-Host "DESIRED STATE ACTIVATED"
    # --------------------------------------------------------------------
    # For efficiency :
    #     1.first check if there are any changes in Azure.  
    #     2.its better to get and set records per zone in infoblox. API has max limit 9999 records in one hit.    
    # --------------------------------------------------------------------
    $recordsCount = $($records.Count)
    $changesFound = $true
    try {
        if ($lastRunRecords) {
            # Read from local file stored in function app
            $diffDepricated = $lastRunRecords | Where-Object { ($records.fqdn -NotContains $_.fqdn) } # left Join
            $diffDepricatedCount = ($diffDepricated | Measure-Object).Count
            $diffNew = $records | Where-Object { ($lastRunRecords.fqdn -NotContains $_.fqdn) } # left Join
            $diffNewCount = ($diffNew | Measure-Object).Count
            if (($diffDepricatedCount -gt 0) -or ($diffNewCount -gt 0)) {
                Write-Host "Azure has Changes detected! it has New:[$diffNewCount] and Depricated:[$diffDepricatedCount]. Need to send it to infoblox"
            }
            else {
                # Exit function if no changes in Azure
                $currentUTCtime = (Get-Date).ToUniversalTime()
                $changesFound = $false
            }
        }
        # Refresh Local Record File
        If (!(test-path $localDir)) {
            New-Item -ItemType Directory -Force -Path $localDir
            $null = New-Item -ItemType File -Path $localFilePath -Force -ErrorAction Stop
            Write-Host  "Local File [$($localDir)] created!"
        }
        $records | ConvertTo-Json -depth 100 | Out-File $localFilePath
        Write-Host  "Writing Azure DNS A-Records Count:[$recordsCount] to local path:[$localFilePath]"    
        
        if (!$changesFound) {
            Write-Host "NO CHANGES DETECTED IN AZURE! Nothing done!\n You have 2 options. `n`t 1.You can remove/register a new DNS record so the changes are sent to infoblox . `n`t 2. You can force send all recrods by changing INFOBLOX_SET_DESIRED_STATE = 0"
            Write-Host "Ending the function! Time:$($currentUTCtime)"
            Write-Host "============================================"
            exit
        }
    }
    catch {
        Write-Host  "Unable to find local file [$localFilePath]. continue"    
    }   

    # --------------------------------------------------------------------
    # If there are changes in Azure found then check changes in infoblox
    # --------------------------------------------------------------------
    # Only get the secret if change is detected in Azure
    try {
        $kv_secret = (Get-AzKeyVaultSecret -vaultName $kv_Obj.ResourceName -Name $kv_secret_name).SecretValue
        $creds = New-Object System.Management.Automation.PSCredential -ArgumentList ($kv_secret_name, $kv_secret)
        Write-Host "Got the secret:[$($kv_secret_name)] from Keyvault:[$($kv_Obj.ResourceName)] in RG:[$($kv_obj.ResourceGroupName)]"
    }
    catch {
        $err = "ERROR Getting secret:[$($kv_secret_name)] from Keyvault... Nothing done! Exiting... ERROR:$[$_]"
        Write-Host $err -ForegroundColor Red
        if ($debug) { Write-Host $err }
        $creds = $null
        throw $err
        exit
    }    
    $uniqueZoneNames = $records | Sort-Object -Property zoneName | Select-Object zoneName | Get-Unique -AsString
    Write-Host "----------------------------------------------------------------------------"
    foreach ($unique in $uniqueZoneNames) {
        $zoneTolookup = $unique.zonename
        Write-Host "Zone:[$zoneTolookup] in HUB:[$rg_hub]"   
        Write-Host "----------------------------------------------------------------------------"        
        $recordsAzure = $records | Where-Object { $_.zoneName -eq $zoneTolookup }  | Sort-Object -Property name
        $recordsInfoblox = Get-RecordsInfoblox -searchItem $zoneTolookup -useWildCard $true -ignoreFilterAndGetAll $false -InfobloxAttr_EA_AZURE_DevOps $infoblox_attribute_EA_AZURE_DevOps -InfobloxAttr_EA_AZURE_Node $rg_hub -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver

        $diffDepricated = $recordsInfoblox | Where-Object { ($recordsAzure.fqdn -NotContains $_.name) } # left Join
        $diffDepricatedCount = ($diffDepricated | Measure-Object).Count
        $diffNew = $recordsAzure | Where-Object { ($recordsInfoblox.name -NotContains $_.fqdn) } # left Join
        $diffNewCount = ($diffNew | Measure-Object).Count
        Write-Host "`t Current Azure Records    :[$($recordsAzure.Count)] | Records needs Removing:[$diffDepricatedCount] " 
        Write-Host "`t Current Infoblox Records :[$($recordsInfoblox.Count)] | Records needs Adding  :[$diffNewCount]"   
        # Add the new ones only
        foreach ($rec in $diffNew) {
            Set-RecordInfoblox -record $rec -force $true -InfobloxAttr_EA_AZURE_DevOps $Infoblox_attribute_EA_AZURE_DevOps -InfobloxAttr_EA_AZURE_User $infoblox_user -InfobloxAttr_EA_AZURE_Node $rg_hub -AADName $tenant_name -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver
        }

        # remove the unwanted
        foreach ($rec in $diffDepricated) {
            Remove-RecordInfoblox -record $rec -InfobloxAttr_EA_AZURE_User $infoblox_user -InfobloxAttr_EA_AZURE_Node $rg_hub -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver
        }
        Write-Host "=============================================================================="             
    }
    
    Write-Host "DESIRED STATE - FINISHED"
    Write-Host "------------------------"
} # end if($infoblox_set_desired_state)
else {
    # if user wants to write all records then send them to infoblox blindly. If records already exists then Infoblox will ignore it.
    Write-Host "-------------------------------"
    Write-Host "FORCE SET ALL RECORDS ACTIVATED"
    Write-Host "Try Adding ALL Records:[$($records.Count)] from HUB RG:[$rg_hub] in infoblox:[$infoblox_url]"
    # Only get the secret if change is detected in Azure
    try {
        $kv_secret = (Get-AzKeyVaultSecret -vaultName $kv_Obj.ResourceName -Name $kv_secret_name).SecretValue
        $creds = New-Object System.Management.Automation.PSCredential -ArgumentList ($kv_secret_name, $kv_secret)
        Write-Host "Got the secret:[$($kv_secret_name)] from Keyvault:[$($kv_Obj.ResourceName)] in RG:[$($kv_obj.ResourceGroupName)]"
    }
    catch {
        $err = "ERROR Getting secret:[$($kv_secret_name)] from Keyvault... Nothing done! Exiting... ERROR:$[$_]"
        Write-Host $err -ForegroundColor Red
        if ($debug) { Write-Host $err }
        $creds = $null
        throw $err
        exit
    }   
    foreach ($newRecord in $records) {
        Set-RecordInfoblox -record $newRecord -force $true -InfobloxAttr_EA_AZURE_DevOps $infoblox_attribute_EA_AZURE_DevOps -InfobloxAttr_EA_AZURE_User $infoblox_user -InfobloxAttr_EA_AZURE_Node $rg_hub -AADName $tenant_name  -infobloxUrl $infoblox_url -infobloxWapiVerisonNumber $infoblox_wapi_ver
    }
    Write-Host "FORCE SET ALL RECORDS - FINISHED"
    Write-Host "--------------------------------"
}

#endregion set_infoblox

$currentUTCtime = (Get-Date).ToUniversalTime()
Write-Host "Ending the function! Time:$($currentUTCtime)"
Write-Host "================================================="
