Import-Module $(Join-Path $ENV:BUILD_ARTIFACTSTAGINGDIRECTORY "control/devops_control")
$allNodesPath = Join-Path $ENV:BUILD_ARTIFACTSTAGINGDIRECTORY ".configuration/allNodes"

$allConfigNodes = Get-AllNodes -InstancePath $allNodesPath
"Found Nodes:"
"---"
$allConfigNodes
"---"

az config set extension.use_dynamic_install=yes_without_prompt
az extension add --name azure-devops

ForEach ($node in $allConfigNodes) {
    $node_info_path = join-Path $allNodesPath $node "node_info.json"
    $node_info = Get-Content $node_info_path | ConvertFrom-Json -Depth 20
    $node_config_path = join-Path $allNodesPath $node "node.json"
    $node_config = Get-Content $node_config_path | ConvertFrom-Json -Depth 20
    $node_stages_config_path = join-Path $allNodesPath $node "stages.json"
    $node_stages_config = Get-Content $node_stages_config_path | ConvertFrom-Json -Depth 20

    $updateExisting = $ENV:BUILD_SOURCEBRANCH -eq "refs/heads/main" ? $true : $false
    Set-NodeADOCOnfiguration -NodeConfig $node_config -NodeStages $node_stages_config.stages -NodeInfo $node_info -devopsOrg "ecpIncubate" -devopsProject "al-framework" -repositoryName "alz" -mainBranchName "main" -updateExisting $updateExisting
}