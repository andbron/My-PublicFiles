Import-Module .\ecp.psm1 -force
Set-Context -instancePath "C:\RepoSource\Repos\ECP-Incubation\Config\ecp-demo"

Get-NodeInfo -Node spoke1

Get-NodeInfo -Node spoke1\fwrules
Get-NodeConfiguration -Node spoke1\fwrules
Get-NodeStagesConfiguration -Node spoke1\fwrules
Get-NodeInput -Node spoke1\fwrules -Stage "dev"


Get-NodeInput -Node spoke1\fwrules -Stage "dev" | Convert-InputToBicepParameters -Compress
Get-NodeInput -Node spoke1\fwrules -Stage "dev" | Convert-InputToBicepParameters -AzCLIParameters
Get-NodeInput -Node spoke1\fwrules -Stage "dev" | Convert-InputToTFVars

#Diagram - install "markdown preview mermaid" vs code extension, or publish to devops wiki to render
Build-DependencyDiagram -ShowChildNodes -ShowStageLinks -ShowStages > out.md


########Mock Node PIPELINE
$artifactLocation = "C:\repos\ecpincubate\Config\ecp-demo\.artifact" #set to ado artifact location
###Build
Set-Context -instancePath "C:\repos\ecpincubate\Config\ecp-demo" -artifactPath $artifactLocation
Build-Configuration -Node spoke1\fwrules 
Save-Solution -Node spoke1\fwrules
#TODO Test-Configuration (sca)
#TODO Test-Solution (sca)
#Create Build Artifact containing solution files and merged node/stage configuration

###Plan - from this point on only the build artifact should be referenced
Set-Context -artifactPath $artifactLocation
Initialize-Solution -Stage "dev"
Plan-Solution -Stage "dev"
# (Get-Content (Join-Path $artifactsLocation ".configuration" "dependency_graph.json") | ConvertTo-Json -depth 20) | #TODO

###Deploy
Deploy-Solution -Stage "dev" 



###########Config Scanner PIPELINE?
#Node 
# - Pipeline
# - Branch Policy
#Stage
# - Identity
# - Pool
# - Parent Node RG Scoped RBAC
# - Child Node RG Sc
oped RBAC
# - TF State Storage