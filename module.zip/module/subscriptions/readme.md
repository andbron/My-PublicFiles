# Subscription

## Scope

Subscription:

## Deployment

Resources `*.tf` and RBAC `rbac.tf`.

## Environment

Non-Production

## Details

See [`variables.yml`](.variables.yml)

<!-- BEGIN_TF_DOCS -->

## Requirements

| Name                                                                     | Version |
| ------------------------------------------------------------------------ | ------- |
| <a name="requirement_terraform"></a> [terraform](#requirement_terraform) | >=1.3.1 |
| <a name="requirement_azuread"></a> [azuread](#requirement_azuread)       | 2.30.0  |
| <a name="requirement_azurerm"></a> [azurerm](#requirement_azurerm)       | ~>3.25  |

## Providers

| Name                                                                                                | Version |
| --------------------------------------------------------------------------------------------------- | ------- |
| <a name="provider_azuread"></a> [azuread](#provider_azuread)                                        | 2.30.0  |
| <a name="provider_azurerm"></a> [azurerm](#provider_azurerm)                                        | ~>3.25  |
| <a name="provider_azurerm.connectivity"></a> [azurerm.connectivity](#provider_azurerm.connectivity) | ~>3.25  |
| <a name="provider_azurerm.monitoring"></a> [azurerm.monitoring](#provider_azurerm.monitoring)       | ~>3.25  |

## Modules

| Name                                                                                                                                                                                   | Source                                                                                                        | Version |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- | ------- |
| <a name="module_SharedImageGallery"></a> [SharedImageGallery](#module_SharedImageGallery)                                                                                              | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-shared-image-gallery               | 1.0.3   |
| <a name="module_diagnostics_log_key_vault"></a> [diagnostics_log_key_vault](#module_diagnostics_log_key_vault)                                                                         | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_network_security_group"></a> [diagnostics_log_network_security_group](#module_diagnostics_log_network_security_group)                                  | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account"></a> [diagnostics_log_storage_account](#module_diagnostics_log_storage_account)                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_blob"></a> [diagnostics_log_storage_account_blob](#module_diagnostics_log_storage_account_blob)                                        | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_file"></a> [diagnostics_log_storage_account_file](#module_diagnostics_log_storage_account_file)                                        | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_pac"></a> [diagnostics_log_storage_account_pac](#module_diagnostics_log_storage_account_pac)                                           | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_pac_blob"></a> [diagnostics_log_storage_account_pac_blob](#module_diagnostics_log_storage_account_pac_blob)                            | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_pac_file"></a> [diagnostics_log_storage_account_pac_file](#module_diagnostics_log_storage_account_pac_file)                            | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_pac_queue"></a> [diagnostics_log_storage_account_pac_queue](#module_diagnostics_log_storage_account_pac_queue)                         | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_pac_table"></a> [diagnostics_log_storage_account_pac_table](#module_diagnostics_log_storage_account_pac_table)                         | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_queue"></a> [diagnostics_log_storage_account_queue](#module_diagnostics_log_storage_account_queue)                                     | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_storage_account_table"></a> [diagnostics_log_storage_account_table](#module_diagnostics_log_storage_account_table)                                     | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_diagnostics_log_virtual_network"></a> [diagnostics_log_virtual_network](#module_diagnostics_log_virtual_network)                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-diagnostic-logs                    | 1.0.4   |
| <a name="module_key_vault"></a> [key_vault](#module_key_vault)                                                                                                                         | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-key-vault                          | 1.0.6   |
| <a name="module_naming"></a> [naming](#module_naming)                                                                                                                                  | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-naming                             | 1.0.8   |
| <a name="module_network_security_group_association"></a> [network_security_group_association](#module_network_security_group_association)                                              | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-network-security-group-association | 1.0.1   |
| <a name="module_network_security_group_association_plt_dns_subnet"></a> [network_security_group_association_plt_dns_subnet](#module_network_security_group_association_plt_dns_subnet) | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-network-security-group-association | 1.0.1   |
| <a name="module_network_watcher"></a> [network_watcher](#module_network_watcher)                                                                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-network-watcher                    | 1.0.1   |
| <a name="module_platform_dns_subnet"></a> [platform_dns_subnet](#module_platform_dns_subnet)                                                                                           | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-subnet                             | 1.0.3   |
| <a name="module_private_dns_resolver"></a> [private_dns_resolver](#module_private_dns_resolver)                                                                                        | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-dns-resolver               | 1.0.3   |
| <a name="module_private_dns_resolver_subnet_inbound"></a> [private_dns_resolver_subnet_inbound](#module_private_dns_resolver_subnet_inbound)                                           | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-subnet                             | 1.0.3   |
| <a name="module_private_dns_resolver_subnet_outbound"></a> [private_dns_resolver_subnet_outbound](#module_private_dns_resolver_subnet_outbound)                                        | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-subnet                             | 1.0.3   |
| <a name="module_private_dns_zone"></a> [private_dns_zone](#module_private_dns_zone)                                                                                                    | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-dns-zone                   | 1.0.1   |
| <a name="module_private_dns_zone_static_web"></a> [private_dns_zone_static_web](#module_private_dns_zone_static_web)                                                                   | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-dns-zone                   | 1.0.1   |
| <a name="module_private_endpoint_key_vault"></a> [private_endpoint_key_vault](#module_private_endpoint_key_vault)                                                                      | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-endpoint                   | 1.0.2   |
| <a name="module_private_endpoint_storage_account"></a> [private_endpoint_storage_account](#module_private_endpoint_storage_account)                                                    | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-endpoint                   | 1.0.2   |
| <a name="module_private_endpoint_storage_account_blob_static_web"></a> [private_endpoint_storage_account_blob_static_web](#module_private_endpoint_storage_account_blob_static_web)    | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-endpoint                   | 1.0.2   |
| <a name="module_private_endpoint_storage_account_static_web"></a> [private_endpoint_storage_account_static_web](#module_private_endpoint_storage_account_static_web)                   | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-private-endpoint                   | 1.0.2   |
| <a name="module_rbac_assignment"></a> [rbac_assignment](#module_rbac_assignment)                                                                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-role-assignment                    | 1.0.3   |
| <a name="module_resource_group_1"></a> [resource_group_1](#module_resource_group_1)                                                                                                    | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_resource_group_azure_migrate"></a> [resource_group_azure_migrate](#module_resource_group_azure_migrate)                                                                | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_resource_group_compute_gallery"></a> [resource_group_compute_gallery](#module_resource_group_compute_gallery)                                                          | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_resource_group_management"></a> [resource_group_management](#module_resource_group_management)                                                                         | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_resource_group_network"></a> [resource_group_network](#module_resource_group_network)                                                                                  | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_resource_group_private_dns"></a> [resource_group_private_dns](#module_resource_group_private_dns)                                                                      | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-resource-group                     | 1.0.1   |
| <a name="module_storage_account"></a> [storage_account](#module_storage_account)                                                                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-storage-account                    | 2.0.4   |
| <a name="module_storage_account_pac"></a> [storage_account_pac](#module_storage_account_pac)                                                                                           | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-storage-account                    | 2.0.4   |
| <a name="module_subnet"></a> [subnet](#module_subnet)                                                                                                                                  | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-subnet                             | 1.0.3   |
| <a name="module_subnet_private_endpoint"></a> [subnet_private_endpoint](#module_subnet_private_endpoint)                                                                               | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-subnet                             | 1.0.3   |
| <a name="module_virtual_network"></a> [virtual_network](#module_virtual_network)                                                                                                       | git::https://dev.azure.com/ecpIncubate/EL23-Modules/_git/terraform-azurerm-virtual-network                    | 1.0.1   |

## Resources

| Name                                                                                                                                                                                            | Type        |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| [azurerm_network_security_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group)                                                   | resource    |
| [azurerm_network_security_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule)                                                     | resource    |
| [azurerm_private_dns_zone_virtual_network_link.dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link)            | resource    |
| [azurerm_private_dns_zone_virtual_network_link.dns_vnet_link_static_web](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource    |
| [azurerm_route.vnet_routes](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route)                                                                              | resource    |
| [azurerm_route_table.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table)                                                                         | resource    |
| [azurerm_security_center_automation.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_automation)                                           | resource    |
| [azurerm_storage_blob.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_blob)                                                                       | resource    |
| [azurerm_subnet_route_table_association.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association)                                | resource    |
| [azurerm_virtual_network_peering.peer_from_conn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering)                                       | resource    |
| [azurerm_virtual_network_peering.peer_to_conn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering)                                         | resource    |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/2.30.0/docs/data-sources/client_config)                                                               | data source |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config)                                                               | data source |
| [azurerm_eventhub.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/eventhub)                                                                            | data source |
| [azurerm_eventhub_authorization_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/eventhub_authorization_rule)                                      | data source |
| [azurerm_private_dns_zone.dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone)                                                        | data source |
| [azurerm_role_definition.rbac_roles](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/role_definition)                                                        | data source |
| [azurerm_storage_account.diagnostics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/storage_account)                                                       | data source |
| [azurerm_subscription.scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription)                                                                   | data source |
| [azurerm_virtual_network.connectivity_hub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/virtual_network)                                                  | data source |

## Inputs

| Name                                                                                                                     | Description                                                                    | Type     | Default | Required |
| ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | -------- | ------- | :------: |
| <a name="input_create_private_dns_resolver"></a> [create_private_dns_resolver](#input_create_private_dns_resolver)       | A switch to indicate if the Private DENS Resolver resource is deployed         | `bool`   | `true`  |    no    |
| <a name="input_disable_bgp_route_propagation"></a> [disable_bgp_route_propagation](#input_disable_bgp_route_propagation) | Set route propergation on route table                                          | `string` | `true`  |    no    |
| <a name="input_env_global_config"></a> [env_global_config](#input_env_global_config)                                     | The name of the json file that will hold the config for this environment       | `string` | n/a     |   yes    |
| <a name="input_env_specific_config"></a> [env_specific_config](#input_env_specific_config)                               | The name of the json file that will hold the config for this environment       | `string` | n/a     |   yes    |
| <a name="input_env_specific_nsg_rules"></a> [env_specific_nsg_rules](#input_env_specific_nsg_rules)                      | The name of the csv file that will hold the nsg ruleset for this environment   | `string` | n/a     |   yes    |
| <a name="input_env_specific_route_rules"></a> [env_specific_route_rules](#input_env_specific_route_rules)                | The name of the csv file that will hold the route ruleset for this environment | `string` | n/a     |   yes    |

## Outputs

| Name                                                                    | Description |
| ----------------------------------------------------------------------- | ----------- |
| <a name="output_dns_resolver"></a> [dns_resolver](#output_dns_resolver) | n/a         |

<!-- END_TF_DOCS -->
