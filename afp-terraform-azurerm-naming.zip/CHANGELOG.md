# CHANGELOG

## 1.0.8 1/08/2024

- update virtual machine naming convention based on endorsed naming standard

## 1.0.7 19/07/2024

- add data collection rule to list of kown resources for naming generation

## 1.0.6 25/06/2024

- add container apps environment and add a new environment called npd (non production)

## 1.0.5 30/05/2024

- add route server to list of known resources for naming generation

## 1.0.4 15/04/2024

- update naming calculation logic as per workshop outcomes
- write up service design describing the naming construct and details about each segment

## 1.0.3 26/03/2024

- update unit test error handling logic

## 1.0.2 25/03/2024

- enable module unit tests plus expand module unit test output

## 1.0.1 14/03/2024

- update example syntax

## 1.0.0 14/03/2024

- initial module creation

---

**_CHANGELOG Notes_**

- _Add new changelog entries to the top of the file_
- _Document changes to module inputs (vars) and outputs_
- _Highlight breaking changes using the notation:_ **[BREAKING CHANGE]**
