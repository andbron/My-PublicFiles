[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $tfvarsfile
)

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

$test_config = Get-Content (Join-Path $ScriptPath "config.json") | ConvertFrom-Json
Set-Location $scriptPath
if ($test_config.plan -eq $true) {
    Write-output "`nRunning test init`n"
    terraform init
    Write-Output "`nExit Code is $? - Terraform Init`n"       

    if ($tfvarsfile) {
        Write-output "`nRunning test plan with TFVars`n"
        terraform plan -out state.tfplan -var-file $tfvarsfile
        $error_check = $?
        Write-Output "`nExit Code is $? - Terraform Plan with TFVars`n"  
        if($error_check -eq "1"){$global:tf_success = "false"; exit}
    }
    else {
        Write-output "`nRunning test plan`n"
        terraform plan -out state.tfplan
        if($? -eq $False){Write-Output "`nPlan Error Detected - Value [$?]`n"; $global:tf_success = "false"; exit}
    }

    if ($test_config.apply -eq $true) {
        Write-Output "`nRunning test apply`n"
        terraform apply "state.tfplan" -no-color > apply.txt 2>&1
        $this_file = join-path $pwd.path "apply.txt"
        [System.IO.File]::ReadLines($this_file) | ForEach-Object {if($_ -match "Error:"){$_; $global:tf_success = "false"}else{$_}}
        if ($tf_success -eq $False){Write-Output "`nApply Error Detected`n"}
        Remove-Item -path $this_file -Force -ErrorAction SilentlyContinue

        if ($test_config.destroy -eq $true) {
            Write-Output "`nRunning test destroy`n"
            terraform destroy -auto-approve
        }
    }
}
