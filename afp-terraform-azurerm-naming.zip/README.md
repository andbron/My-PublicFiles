# Module README

<!-- BEGIN_TF_DOCS -->



# CHANGELOG

## 1.0.8 1/08/2024

- update virtual machine naming convention based on endorsed naming standard

## 1.0.7 19/07/2024

- add data collection rule to list of kown resources for naming generation

## 1.0.6 25/06/2024

- add container apps environment and add a new environment called npd (non production)

## 1.0.5 30/05/2024

- add route server to list of known resources for naming generation

## 1.0.4 15/04/2024

- update naming calculation logic as per workshop outcomes
- write up service design describing the naming construct and details about each segment

## 1.0.3 26/03/2024

- update unit test error handling logic

## 1.0.2 25/03/2024

- enable module unit tests plus expand module unit test output

## 1.0.1 14/03/2024

- update example syntax

## 1.0.0 14/03/2024

- initial module creation

---

**_CHANGELOG Notes_**

- _Add new changelog entries to the top of the file_
- _Document changes to module inputs (vars) and outputs_
- _Highlight breaking changes using the notation:_ **[BREAKING CHANGE]**
  

## Service Design
# Azure Resource Naming Generation

## Guidelines

In order to simplify and streamline the generation of a resource name based on a naming construct, its been agreed to use a Terraform module configured to generate resource names based on the agreed inputs. This will promote consistent resource naming as the human interruptative has been removed from the activity of resource name generation. The 6 segmented construct is as follows:

<span style="color:lightblue;">Azure_Resource_Type</span><span style="color:black;">-</span><span style="color:gold;">Classification</span><span style="color:black;">-</span><span style="color:green;">Environment</span><span style="color:black;">-</span><span style="color:darkblue;">Environment</span><span style="color:black;">-</span><span style="red;">Unique_AppId</span><span style="color:black;">-</span><span style="color:black;">Index_Number</span>

The table below describes the purpose of each segment together with any validation requirements and also includes an example.

| Segment             | Purpose                                                                                                                                                                                                                                                                                                                                                                                             | Example                                                             |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| Azure Resource Type | This segment identifies the Azure Resource type, the type defined can be referenced in the following table below.                                                                                                                                                                                                                                                                                   | **vnet**-pro-prd-aea-appid-001                                      |
| Classification      | This segment describes the claasification assigned to the use case of this particular resource. Validation is applied to the field, the accepted values include: <br/> pro - protected <br/> off - official <br/> pub - public                                                                                                                                                                      | vnet-**pro**-prd-aea-appid-001                                      |
| Environment         | This segment describes the environment the resource is associated with. Validation is applied to this field, the accepted inputs are: <br/> production <br/> user_acceptance_testing <br/> quality_assurance <br/> development <br/> test <br/> sandbox                                                                                                                                             | vnet-pro-**prd**-aea-appid-001                                      |
| Region              | This segment identifies which region the resource has been provisioned into. Validation restricts accepted values to include: <br/> aea - australiaeast <br/> ase - australiasoutheast <br/> ac1 - australiacentral <br/> ac2 - australiacentral2 <br/> gl - global <br/>                                                                                                                           | vnet-pro-prd-**aea**-appid-001                                      |
| Application Id      | This segment identifies which application this resource belongs too. The application id **_must be a unique string_** to ensure no duplicate resource names are generated which may cause provisioning errors. In order to align to the naming rules and restrictionse for Azure resources, this field has validation to ensure its a minmum of 3 characters and contains a maximum of 6 characters | vnet-pro-prd-aea-**appid**-001                                      |
| Index               | This segment is a numerical value which depends on the number of the same resources provisioned. An index that increments for each of the same resource type.                                                                                                                                                                                                                                       | vnet-pro-prd-aea-appid-**001** <br/> vnet-pro-prd-aea-appid-**002** |

<br/>

The table following describes the resource type per Azure Resource defined:

| Identifier | Azure Services                               | Resource Name Prefix | Notes                                                                                      |
| ---------- | -------------------------------------------- | -------------------- | ------------------------------------------------------------------------------------------ |
| AA         | Azure Automation                             | aa-                  |                                                                                            |
| ADF        | Azure Data Factory                           | adf-                 |                                                                                            |
| ADLS       | Azure Data Lake Storage                      | adls-                |                                                                                            |
| ADLA       | Azure Data Lake Analytics                    | adla-                |                                                                                            |
| ADX        | Azure Data Explorer cluster                  | adx-                 |                                                                                            |
| ADXDB      | Azure Data Explorer cluster database         | adxdb-               |                                                                                            |
| AFW        | Azure Firewall                               | afw-                 |                                                                                            |
| AFWP       | Azure Firewall Policy                        | afwpolicy-           |                                                                                            |
| AMAG       | Azure Monitor Action Group                   | ag-                  |                                                                                            |
| APPGW      | Application Gateway                          | appgw-               |                                                                                            |
| APPGW      | Application Gateway Web Application Firewall | appgwwaf-            |                                                                                            |
| APPINS     | Application Insights                         | appi-                |                                                                                            |
| AKS        | Azure Kubernetes Service                     | aks-                 |                                                                                            |
| AML        | Azure Machine Learning                       | aml-                 |                                                                                            |
| AMPLS      | Azure Monitor Private Link Scope             | ampls-               |                                                                                            |
| APP        | App Service                                  | app-                 |                                                                                            |
| APPSLOT    | App Service Slot                             | appslot-             |                                                                                            |
| APPPLAN    | App Service Plan                             | appplan-             |                                                                                            |
| AS         | Availability Set                             | as-                  |                                                                                            |
| ASA        | Azure Stream Analytics                       | asa-                 |                                                                                            |
| ASE        | App Service Environment                      | ase-                 |                                                                                            |
| ASEARCH    | Azure Search                                 | srch-                |                                                                                            |
| ASG        | Application Security Group                   | asg-                 |                                                                                            |
| BAS        | Azure Bastion                                | bas-                 |                                                                                            |
| BV         | Azure Backup Vault                           | bv-                  |                                                                                            |
| BVPOL      | Azure Backup Vault Policy                    | bvpol-               |                                                                                            |
| COSMOS     | Azure Cosmos DB                              | cosdb-               |                                                                                            |
| CN         | Gateway Connection                           | con-                 |                                                                                            |
| COG        | Azure Cognitive Services                     | cog-                 |                                                                                            |
| DBW        | Azure Databricks workspace                   | dbw-                 |                                                                                            |
| DNSZ       | Azure DNZ Zone (Private)                     | pdnsz-               |                                                                                            |
| ODSK       | Virtual disk - OS                            | -osdisk              | Contains resource or VM in name followed by type and digit <br> (i.e. <VMNAME>-osdisk<##>) |
| DDSK       | Virtual disk - DATA                          | -data                | Contains resource or VM in name followed by type and digit <br> (i.e. <VMNAME>-data<##>)   |
| DTL        | DevTest Labs                                 | dtl-                 |                                                                                            |
| DBX        | Dev Box                                      | dbx-                 |                                                                                            |
| EG         | Event Grid                                   | eg-                  |                                                                                            |
| EH         | Event Hub                                    | eh-                  |                                                                                            |
| EHN        | Event Hub Namespace                          | ehn-                 |                                                                                            |
| ER         | Express Route                                | er-                  |                                                                                            |
| ERC        | Express Route Circuit                        | ercircuit            |                                                                                            |
| FA         | Function Application (Function APP)          | fapp-                |                                                                                            |
| IA         | Integration Account                          | ia-                  |                                                                                            |
| KV         | Key Vault                                    | kv-                  |                                                                                            |
| LA         | Logic App                                    | lapp-                |                                                                                            |
| LAW        | Log Analytics Workspace                      | law-                 |                                                                                            |
| LBE        | Load Balancer (external)                     | lbe-                 |                                                                                            |
| LBI        | Load Balancer (internal)                     | lbi-                 |                                                                                            |
| LBFE       | Load Balancer Frontend IP Config             | feipconfig-          |                                                                                            |
| LBBE       | Load Balancer Frontend Backend Pool          | bepool-              |                                                                                            |
| LBHP       | Load Balancer Health Probe                   | hp-                  | (i.e. hp-<Protocol><Port>/<Description>                                                    |
| LBR        | Load Balancer Rule                           | lbr-                 | May be expanded upon in the future                                                         |
| LGW        | Local Network Gateway                        | lgw-                 |                                                                                            |
| MI         | Azure Managed Identity                       | mi-                  |                                                                                            |
| MIG        | Azure Migrate Project                        | migr-                |                                                                                            |
| MON        | Azure Monitor Workspace                      | monw-                |                                                                                            |
| MSQL       | Azure Database for MySql                     | mysql-               |                                                                                            |
| NGW        | NAT Gateway                                  | ngw-                 |                                                                                            |
| NH         | Azure Notification Hub                       | nh-                  |                                                                                            |
| NHNS       | Azure Notification Hub Namespace             | nhns-                |                                                                                            |
| NIC        | Network Interface (Virtual NIC)              | -nic-                | Contains resource or VM in name followed by digit <br> (i.e. <VMNAME>-nic-<##>)            |
| NSG        | Network Security Group                       | nsg-                 |                                                                                            |
| NW         | Azure Network Watcher                        | nw-                  |                                                                                            |
| PBI        | PowerBi                                      | pbi-                 |                                                                                            |
| PE         | Private Endpoint                             | pe-                  |                                                                                            |
| PIP        | Public IP                                    | pip-                 |                                                                                            |
| PL         | Private Link                                 | pl-                  |                                                                                            |
| PSQLS      | PostGreSQL Server                            | psqls-               |                                                                                            |
| PSQLD      | PostGreSQL DB                                | psqld-               |                                                                                            |
| REDIS      | Azure Cache for Redis                        | redis-               |                                                                                            |
| RG         | Resource Group                               | rg-                  |                                                                                            |
| RSV        | Azure Recovery Services Vault                | rsv-                 |                                                                                            |
| RSVP       | Azure Recovery Services Vault Policy         | rsvpol-              |                                                                                            |
| RT         | Route Table (aka UDR)                        | rt-                  |                                                                                            |
| SA         | Storage Account                              | sa                   | Name limitation on uniqueness and no '-'                                                   |
| SB         | Service Bus                                  | sb-                  |                                                                                            |
| SBQ        | Service Bus queue                            | sbq-                 |                                                                                            |
| SBT        | Service Bus topic                            | sbt-                 |                                                                                            |
| SD         | Shared Dashboard                             | sdash-               |                                                                                            |
| SE         | Service Endpoint                             | se-                  |                                                                                            |
| SN         | Subnet                                       | sn-                  |                                                                                            |
| SQL        | SQL DB                                       | sql-                 |                                                                                            |
| SQLDB      | Azure SQL Database                           | sqldb-               |                                                                                            |
| SQLDW      | Azure SQL Data Warehouse                     | sqldw-               |                                                                                            |
| SQLMI      | Azure SQL Managed Instance                   | sqlmi-               |                                                                                            |
| SQLS       | Azure SQL Database Server                    | sqls-                |                                                                                            |
| STVM       | Virtual machine storage account              | stvm-                |                                                                                            |
| SYN        | Azure Synapse                                | syn-                 |                                                                                            |
| VDW        | Virtual desktop workspace                    | vdw-                 |                                                                                            |
| VDAPPG     | Virtual desktop application group            | vdappg-              |                                                                                            |
| VDHPOOL    | Virtual desktop host pool                    | vdhpool-             |                                                                                            |
| VM         | Virtual Machine                              | _<See Below>_        |                                                                                            |
| VMSS       | Virtual machine scale set                    | vmss-                |                                                                                            |
| VN         | VNET                                         | vnet-                |                                                                                            |
| VNGW       | VNET Gateway                                 | vnetgw-              |                                                                                            |
| VNP        | VNet Peer                                    | peer-                |                                                                                            |
| VPNGW      | VPN Gateway                                  | vpngw                |                                                                                            |
| WA         | Web App                                      | wapp-                |                                                                                            |

<br/>

## How to Generate Rewsource Names

In order to test any logic updates to the naming module, its recommended to yse the Terraform Console to get an insight into what are the calcuation steps occuring within the modul's logic. To start the Terraform Console, refer this example following:

```PowerShell

terraform init

terraform console -var security_classification="pro" -var environment="development" -var location="australiaeast" -var domain="1234" -var generator="{domain={resource_group= 3, subnet= 3}}"

```

Once the Terraform console has been invoked, you can type `local.generator_config` to return all the respective naming segments for the declared resources (ie: resource groups and subnets).

```PowerShell

{
  "domain" = {
    "resource_group" = {
      "count" = 3
      "index_format" = "%03d"
      "max_name_length" = -1
      "name_parts" = tolist([
        "rg",
        "pro",
        "dev",
        "aea",
        "1234",
      ])
      "separator" = "-"
      "type" = "resource_group"
    }
    "subnet" = {
      "count" = 3
      "index_format" = "%03d"
      "max_name_length" = -1
      "name_parts" = tolist([
        "snet",
        "pro",
        "dev",
        "aea",
        "1234",
      ])
      "separator" = "-"
      "type" = "subnet"
    }
  }
}

```
  

## Example usage

```hcl

### A provider block is required in order to interact with an azure subscription
### Note: the Unit testing pipeline handles the necessary authentication steps 
terraform {
  required_version = ">= 1.7.2" # Terraform Version >=1.7.2
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~>3.6.0"
    }
  }
}

provider "azurerm" {
  features {}
}


# ### This code snippet will call the module that this test is designed for using a relative path
module "thismodule" {
  source = "../../"
  #add module inputs as needed
  security_classification = "pro"
  environment             = "development"
  location                = "australiaeast"
  domain                  = "1234"
  generator = {
    domain = {
      resource_group          = 3
      # subnet                  = 3
      # network_watcher         = 1
      # virtual_network         = 3
      # key_vault               = 3
      # storage_account         = 3
      # network_interface       = 3
      # network_security_group  = 3
      # private_endpoint        = 3
      virtual_machine_is       = 3
      # virtual_machine_db       = 3
    }
  }

}

output "resource_group_names_returned" {
  value = module.thismodule.generated_names.domain.resource_group
}

# output "subnet_returned" {
#   value = module.thismodule.generated_names.domain.subnet
# }

# output "network_watcher_returned" {
#   value = module.thismodule.generated_names.domain.network_watcher
# }

# output "virtual_network_returned" {
#   value = module.thismodule.generated_names.domain.virtual_network
# }

# output "key_vault_returned" {
#   value = module.thismodule.generated_names.domain.key_vault
# }

# output "storage_account_returned" {
#   value = module.thismodule.generated_names.domain.storage_account
# }

# output "network_interface_returned" {
#   value = module.thismodule.generated_names.domain.network_interface
# }

# output "network_security_group_returned" {
#   value = module.thismodule.generated_names.domain.network_security_group
# }

# output "private_endpoint_returned" {
#   value = module.thismodule.generated_names.domain.private_endpoint
# }

output "virtual_machine_is" {
  value = module.thismodule.generated_names.domain.virtual_machine_is
}

output "computer_name_is" {
  value = module.thismodule.generated_names.domain.computer_name_is
}

# output "virtual_machine_db" {
#   value = module.thismodule.generated_names.domain.virtual_machine_db
# }

# output "computer_name_db" {
#   value = module.thismodule.generated_names.domain.computer_name_db
# }
  
{
    "plan": true,
    "apply": true,
    "destroy": true
}
 
module "naming" {
  source = "../../"
  #add module inputs as needed
  security_classification = "pro"
  environment             = "development"
  location                = "australiaeast"
  domain                  = "1234"
  generator = {
    domain = {
      resource_group          = 3
      subnet                  = 4
      network_watcher         = 1
      virtual_network         = 5
      key_vault               = 1
      storage_account         = 4
      network_interface       = 5
      network_security_group  = 4
      private_endpoint        = 5
      route_table             = 5
      azure_compute_gallery   = 1
      private_dns_resolver    = 1
      virtual_machine_linux   = 3
      virtual_machine_windows = 3
    }
  }
}
   
```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.7.2 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.90.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.6.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_random"></a> [random](#provider\_random) | >= 3.6.0 |  

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [random_string.random](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_custom_abbreviation"></a> [custom\_abbreviation](#input\_custom\_abbreviation) | To be used as custom abbreviation for custom services. | `string` | `"abcde"` | no |
| <a name="input_domain"></a> [domain](#input\_domain) | To be used as unique identifier for platform landing zones or application landing zones. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_environment_map"></a> [environment\_map](#input\_environment\_map) | n/a | `map(any)` | <pre>{<br>  "development": "dev",<br>  "non_production": "npd",<br>  "production": "prd",<br>  "quality_assurance": "qua",<br>  "sandbox": "snb",<br>  "test": "tst",<br>  "user_acceptance_testing": "uat"<br>}</pre> | no |
| <a name="input_generator"></a> [generator](#input\_generator) | n/a | `map(map(number))` | <pre>{<br>  "app": {<br>    "rg": 1<br>  }<br>}</pre> | no |
| <a name="input_location"></a> [location](#input\_location) | general | `string` | n/a | yes |
| <a name="input_location_map"></a> [location\_map](#input\_location\_map) | n/a | `map(any)` | <pre>{<br>  "australiacentral": "ac1",<br>  "australiacentral2": "ac2",<br>  "australiaeast": "aea",<br>  "australiasoutheast": "ase",<br>  "global": "gl",<br>  "notapplicable": "",<br>  "worldwide": "ww-"<br>}</pre> | no |
| <a name="input_security_classification"></a> [security\_classification](#input\_security\_classification) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_env_abbr"></a> [env\_abbr](#output\_env\_abbr) | Abbreviated environment name. |
| <a name="output_environment"></a> [environment](#output\_environment) | Environment name. |
| <a name="output_generated_names"></a> [generated\_names](#output\_generated\_names) | Generated names. |
| <a name="output_location"></a> [location](#output\_location) | Location |
| <a name="output_tags"></a> [tags](#output\_tags) | tags. |


<!-- END_TF_DOCS -->