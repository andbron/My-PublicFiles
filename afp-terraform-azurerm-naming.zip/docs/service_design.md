# Azure Resource Naming Generation

## Guidelines

In order to simplify and streamline the generation of a resource name based on a naming construct, its been agreed to use a Terraform module configured to generate resource names based on the agreed inputs. This will promote consistent resource naming as the human interruptative has been removed from the activity of resource name generation. The 6 segmented construct is as follows:

<span style="color:lightblue;">Azure_Resource_Type</span><span style="color:black;">-</span><span style="color:gold;">Classification</span><span style="color:black;">-</span><span style="color:green;">Environment</span><span style="color:black;">-</span><span style="color:darkblue;">Environment</span><span style="color:black;">-</span><span style="red;">Unique_AppId</span><span style="color:black;">-</span><span style="color:black;">Index_Number</span>

The table below describes the purpose of each segment together with any validation requirements and also includes an example.

| Segment             | Purpose                                                                                                                                                                                                                                                                                                                                                                                             | Example                                                             |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| Azure Resource Type | This segment identifies the Azure Resource type, the type defined can be referenced in the following table below.                                                                                                                                                                                                                                                                                   | **vnet**-pro-prd-aea-appid-001                                      |
| Classification      | This segment describes the claasification assigned to the use case of this particular resource. Validation is applied to the field, the accepted values include: <br/> pro - protected <br/> off - official <br/> pub - public                                                                                                                                                                      | vnet-**pro**-prd-aea-appid-001                                      |
| Environment         | This segment describes the environment the resource is associated with. Validation is applied to this field, the accepted inputs are: <br/> production <br/> user_acceptance_testing <br/> quality_assurance <br/> development <br/> test <br/> sandbox                                                                                                                                             | vnet-pro-**prd**-aea-appid-001                                      |
| Region              | This segment identifies which region the resource has been provisioned into. Validation restricts accepted values to include: <br/> aea - australiaeast <br/> ase - australiasoutheast <br/> ac1 - australiacentral <br/> ac2 - australiacentral2 <br/> gl - global <br/>                                                                                                                           | vnet-pro-prd-**aea**-appid-001                                      |
| Application Id      | This segment identifies which application this resource belongs too. The application id **_must be a unique string_** to ensure no duplicate resource names are generated which may cause provisioning errors. In order to align to the naming rules and restrictionse for Azure resources, this field has validation to ensure its a minmum of 3 characters and contains a maximum of 6 characters | vnet-pro-prd-aea-**appid**-001                                      |
| Index               | This segment is a numerical value which depends on the number of the same resources provisioned. An index that increments for each of the same resource type.                                                                                                                                                                                                                                       | vnet-pro-prd-aea-appid-**001** <br/> vnet-pro-prd-aea-appid-**002** |

<br/>

The table following describes the resource type per Azure Resource defined:

| Identifier | Azure Services                               | Resource Name Prefix | Notes                                                                                      |
| ---------- | -------------------------------------------- | -------------------- | ------------------------------------------------------------------------------------------ |
| AA         | Azure Automation                             | aa-                  |                                                                                            |
| ADF        | Azure Data Factory                           | adf-                 |                                                                                            |
| ADLS       | Azure Data Lake Storage                      | adls-                |                                                                                            |
| ADLA       | Azure Data Lake Analytics                    | adla-                |                                                                                            |
| ADX        | Azure Data Explorer cluster                  | adx-                 |                                                                                            |
| ADXDB      | Azure Data Explorer cluster database         | adxdb-               |                                                                                            |
| AFW        | Azure Firewall                               | afw-                 |                                                                                            |
| AFWP       | Azure Firewall Policy                        | afwpolicy-           |                                                                                            |
| AMAG       | Azure Monitor Action Group                   | ag-                  |                                                                                            |
| APPGW      | Application Gateway                          | appgw-               |                                                                                            |
| APPGW      | Application Gateway Web Application Firewall | appgwwaf-            |                                                                                            |
| APPINS     | Application Insights                         | appi-                |                                                                                            |
| AKS        | Azure Kubernetes Service                     | aks-                 |                                                                                            |
| AML        | Azure Machine Learning                       | aml-                 |                                                                                            |
| AMPLS      | Azure Monitor Private Link Scope             | ampls-               |                                                                                            |
| APP        | App Service                                  | app-                 |                                                                                            |
| APPSLOT    | App Service Slot                             | appslot-             |                                                                                            |
| APPPLAN    | App Service Plan                             | appplan-             |                                                                                            |
| AS         | Availability Set                             | as-                  |                                                                                            |
| ASA        | Azure Stream Analytics                       | asa-                 |                                                                                            |
| ASE        | App Service Environment                      | ase-                 |                                                                                            |
| ASEARCH    | Azure Search                                 | srch-                |                                                                                            |
| ASG        | Application Security Group                   | asg-                 |                                                                                            |
| BAS        | Azure Bastion                                | bas-                 |                                                                                            |
| BV         | Azure Backup Vault                           | bv-                  |                                                                                            |
| BVPOL      | Azure Backup Vault Policy                    | bvpol-               |                                                                                            |
| COSMOS     | Azure Cosmos DB                              | cosdb-               |                                                                                            |
| CN         | Gateway Connection                           | con-                 |                                                                                            |
| COG        | Azure Cognitive Services                     | cog-                 |                                                                                            |
| DBW        | Azure Databricks workspace                   | dbw-                 |                                                                                            |
| DNSZ       | Azure DNZ Zone (Private)                     | pdnsz-               |                                                                                            |
| ODSK       | Virtual disk - OS                            | -osdisk              | Contains resource or VM in name followed by type and digit <br> (i.e. <VMNAME>-osdisk<##>) |
| DDSK       | Virtual disk - DATA                          | -data                | Contains resource or VM in name followed by type and digit <br> (i.e. <VMNAME>-data<##>)   |
| DTL        | DevTest Labs                                 | dtl-                 |                                                                                            |
| DBX        | Dev Box                                      | dbx-                 |                                                                                            |
| EG         | Event Grid                                   | eg-                  |                                                                                            |
| EH         | Event Hub                                    | eh-                  |                                                                                            |
| EHN        | Event Hub Namespace                          | ehn-                 |                                                                                            |
| ER         | Express Route                                | er-                  |                                                                                            |
| ERC        | Express Route Circuit                        | ercircuit            |                                                                                            |
| FA         | Function Application (Function APP)          | fapp-                |                                                                                            |
| IA         | Integration Account                          | ia-                  |                                                                                            |
| KV         | Key Vault                                    | kv-                  |                                                                                            |
| LA         | Logic App                                    | lapp-                |                                                                                            |
| LAW        | Log Analytics Workspace                      | law-                 |                                                                                            |
| LBE        | Load Balancer (external)                     | lbe-                 |                                                                                            |
| LBI        | Load Balancer (internal)                     | lbi-                 |                                                                                            |
| LBFE       | Load Balancer Frontend IP Config             | feipconfig-          |                                                                                            |
| LBBE       | Load Balancer Frontend Backend Pool          | bepool-              |                                                                                            |
| LBHP       | Load Balancer Health Probe                   | hp-                  | (i.e. hp-<Protocol><Port>/<Description>                                                    |
| LBR        | Load Balancer Rule                           | lbr-                 | May be expanded upon in the future                                                         |
| LGW        | Local Network Gateway                        | lgw-                 |                                                                                            |
| MI         | Azure Managed Identity                       | mi-                  |                                                                                            |
| MIG        | Azure Migrate Project                        | migr-                |                                                                                            |
| MON        | Azure Monitor Workspace                      | monw-                |                                                                                            |
| MSQL       | Azure Database for MySql                     | mysql-               |                                                                                            |
| NGW        | NAT Gateway                                  | ngw-                 |                                                                                            |
| NH         | Azure Notification Hub                       | nh-                  |                                                                                            |
| NHNS       | Azure Notification Hub Namespace             | nhns-                |                                                                                            |
| NIC        | Network Interface (Virtual NIC)              | -nic-                | Contains resource or VM in name followed by digit <br> (i.e. <VMNAME>-nic-<##>)            |
| NSG        | Network Security Group                       | nsg-                 |                                                                                            |
| NW         | Azure Network Watcher                        | nw-                  |                                                                                            |
| PBI        | PowerBi                                      | pbi-                 |                                                                                            |
| PE         | Private Endpoint                             | pe-                  |                                                                                            |
| PIP        | Public IP                                    | pip-                 |                                                                                            |
| PL         | Private Link                                 | pl-                  |                                                                                            |
| PSQLS      | PostGreSQL Server                            | psqls-               |                                                                                            |
| PSQLD      | PostGreSQL DB                                | psqld-               |                                                                                            |
| REDIS      | Azure Cache for Redis                        | redis-               |                                                                                            |
| RG         | Resource Group                               | rg-                  |                                                                                            |
| RSV        | Azure Recovery Services Vault                | rsv-                 |                                                                                            |
| RSVP       | Azure Recovery Services Vault Policy         | rsvpol-              |                                                                                            |
| RT         | Route Table (aka UDR)                        | rt-                  |                                                                                            |
| SA         | Storage Account                              | sa                   | Name limitation on uniqueness and no '-'                                                   |
| SB         | Service Bus                                  | sb-                  |                                                                                            |
| SBQ        | Service Bus queue                            | sbq-                 |                                                                                            |
| SBT        | Service Bus topic                            | sbt-                 |                                                                                            |
| SD         | Shared Dashboard                             | sdash-               |                                                                                            |
| SE         | Service Endpoint                             | se-                  |                                                                                            |
| SN         | Subnet                                       | sn-                  |                                                                                            |
| SQL        | SQL DB                                       | sql-                 |                                                                                            |
| SQLDB      | Azure SQL Database                           | sqldb-               |                                                                                            |
| SQLDW      | Azure SQL Data Warehouse                     | sqldw-               |                                                                                            |
| SQLMI      | Azure SQL Managed Instance                   | sqlmi-               |                                                                                            |
| SQLS       | Azure SQL Database Server                    | sqls-                |                                                                                            |
| STVM       | Virtual machine storage account              | stvm-                |                                                                                            |
| SYN        | Azure Synapse                                | syn-                 |                                                                                            |
| VDW        | Virtual desktop workspace                    | vdw-                 |                                                                                            |
| VDAPPG     | Virtual desktop application group            | vdappg-              |                                                                                            |
| VDHPOOL    | Virtual desktop host pool                    | vdhpool-             |                                                                                            |
| VM         | Virtual Machine                              | _<See Below>_        |                                                                                            |
| VMSS       | Virtual machine scale set                    | vmss-                |                                                                                            |
| VN         | VNET                                         | vnet-                |                                                                                            |
| VNGW       | VNET Gateway                                 | vnetgw-              |                                                                                            |
| VNP        | VNet Peer                                    | peer-                |                                                                                            |
| VPNGW      | VPN Gateway                                  | vpngw                |                                                                                            |
| WA         | Web App                                      | wapp-                |                                                                                            |

<br/>

## How to Generate Rewsource Names

In order to test any logic updates to the naming module, its recommended to yse the Terraform Console to get an insight into what are the calcuation steps occuring within the modul's logic. To start the Terraform Console, refer this example following:

```PowerShell

terraform init

terraform console -var security_classification="pro" -var environment="development" -var location="australiaeast" -var domain="1234" -var generator="{domain={resource_group= 3, subnet= 3}}"

```

Once the Terraform console has been invoked, you can type `local.generator_config` to return all the respective naming segments for the declared resources (ie: resource groups and subnets).

```PowerShell

{
  "domain" = {
    "resource_group" = {
      "count" = 3
      "index_format" = "%03d"
      "max_name_length" = -1
      "name_parts" = tolist([
        "rg",
        "pro",
        "dev",
        "aea",
        "1234",
      ])
      "separator" = "-"
      "type" = "resource_group"
    }
    "subnet" = {
      "count" = 3
      "index_format" = "%03d"
      "max_name_length" = -1
      "name_parts" = tolist([
        "snet",
        "pro",
        "dev",
        "aea",
        "1234",
      ])
      "separator" = "-"
      "type" = "subnet"
    }
  }
}

```
