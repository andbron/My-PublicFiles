<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_lb.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb_backend_address_pool.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_nat_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_nat_rule) | resource |
| [azurerm_lb_probe.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_network_interface_backend_address_pool_association.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_backend_address_pool_associations"></a> [backend\_address\_pool\_associations](#input\_backend\_address\_pool\_associations) | List of Backend Address Pools Associations. | <pre>map(object({<br>    network_interface_id  = string<br>    ip_configuration_name = string<br>  }))</pre> | n/a | yes |
| <a name="input_backend_address_pool_name"></a> [backend\_address\_pool\_name](#input\_backend\_address\_pool\_name) | The name which should be used for this Backend Address Pool. | `string` | n/a | yes |
| <a name="input_frontend_ip_configuration_name"></a> [frontend\_ip\_configuration\_name](#input\_frontend\_ip\_configuration\_name) | Specifies the name of the frontend IP configuration | `string` | n/a | yes |
| <a name="input_frontend_private_ip_address"></a> [frontend\_private\_ip\_address](#input\_frontend\_private\_ip\_address) | Private IP Address to assign to the Load Balancer. | `string` | `null` | no |
| <a name="input_frontend_private_ip_address_allocation"></a> [frontend\_private\_ip\_address\_allocation](#input\_frontend\_private\_ip\_address\_allocation) | The allocation method for the Private IP Address used by this Load Balancer. Possible values as Dynamic and Static. | `string` | `"Dynamic"` | no |
| <a name="input_frontend_private_ip_private_ip_address_version"></a> [frontend\_private\_ip\_private\_ip\_address\_version](#input\_frontend\_private\_ip\_private\_ip\_address\_version) | The version of IP that the Private IP Address is. Possible values are IPv4 or IPv6. | `string` | `"IPv4"` | no |
| <a name="input_frontend_subnet_id"></a> [frontend\_subnet\_id](#input\_frontend\_subnet\_id) | The ID of the Subnet which should be associated with the IP Configuration. | `string` | n/a | yes |
| <a name="input_lb_name"></a> [lb\_name](#input\_lb\_name) | Specifies the name of the Load Balancer | `string` | n/a | yes |
| <a name="input_lb_sku"></a> [lb\_sku](#input\_lb\_sku) | n/a | `string` | `"Standard"` | no |
| <a name="input_load_balancer_nat_rules"></a> [load\_balancer\_nat\_rules](#input\_load\_balancer\_nat\_rules) | Map containing load balancer nat pool parameters. | <pre>map(object({<br>    name                    = string<br>    frontend_ip_name        = string<br>    lb_port                 = number<br>    backend_port            = number<br>    idle_timeout_in_minutes = number<br>    enable_floating_ip      = bool<br>    enable_tcp_reset        = bool<br>  }))</pre> | `{}` | no |
| <a name="input_load_balancer_rules"></a> [load\_balancer\_rules](#input\_load\_balancer\_rules) | Map containing load balancer rule and probe parameters. | <pre>map(object({<br>    name                      = string<br>    lb_protocol               = string<br>    lb_port                   = string<br>    backend_port              = number<br>    enable_floating_ip        = bool<br>    disable_outbound_snat     = bool<br>    enable_tcp_reset          = bool<br>    probe_port                = number<br>    probe_protocol            = string<br>    request_path              = string<br>    probe_interval            = number<br>    probe_unhealthy_threshold = number<br>    load_distribution         = string<br>    idle_timeout_in_minutes   = number<br>  }))</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure Region where the Load Balancer should be created. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group in which to create the Load Balancer. | `string` | n/a | yes |
| <a name="input_sku_tier"></a> [sku\_tier](#input\_sku\_tier) | The Sku Tier of this Load Balancer. Possible values are Global and Regional. | `string` | `"Regional"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags of the Load Balancer in addition to the resource group tag. | `map(string)` | `null` | no |
| <a name="input_zones"></a> [zones](#input\_zones) | Specifies a list of Availability Zones in which the IP Address for this Load Balancer should be located. | `list(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_backend_ids"></a> [backend\_ids](#output\_backend\_ids) | The list of backend pool address IDs. |
| <a name="output_frontend_ip_configurations"></a> [frontend\_ip\_configurations](#output\_frontend\_ip\_configurations) | The list of frontend configurations names. |
| <a name="output_id"></a> [id](#output\_id) | The Load Balancer Id. |
| <a name="output_name"></a> [name](#output\_name) | The Load Balancer name. |
| <a name="output_natrule_map_ids"></a> [natrule\_map\_ids](#output\_natrule\_map\_ids) | The map of NAT rules. |
| <a name="output_private_ip_addresses"></a> [private\_ip\_addresses](#output\_private\_ip\_addresses) | The list of private IP addresses assigned to the frontend configuration names. |
| <a name="output_probe_ids"></a> [probe\_ids](#output\_probe\_ids) | The list of Probe IDs. |
| <a name="output_probe_map_ids"></a> [probe\_map\_ids](#output\_probe\_map\_ids) | The map of Load Balancer Probes. |
| <a name="output_rule_ids"></a> [rule\_ids](#output\_rule\_ids) | The list of Load Balancer rules Ids. |
<!-- END_TF_DOCS -->