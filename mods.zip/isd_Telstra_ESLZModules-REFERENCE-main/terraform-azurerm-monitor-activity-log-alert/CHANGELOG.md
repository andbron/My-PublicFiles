# CHANGELOG (aligned to versions.tf)

## [1.0.6] - [2024-03-20]

### Added

- Added levels

## [1.0.5] - [2024-03-12]

### Added

- Added all receivers

## [1.0.4] - [2023-02-27]

### Added

- tags in azurerm_monitor_action_group block

## [1.0.3] - [2023-02-27]

### Added

- modified azurerm version ~>3.25 instead of ~>3.25.0

## [1.0.2] - [2023-02-27]

### Added

- modified azurerm version from =3.25.0 to ~>3.25.0

## [1.0.1] - [2023-02-22]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
