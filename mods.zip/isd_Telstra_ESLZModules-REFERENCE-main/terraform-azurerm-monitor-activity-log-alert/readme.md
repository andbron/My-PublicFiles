ESLZ Modules
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_action_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |
| [azurerm_monitor_activity_log_alert.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_activity_log_alert) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_name"></a> [action\_group\_name](#input\_action\_group\_name) | The name of the Action Group. | `string` | n/a | yes |
| <a name="input_action_group_short_name"></a> [action\_group\_short\_name](#input\_action\_group\_short\_name) | The short name of the action group. This will be used in SMS messages. | `string` | n/a | yes |
| <a name="input_alert_category"></a> [alert\_category](#input\_alert\_category) | The category of the operation. Possible values are Administrative, Autoscale, Policy, Recommendation, ResourceHealth, Security and ServiceHealth. | `string` | n/a | yes |
| <a name="input_alert_description"></a> [alert\_description](#input\_alert\_description) | The description of this activity log alert. | `string` | `""` | no |
| <a name="input_alert_enable"></a> [alert\_enable](#input\_alert\_enable) | Should this Activity Log Alert be enabled? | `bool` | `true` | no |
| <a name="input_alert_name"></a> [alert\_name](#input\_alert\_name) | The name of the activity log alert. | `string` | n/a | yes |
| <a name="input_alert_scope_list"></a> [alert\_scope\_list](#input\_alert\_scope\_list) | The Scope at which the Activity Log should be applied. A list of strings which could be a resource group/subscription/resource ID. | `list(string)` | n/a | yes |
| <a name="input_caller"></a> [caller](#input\_caller) | The email address or Azure Active Directory identifier of the user who performed the operation. | `string` | `null` | no |
| <a name="input_emailreceivers"></a> [emailreceivers](#input\_emailreceivers) | A list of email receiver for alert.<br>    <br>    name - (Required) The name of the email receiver. Names must be unique (case-insensitive) <br>    across all receivers within an action group.<br><br>    email\_address - (Required) The email address of this receiver.<br><br>    use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    email_address           = string<br>    use_common_alert_schema = bool<br>  }))</pre> | n/a | yes |
| <a name="input_level"></a> [level](#input\_level) | The severity level of the event. Possible values are Verbose, Informational, Warning, Error, and Critical. | `string` | `"Informational"` | no |
| <a name="input_monitor_resource_group"></a> [monitor\_resource\_group](#input\_monitor\_resource\_group) | The name of resource group monitored by the activity log alert. | `string` | `null` | no |
| <a name="input_monitor_resource_id"></a> [monitor\_resource\_id](#input\_monitor\_resource\_id) | The specific resource monitored by the activity log alert. It should be within one of the scopes. | `string` | `null` | no |
| <a name="input_operation_name"></a> [operation\_name](#input\_operation\_name) | The Resource Manager Role-Based Access Control operation name. Supported operation should be of the form: <resourceProvider>/<resourceType>/<operation> | `string` | `null` | no |
| <a name="input_recommendation_category"></a> [recommendation\_category](#input\_recommendation\_category) | The recommendation category of the event. Possible values are Cost, Reliability, OperationalExcellence and Performance. It is only allowed when category is Recommendation. | `string` | `"Performance"` | no |
| <a name="input_recommendation_impact"></a> [recommendation\_impact](#input\_recommendation\_impact) | The recommendation impact of the event. Possible values are High, Medium and Low. It is only allowed when category is Recommendation. | `string` | `"Medium"` | no |
| <a name="input_recommendation_type"></a> [recommendation\_type](#input\_recommendation\_type) | The recommendation type of the event. It is only allowed when category is Recommendation. | `string` | `null` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the activity log alert. | `string` | n/a | yes |
| <a name="input_resource_health_current"></a> [resource\_health\_current](#input\_resource\_health\_current) | List of resource current health statuses that will log an alert. Possible values are Available, Degraded, Unavailable and Unknown. | `list(string)` | `[]` | no |
| <a name="input_resource_health_previous"></a> [resource\_health\_previous](#input\_resource\_health\_previous) | List of resource previous health statuses that will log an alert. Possible values are Available, Degraded, Unavailable and Unknown. | `list(string)` | `[]` | no |
| <a name="input_resource_health_reason"></a> [resource\_health\_reason](#input\_resource\_health\_reason) | List of reasons that will log an alert. Possible values are PlatformInitiated (such as a problem with the resource in an affected region of an Azure incident), UserInitiated (such as a shutdown request of a VM) and Unknown. | `list(string)` | `[]` | no |
| <a name="input_resource_provider"></a> [resource\_provider](#input\_resource\_provider) | The name of the resource provider monitored by the activity log alert. | `string` | `null` | no |
| <a name="input_resource_type"></a> [resource\_type](#input\_resource\_type) | The resource type monitored by the activity log alert. | `string` | `""` | no |
| <a name="input_service_health_events"></a> [service\_health\_events](#input\_service\_health\_events) | Events this alert will monitor Possible values are Incident, Maintenance, Informational, ActionRequired and Security. By default All events | `list(string)` | `[]` | no |
| <a name="input_service_health_locations"></a> [service\_health\_locations](#input\_service\_health\_locations) | Locations this alert will monitor. For example, West Europe. Default value will be all locations | `list(string)` | `[]` | no |
| <a name="input_service_health_services"></a> [service\_health\_services](#input\_service\_health\_services) | Services this alert will monitor. For example, Activity Logs & Alerts, Action Groups. Defaults to all Services. | `list(string)` | `[]` | no |
| <a name="input_status"></a> [status](#input\_status) | The status of the event. For example, Started, Failed, or Succeeded. | `string` | `null` | no |
| <a name="input_sub_status"></a> [sub\_status](#input\_sub\_status) | The sub status of the event. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the activity log alert. | `map(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_action_group_id"></a> [action\_group\_id](#output\_action\_group\_id) | The ID of the created action group. |
| <a name="output_id"></a> [id](#output\_id) | The ID of the created activity log alert. |
<!-- END_TF_DOCS -->
