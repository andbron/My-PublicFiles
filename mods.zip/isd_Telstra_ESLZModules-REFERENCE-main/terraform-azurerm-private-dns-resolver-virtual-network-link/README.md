<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_resolver_virtual_network_link.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_virtual_network_link) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_dns_forwarding_ruleset_id "></a> [dns\_forwarding\_ruleset\_id ](#input\_dns\_forwarding\_ruleset\_id ) | The name of Private DNS Resolver | `string` | n/a | yes |
| <a name="input_metadata"></a> [metadata](#input\_metadata) | metadata of the Private DNS Resolver. | `map(string)` | `null` | no |
| <a name="input_private_dns_resolver_virtual_network_link_name"></a> [private\_dns\_resolver\_virtual\_network\_link\_name](#input\_private\_dns\_resolver\_virtual\_network\_link\_name) | Specifies the name which should be used for this Private DNS Resolver Virtual Network Link. Changing this forces a new Private DNS Resolver Virtual Network Link to be created. | `string` | n/a | yes |
| <a name="input_virtual_network_id"></a> [virtual\_network\_id](#input\_virtual\_network\_id) | The id of the virtual network to which to attach the DNS resolver. Changing this forces a new resource to be created. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The Private DNS Resolver Virtual Network Link ID. |
<!-- END_TF_DOCS -->