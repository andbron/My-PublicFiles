# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2024-03-19]

### Changed

-Transform policy_set_initiative_parameters in test example to align with other policy assignment modules

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
