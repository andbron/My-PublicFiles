# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-06-30]

### Changed

- Updated output.tf to output id of Proximity Placement Group
- Removed lifecycle block

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
