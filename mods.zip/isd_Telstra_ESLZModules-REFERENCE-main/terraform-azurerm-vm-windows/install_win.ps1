param
(
    [string]
    $splunk_params,
    [string]
    $newrelic_proxy,
    [string]
    $newrelic_key,
    [string]
    $client_ip_win,
    [string]
    $client_name
)

Configuration BaseLineConfiguration_config
{
    param
    (
        [string]
        $splunk_params,
        [string]
        $newrelic_proxy,
        [string]
        $newrelic_key,
        [string]
        $client_ip_win,
        [string]
        $client_name
    )

   
    Import-DscResource –ModuleName PSDesiredStateConfiguration
    

    Node Localhost
    {
                  
     
  

        #--------------------install Splunk --------------------
        Script splunk {
            SetScript  = {
                $arglist = $using:splunk_params
                $arglist = "$($arglist.trim()) splunkforwarder-9.0.2-17e00c557dc1-x64-release.msi"
                 
                Start-Process -FilePath "c:\srcpackages\splunk\splunk-uf-install.bat"  -ArgumentList $arglist  -Wait -NoNewWindow 
               
            }
            TestScript = { 
                
                $false
            }
            GetScript  = { 
            
            }
            
        }

        #--------------------Config Newrelic --------------------
        Script newrelicconfig {
            SetScript  = {
                $proxy = $using:newrelic_proxy
                $proxy = "http://$($proxy.trim())"
                $productkey = $using:newrelic_key
                 
                echo "license_key: $productkey" > "C:\Program Files\New Relic\newrelic-infra\newrelic-infra.yml"
                echo "proxy: $proxy" >> "C:\Program Files\New Relic\newrelic-infra\newrelic-infra.yml"
            }
            TestScript = { 
                
                $false
                
            }
            GetScript  = { 
            
            }
            
        }

        #--------------------Config commvault --------------------
        Script commvaultconfig {
            SetScript  = {
                $clienthostname = $using:client_ip_win
                $clientname = $using:client_name
                $arglist = "-OpType 1000 -CSHost dpscs.in.telstra.com.au -clientname $clientname -clientHostName $clienthostname -overwriteClientInfo ON -restartServices -output C:\srcpackages\commvault\CSRegistration.xml"
                
                # TimeZone Settings 
                Set-TimeZone -Id "AUS Eastern Standard Time"
                

                try {
                Start-Process -FilePath "C:\Program Files\Commvault\contentStore\Base\SIMCallWrapper.exe"  -ArgumentList $arglist  -Wait -NoNewWindow
                }
                catch {
                $commv = $_
                }
                

            }
            TestScript = { 
                
                $false
            }
            GetScript  = { 
            
            }
            
        }
        
        #-------------------- Post fix  --------------------
        Script postfix {
            SetScript  = {
            
                try {
                    Set-ItemProperty -Path "HKLM:\SOFTWARE\CommVault Systems\Galaxy\Instance001\Machines\$($env:COMPUTERNAME)" -Name 'sHOSTNAME' -Value "$($env:COMPUTERNAME)"
                    $user = Get-WmiObject Win32_UserAccount -Filter "Name='Guest'"
                    $result = $user.Rename('TelstraGuser')
                }
                catch {
                    $cleanup = $_
                }


            }
            TestScript = { 

                $false
                        
            }
            GetScript  = { 
                    
            }
            
                    
        }

        #-------------------- Cleanup  --------------------
        Script cleanup {
            SetScript  = {
            
            try{
            Remove-Item -Path "C:\srcpackages\" -Recurse -Force -Verbose -ErrorAction SilentlyContinue
            }
            catch {
            $cleanup = $_
            }


            }
            TestScript = { 

                return (!(test-path "C:\srcpackages"))
                        
            }
            GetScript  = { 
                    
            }
            
                    
        }
        
    }

       
}  

winrm quickconfig -quiet
Start-Sleep -Seconds 60
Set-Location -Path "C:\Packages" 

if((Test-Path -Path 'C:\srcpackages\') -eq $true ){
BaseLineConfiguration_config -splunk_params $splunk_params -newrelic_proxy $newrelic_proxy -newrelic_key $newrelic_key -client_ip_win $client_ip_win -client_name $client_name 
Start-DscConfiguration -Path "C:\Packages\BaseLineConfiguration_config" -Wait -Verbose -Force 

}
else {
  
}
