# CHANGELOG (aligned to versions.tf)
## [1.0.13] - [2023-12-01]
### Added

- Added Secure boot setting and vTPM security setting.This needs VM image upgrade to Gen2

## [1.0.12] - [2023-11-20]
### Fixed

- Fix tag inheritance for child modules via AzApi
- Fix tag inheritance for extensions
- Deny public endpoint for managed disk (OS) via AzApi

## [1.0.11] - [2023-10-18]
### Added

- Added validation for licence type to be Hybrid

## [1.0.10] - [2023-9-28]
### Added

- Added ip_config_name as output

### Changed

- Remove the vm diagnostic extention

## [1.0.9] - [2023-08-02]

### Added

- Added zone as an export attribute required to link any managed disks attached to this VM

## [1.0.8] - [2023-06-21]

### Added

- Added encryption_at_host_enabled variable

## [1.0.7] - [2023-06-21]

### Added

- Adding proximity_placement_group_id variable

### Changed

## [1.0.6] - [2023-06-30]

- Removed lifecycle block to allow for updates for tags.
- Aligned outputs.
- Retained module version.

## [1.0.6] - [2023-04-03]

### Added

- windows app config extension and required variables.

## [1.0.5] - [2023-03-31]

### Fixed

- fixed the Outputs of the module.

## [1.0.4] - [2023-03-30]

### Added

- Updated nic ip configuration primary value to 'true'.
- Made source image id mandatory.

## [1.0.3] - [2023-02-21]

### Added

- Added Identity Type as paremeter so that UserAssigned identity can also be enabled.

## [1.0.2] - [2023-01-19]

### Added

- Added diagnostics extension code to enable the diagnostics settings.

## [1.0.1] - [2022-12-07]

### Added

- Added skip_kv_secert_add variable for fixing module pipeline

### Fixed

- OS disk name is replace with ${var.virtual_machine_name}-vol01 instead of earlier name format

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
