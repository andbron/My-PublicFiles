# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.2] - [2023-05-25]

### Added

- Netwrok rules sets
- key vault key
- Role assignment
- customer managed key

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
