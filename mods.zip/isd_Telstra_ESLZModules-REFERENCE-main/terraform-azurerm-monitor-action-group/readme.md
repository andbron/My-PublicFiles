<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_action_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_name"></a> [action\_group\_name](#input\_action\_group\_name) | The name of the Action Group. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_action_group_short_name"></a> [action\_group\_short\_name](#input\_action\_group\_short\_name) | The short name of the action group. This will be used in SMS messages. | `string` | n/a | yes |
| <a name="input_armrolereceivers"></a> [armrolereceivers](#input\_armrolereceivers) | List of arm role receivers.<br><br>   name - (Required) The name of the ARM role receiver.<br><br>   role\_id - (Required) The arm role id.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    role_id                 = string<br>    use_common_alert_schema = bool<br>  }))</pre> | `{}` | no |
| <a name="input_automationrunbookreceivers"></a> [automationrunbookreceivers](#input\_automationrunbookreceivers) | List of automation run book receivers.<br><br>   name - (Required) The name of the automation runbook receiver.<br><br>   automation\_account\_id - (Required) The automation account ID which holds this runbook and authenticates to Azure resources.<br><br>   runbook\_name - (Required) The name for this runbook.<br><br>   webhook\_resource\_id - (Required) The resource id for webhook linked to this runbook.<br><br>   is\_global\_runbook - (Required) Indicates whether this instance is global runbook.<br><br>   service\_uri - (Required) The URI where webhooks should be sent.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    automation_account_id   = string<br>    runbook_name            = string<br>    webhook_resource_id     = string<br>    is_global_runbook       = bool<br>    service_uri             = string<br>    use_common_alert_schema = bool<br>  }))</pre> | `{}` | no |
| <a name="input_azureapppushreceivers"></a> [azureapppushreceivers](#input\_azureapppushreceivers) | List of azure app pusher receivers.<br><br>   name - (Required) The name of the Azure app push receiver.<br><br>   email\_address - (Required) The email address of the user signed into the mobile app who will receive push notifications <br>   from this receiver. | <pre>map(object({<br>    name          = string<br>    email_address = string<br>  }))</pre> | `{}` | no |
| <a name="input_azurefunctionreceivers"></a> [azurefunctionreceivers](#input\_azurefunctionreceivers) | List of azure function app receivers.<br><br>   name - (Required) The name of the Azure Function receiver.<br><br>   function\_app\_resource\_id - (Required) The Azure resource ID of the function app.<br><br>   function\_name - (Required) The function name in the function app.<br><br>   http\_trigger\_url - (Required) The HTTP trigger url where HTTP request sent to.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                     = string<br>    function_app_resource_id = string<br>    function_name            = string<br>    http_trigger_url         = string<br>    use_common_alert_schema  = bool<br>  }))</pre> | `{}` | no |
| <a name="input_emailreceivers"></a> [emailreceivers](#input\_emailreceivers) | List of email receivers.<br><br>   name - (Required) The name of the email receiver. Names must be unique (case-insensitive) across all <br>   receivers within an action group.<br><br>   email\_address - (Required) The email address of this receiver.<br><br>   use\_common\_alert\_schema- (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    email_address           = string<br>    use_common_alert_schema = bool<br>  }))</pre> | `{}` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Whether this action group is enabled. If an action group is not enabled, then none of its receivers will receive communications. | `bool` | `true` | no |
| <a name="input_eventhubreceivers"></a> [eventhubreceivers](#input\_eventhubreceivers) | List of azure function app receivers.<br><br>   name - (Required) The name of the EventHub Receiver, must be unique within action group.<br><br>   event\_hub\_name - (Optional) The name of the specific Event Hub queue.<br>   function\_name - (Required) The function name in the function app.<br><br>   http\_trigger\_url - (Required) The HTTP trigger url where HTTP request sent to.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    subscription_id         = string<br>    event_hub_name          = string<br>    event_hub_namespace     = string<br>    tenant_id               = string<br>    use_common_alert_schema = bool<br>  }))</pre> | `{}` | no |
| <a name="input_itsmreceivers"></a> [itsmreceivers](#input\_itsmreceivers) | List of itsm receivers.<br><br>   name - (Required) The name of the ITSM receiver.<br><br>   workspace\_id - (Required) The Azure Log Analytics workspace ID where this connection is defined. Format is <br>   <subscription id>\|<workspace id>, for example 00000000-0000-0000-0000-000000000000\|00000000-0000-0000-0000-000000000000.<br><br>   connection\_id - (Required) The unique connection identifier of the ITSM connection.<br><br>   ticket\_configuration - (Required) A JSON blob for the configurations of the ITSM action. CreateMultipleWorkItems option will <br>   be part of this blob as well. ticket\_configuration should be JSON blob with PayloadRevision and WorkItemType keys <br>   (e.g., ticket\_configuration="{\"PayloadRevision\":0,\"WorkItemType\":\"Incident\"}")<br><br>   region - (Required) The region of the workspace. | <pre>map(object({<br>    name                 = string<br>    workspace_id         = string<br>    connection_id        = string<br>    ticket_configuration = string<br>    region               = string<br>  }))</pre> | `{}` | no |
| <a name="input_logicappreceivers"></a> [logicappreceivers](#input\_logicappreceivers) | List of logic application receivers.<br><br>   name - (Required) The name of the logic app receiver.<br><br>   resource\_id - (Required) The Azure resource ID of the logic app.<br><br>   callback\_url - (Required) The callback url where HTTP request sent to.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema. | <pre>map(object({<br>    name                    = string<br>    resource_id             = string<br>    callback_url            = string<br>    use_common_alert_schema = bool<br>  }))</pre> | `{}` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the action group. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_smsreceivers"></a> [smsreceivers](#input\_smsreceivers) | List of sms receivers.<br><br>   name - (Required) The name of the SMS receiver. Names must be unique (case-insensitive) across all receivers within an action group.<br><br>   country\_code - (Required) The country code of the SMS receiver.<br><br>   phone\_number - (Required) The phone number of the SMS receiver. | <pre>map(object({<br>    name         = string<br>    country_code = string<br>    phone_number = string<br>  }))</pre> | `{}` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |
| <a name="input_voicereceivers"></a> [voicereceivers](#input\_voicereceivers) | List of voice/phone receivers.<br><br>   name - (Required) The name of the voice receiver.<br><br>   country\_code - (Required) The country code of the voice receiver.<br><br>   phone\_number - (Required) The phone number of the voice receiver. | <pre>map(object({<br>    name         = string<br>    country_code = string<br>    phone_number = string<br>  }))</pre> | `{}` | no |
| <a name="input_webhookreceivers"></a> [webhookreceivers](#input\_webhookreceivers) | List of webhook receivers.<br><br>   name - (Required) The name of the webhook receiver. Names must be unique (case-insensitive) across all<br>   receivers within an action group.<br><br>   service\_uri - (Required) The URI where webhooks should be sent.<br><br>   use\_common\_alert\_schema - (Optional) Enables or disables the common alert schema.<br><br>   The aad\_auth block supports the following:.<br><br>   object\_id - (Required) The webhook application object Id for AAD auth.<br><br>   identifier\_uri - (Optional) The identifier URI for AAD auth.<br><br>   tenant\_id - (Optional) The tenant id for AAD auth. | <pre>map(object({<br>    name                    = string<br>    service_uri             = string<br>    use_common_alert_schema = string<br>    aad_auth = object({<br>      object_id      = string<br>      identifier_uri = string<br>      tenant_id      = string<br>    })<br>  }))</pre> | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_action_group_id"></a> [action\_group\_id](#output\_action\_group\_id) | The ID of the created action group. |
<!-- END_TF_DOCS -->
