#!/bin/bash

#TODO: Move this script to some other place, somewhere outside of https://dev.azure.com/9025-CICD/ESLZ%20Modules project

set -o errexit

exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

# Let the server breathe a little after starting up, otherwise DNS issues crops up (randomly)
sleep 60

# Pre-Install
rm -rf /tmp/bootstrap_vars.yml /tmp/bootstrap

# Ansible Variables
cat > /tmp/bootstrap_vars.yml << "EOF"
---
splunk_targeturi: ${splunk_targeturi}
telstra_dns: ${telstra_dns}
network: ${network}
env: ${env}
appname: ${appname}
computername: ${computername}
key: ${key}
newrelic_proxy: ${newrelic_proxy}
proxy_url: ${proxy_url}
server_url: ${server_url}
vers: ${vers}
pool_name: ${pool_name}
EOF

# Clone the git repository that contains ansible playbooks
https_proxy=${proxy_url} git clone --branch main https://${pat_token}@dev.azure.com/9025-CICD/ESLZ%20Platform/_git/platform /tmp/bootstrap && \
    cd /tmp/bootstrap/deployments/pools/playbooks && \
    ansible-playbook --extra-vars "@/tmp/bootstrap_vars.yml" ado_agent_bootstrap.yml -e pat_token=${pat_token} -v

rm -rf /tmp/bootstrap_vars.yml /tmp/bootstrap/

