#!/bin/bash

# This script is created for the specific golden images, that have the required applications configured or present.

## Newrelic config part ##
    if grep -q "${key}" "/etc/newrelic-infra.yml"; then
        echo "Newrelic already configured"
    else
        echo "license_key: ${key}" > /etc/newrelic-infra.yml
        echo "proxy: http://${newrelic_proxy}" >> /etc/newrelic-infra.yml
    fi
## Newrelic config part ends##

## DNS Config ##

sudo echo -e "DNS=${telstra_dns}\nFallbackDNS=168.63.129.16\n" >> /etc/systemd/resolved.conf
sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf
sudo service systemd-resolved restart 1> /dev/null 2> /dev/null

## DNS Config ends ##

## Splunk Installation and config part ##

    # Get the os name
    os_name=$(cat /etc/os-release | grep -w NAME | cut -d= -f2 | tr -d '"')
    service_status=$(systemctl is-active SplunkForwarder)
    if [ "$service_status" != "running" ]; then
    # Check if the os is ubuntu or rhel
    if [ "$os_name" == "Red Hat Enterprise Linux Server" ]; then
        yum install /home/linux-soe/splunkforwarder-9.0.2-17e00c557dc1-linux-2.6-x86_64.rpm -y

    else
        tar -xvzf /home/splunk/splunk/splunk-linux.tar -C /home/splunk/
        dpkg -i /home/splunk/splunkforwarder-9.0.3-dd0128b1f8cd-linux-2.6-amd64.deb
    fi

    # Common splunk config part
    mkdir -p /opt/splunkforwarder/etc/apps/onesplunk_ds/local

    echo "[target-broker:deploymentServer]" > /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "targetUri = ${splunk_targeturi}" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "[deployment-client]" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "clientName = OneSplunk-UF-${network}-${env}-${appname}-${computername}" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf

    bash -c '/opt/splunkforwarder/bin/splunk enable boot-start -systemd-managed 1 -user splunk --accept-license --answer-yes --auto-ports --no-prompt'

    chown  -R splunk:splunk /opt/splunkforwarder/

    systemctl start SplunkForwarder

    else
        echo "Splunk already configured"
    fi

    # Splunk log rotate config part
    if [ "$os_name" == "Red Hat Enterprise Linux Server" ]; then
        cat << EOF > /etc/logrotate.d/Splunk_syslogs_permissions
/var/log/waagent.log
/var/log/messages
/var/log/dmesg
/var/log/secure
/var/log/audit/audit.log
{
      weekly
      maxsize 100M
      su root root
      rotate 4
      create 0640 root root
      dateext
      compress
      postrotate
            /usr/bin/setfacl -m g:splunk:r /var/log/waagent.log
            /usr/bin/setfacl -m g:splunk:r /var/log/messages
            /usr/bin/setfacl -m g:splunk:r /var/log/dmesg
            /usr/bin/setfacl -m g:splunk:r /var/log/secure
            /usr/bin/setfacl -m g:splunk:r /var/log/audit/audit.log
      endscript
}
EOF
        sudo logrotate -vf Splunk_syslogs_permissions
    else
        cat << EOF > /etc/logrotate.d/Splunk_syslogs_permissions
/var/log/syslog
/var/log/auth.log
/var/log/kern.log
/var/log/waagent.log
/var/log/audit/audit.log
{
    weekly
    maxsize 100M
    su root adm
    rotate 4
    create 0640 root  adm
    dateext
    compress
    postrotate
            /usr/bin/setfacl -m g:splunk:r /var/log/syslog
            /usr/bin/setfacl -m g:splunk:r /var/log/auth.log
            /usr/bin/setfacl -m g:splunk:r /var/log/kern.log
            /usr/bin/setfacl -m g:splunk:r /var/log/waagent.log
            /usr/bin/setfacl -m g:splunk:r /var/log/audit/audit.log
    endscript
}
EOF
        sudo logrotate -vf Splunk_syslogs_permissions
    fi
    
## Splunk Installation and config part ends ##


## Config commvault ##
    commcheck=$(simpana status | grep "CommServe Host Name = 10.75.1.50")
    if [$commcheck = "CommServe Host Name = 10.75.1.50"]; then
        echo "commvault registration already completed"
    else
        bash -c '/opt/app/commvault/Base/SIMCallWrapper -OpType 1000 -CSHost 10.75.1.50 -clientname ${clientname} -clientHostName ${clientname} -overwriteClientInfo ON -restartServices -output /home/CSRegistration.xml'
    fi
## Config commvault ends ##


## cleanup part ##
    # This will remove all the files and folders which are not needed
    for file in "/home/rhel7securitybaseline.py" "/home/securitycheck.py" "/tmp/sshd_banner" "/home/linux-soe"; do
        if [ -e "$file" ]; then

            rm -rf "$file"
            #echo "Removed $file"
        else
            echo "$file does not exist or removed previously"
        fi
    done

## cleanup part ends ##
