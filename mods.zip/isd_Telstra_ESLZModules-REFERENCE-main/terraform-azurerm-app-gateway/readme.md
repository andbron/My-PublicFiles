<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | 2.30.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | 2.30.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_application_gateway.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_gateway) | resource |
| [azurerm_key_vault_access_policy.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_user_assigned_identity.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/2.30.0/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_gateway_name"></a> [application\_gateway\_name](#input\_application\_gateway\_name) | The name of the Application Gateway. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_autoscale_configuration"></a> [autoscale\_configuration](#input\_autoscale\_configuration) | Minimum or Maximum capacity for autoscaling. Accepted values are for Minimum in the range 0 to 100 and for Maximum in the range 2 to 125 | <pre>object({<br>    min_capacity = number<br>    max_capacity = number<br>  })</pre> | `null` | no |
| <a name="input_backend_address_pools"></a> [backend\_address\_pools](#input\_backend\_address\_pools) | List of backend address pools | <pre>map(object({<br>    name         = string<br>    fqdns        = list(string)<br>    ip_addresses = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_backend_http_settings"></a> [backend\_http\_settings](#input\_backend\_http\_settings) | List of backend HTTP settings. | <pre>map(object({<br>    name                                = string<br>    cookie_based_affinity               = string<br>    affinity_cookie_name                = string<br>    path                                = string<br>    enable_https                        = bool<br>    probe_name                          = string<br>    request_timeout                     = number<br>    host_name                           = string<br>    pick_host_name_from_backend_address = bool<br>  }))</pre> | n/a | yes |
| <a name="input_client_auth_certificate"></a> [client\_auth\_certificate](#input\_client\_auth\_certificate) | The base-64 encoded certificate. | `string` | n/a | yes |
| <a name="input_enable_http2"></a> [enable\_http2](#input\_enable\_http2) | Is HTTP2 enabled on the application gateway resource? | `bool` | `false` | no |
| <a name="input_firewall_policy_id"></a> [firewall\_policy\_id](#input\_firewall\_policy\_id) | The ID of the Web Application Firewall Policy. | `string` | n/a | yes |
| <a name="input_frontend_ip_configurations"></a> [frontend\_ip\_configurations](#input\_frontend\_ip\_configurations) | The list of Frontend IP configuration | <pre>map(object({<br>    name                          = string<br>    subnet_id                     = string<br>    private_ip_address            = string<br>    private_ip_address_allocation = string<br>  }))</pre> | n/a | yes |
| <a name="input_frontend_ports"></a> [frontend\_ports](#input\_frontend\_ports) | The name used for this Frontend Port. | <pre>map(object({<br>    name = string<br>  }))</pre> | n/a | yes |
| <a name="input_gateway_ip_configuration_subnet_id"></a> [gateway\_ip\_configuration\_subnet\_id](#input\_gateway\_ip\_configuration\_subnet\_id) | The ID of the Subnet which the Application Gateway should be connected to. | `string` | n/a | yes |
| <a name="input_health_probes"></a> [health\_probes](#input\_health\_probes) | List of Health probes used to test backend pools health. | <pre>map(object({<br>    name                                      = string<br>    host                                      = string<br>    interval                                  = number<br>    path                                      = string<br>    timeout                                   = number<br>    unhealthy_threshold                       = number<br>    port                                      = number<br>    protocol                                  = string<br>    pick_host_name_from_backend_http_settings = bool<br>    match = object({<br>      body        = string<br>      status_code = list(string)<br>    })<br>  }))</pre> | n/a | yes |
| <a name="input_http_listener"></a> [http\_listener](#input\_http\_listener) | List of  HTTP listener settings. | <pre>map(object({<br>    name                           = string<br>    frontend_ip_configuration_name = string<br>    frontend_port_name             = string<br>    host_name                      = string<br>    host_names                     = list(string)<br>    require_sni                    = bool<br>    ssl_profile_name               = string<br>  }))</pre> | n/a | yes |
| <a name="input_key_vault_id"></a> [key\_vault\_id](#input\_key\_vault\_id) | The ID of key vault | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure region where the Application Gateway should exist. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_public_ip_address_id"></a> [public\_ip\_address\_id](#input\_public\_ip\_address\_id) | The ID of a Public IP Address which the Application Gateway should use. | `string` | n/a | yes |
| <a name="input_public_ip_address_name"></a> [public\_ip\_address\_name](#input\_public\_ip\_address\_name) | The name of Public IP. | `string` | n/a | yes |
| <a name="input_request_routing_rules"></a> [request\_routing\_rules](#input\_request\_routing\_rules) | List of Request routing rules to be used for listeners. | <pre>map(object({<br>    name                       = string<br>    rule_type                  = string<br>    http_listener_name         = string<br>    backend_http_settings_name = string<br>    backend_address_pool_name  = string<br>    url_path_map_name          = string<br>    priority                   = number<br>  }))</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to the Application Gateway should exist. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_sku_capacity"></a> [sku\_capacity](#input\_sku\_capacity) | The Capacity of the SKU to use for this Application Gateway. When using a V1 SKU this value must be between 1 and 32, and 1 to 125 for a V2 SKU. This property is optional if autoscale\_configuration is set. | `string` | `"2"` | no |
| <a name="input_ssl_certificate_id"></a> [ssl\_certificate\_id](#input\_ssl\_certificate\_id) | The id of the SSL certificate that the App Gateway will use. | `string` | n/a | yes |
| <a name="input_ssl_certificate_name"></a> [ssl\_certificate\_name](#input\_ssl\_certificate\_name) | The name of the SSL certificate that the App Gateway will use. | `string` | n/a | yes |
| <a name="input_ssl_profiles"></a> [ssl\_profiles](#input\_ssl\_profiles) | List of SSL profile configuration | <pre>map(object({<br>    name                             = string<br>    trusted_client_certificate_names = list(string)<br>    verify_client_cert_issuer_dn     = string<br>    ssl_policy = object({<br>      policy_name = string<br>    })<br>  }))</pre> | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |
| <a name="input_trusted_client_certificate_name"></a> [trusted\_client\_certificate\_name](#input\_trusted\_client\_certificate\_name) | The name of the Trusted Client Certificate that is unique within this Application Gateway. | `string` | n/a | yes |
| <a name="input_user_assigned_identity_name"></a> [user\_assigned\_identity\_name](#input\_user\_assigned\_identity\_name) | Specifies the name of this User Assigned Identity. | `string` | n/a | yes |
| <a name="input_zones"></a> [zones](#input\_zones) | A collection of availability zones to spread the Application Gateway over. | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the App Gateway |
| <a name="output_name"></a> [name](#output\_name) | The name of the App Gateway |
| <a name="output_user_assigned_identity_id"></a> [user\_assigned\_identity\_id](#output\_user\_assigned\_identity\_id) | The ID of the User Assigned Identity |
<!-- END_TF_DOCS -->

## Notes
- To use a certificate from a Keyvault behind a Network it's necessary to configure a service endpoint to the keyvault because it is not able to resolve the private endpoint when the AppGateway is being created. For more details, check [How the integration works](https://docs.microsoft.com/en-us/azure/application-gateway/key-vault-certs#how-integration-works).
- To get more details on how the integration with APIM works, check [this document](https://docs.microsoft.com/en-us/azure/api-management/api-management-howto-integrate-internal-vnet-appgateway).
