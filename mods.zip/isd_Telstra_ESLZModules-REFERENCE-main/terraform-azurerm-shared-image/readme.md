<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_shared_image.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/shared_image) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_accelerated_network_support_enabled"></a> [accelerated\_network\_support\_enabled](#input\_accelerated\_network\_support\_enabled) | Specifies if the Shared Image supports Accelerated Network | `bool` | `false` | no |
| <a name="input_architecture"></a> [architecture](#input\_architecture) | The CPU architecture supported by an OS. | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | A description for the Shared Image. | `string` | n/a | yes |
| <a name="input_disk_types_not_allowed"></a> [disk\_types\_not\_allowed](#input\_disk\_types\_not\_allowed) | One or more Disk Types not allowed for the Image | `list(string)` | `null` | no |
| <a name="input_end_of_life_date"></a> [end\_of\_life\_date](#input\_end\_of\_life\_date) | The end of life date in RFC3339 format of the Image | `string` | `null` | no |
| <a name="input_eula"></a> [eula](#input\_eula) | The End User Licence Agreement for the Shared Image | `string` | `null` | no |
| <a name="input_hyper_v_generation"></a> [hyper\_v\_generation](#input\_hyper\_v\_generation) | The generation of HyperV of the Virtual Machine | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The region where the resource will be deployed. | `string` | n/a | yes |
| <a name="input_offer"></a> [offer](#input\_offer) | The Offer Name for the Shared Image. | `string` | n/a | yes |
| <a name="input_os_type"></a> [os\_type](#input\_os\_type) | The type of Operating System present in this Shared Image. Possible values are Linux and Windows. | `string` | n/a | yes |
| <a name="input_publisher"></a> [publisher](#input\_publisher) | The Publisher Name for the Gallery Image. | `string` | n/a | yes |
| <a name="input_release_note_uri"></a> [release\_note\_uri](#input\_release\_note\_uri) | The URI containing the Release Notes associated with this Shared Image | `string` | `null` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of Resources Group | `string` | n/a | yes |
| <a name="input_shared_image_gallery_name"></a> [shared\_image\_gallery\_name](#input\_shared\_image\_gallery\_name) | Specifies the name of the Shared Image Gallery. | `string` | n/a | yes |
| <a name="input_shared_image_name"></a> [shared\_image\_name](#input\_shared\_image\_name) | Specifies the name of the image definition. | `string` | n/a | yes |
| <a name="input_sku"></a> [sku](#input\_sku) | The Name of the SKU for the Gallery Image. | `string` | n/a | yes |
| <a name="input_specialized"></a> [specialized](#input\_specialized) | Specifies that the Operating System used inside this Image has not been Generalized | `bool` | `false` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags of the Shared Image Gallery. | `map(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The Shared Image id. |
<!-- END_TF_DOCS -->
