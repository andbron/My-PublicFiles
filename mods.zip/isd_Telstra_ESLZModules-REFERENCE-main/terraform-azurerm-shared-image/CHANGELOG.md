# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-06-01]
### Changed
* Removed the lifecycle rule to ignore tags
* Added Telstra specific tags

## [1.0.1] - [yyyy-mm-dd]

### Added
* Initialization

### Added
### Changed
### Fixed
### Features
