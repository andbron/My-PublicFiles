# CHANGELOG (aligned to versions.tf)
## [1.0.2] -[2023-11-13]
## Changed
- Updated certificate validity to take default expiry to 12
-updated examples/main.tf to remove KV creation and use existing KV

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
