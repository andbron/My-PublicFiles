<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_certificate.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_certificate) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_certificate_name"></a> [certificate\_name](#input\_certificate\_name) | The name of the certificate. | `string` | n/a | yes |
| <a name="input_certificate_policy_issuer_parameters_name"></a> [certificate\_policy\_issuer\_parameters\_name](#input\_certificate\_policy\_issuer\_parameters\_name) | The name of the Certificate Issuer. Possible values include Self (for self-signed certificate), or Unknown (for a certificate issuing authority like Let's Encrypt and Azure direct supported ones). | `string` | n/a | yes |
| <a name="input_key_properties_exportable"></a> [key\_properties\_exportable](#input\_key\_properties\_exportable) | Determines if the Key is exportable. | `bool` | n/a | yes |
| <a name="input_key_properties_key_size"></a> [key\_properties\_key\_size](#input\_key\_properties\_key\_size) | The size of the Key used in the Certificate. Possible values include 2048, 3072, and 4096. | `number` | n/a | yes |
| <a name="input_key_properties_key_type"></a> [key\_properties\_key\_type](#input\_key\_properties\_key\_type) | Specifies the Type of Key, such as RSA,EC. | `string` | n/a | yes |
| <a name="input_key_properties_reuse_key"></a> [key\_properties\_reuse\_key](#input\_key\_properties\_reuse\_key) | Determines if the Key is reusable. | `bool` | n/a | yes |
| <a name="input_key_vault_id"></a> [key\_vault\_id](#input\_key\_vault\_id) | The id of the Key Vault. | `string` | n/a | yes |
| <a name="input_lifetime_action_action_type"></a> [lifetime\_action\_action\_type](#input\_lifetime\_action\_action\_type) | The Type of action to be performed when the lifetime trigger is triggered. Possible values include AutoRenew and EmailContacts. | `string` | n/a | yes |
| <a name="input_lifetime_action_trigger_days_before_expiry"></a> [lifetime\_action\_trigger\_days\_before\_expiry](#input\_lifetime\_action\_trigger\_days\_before\_expiry) | The number of days before the Certificate expires that the action associated with this Trigger should run. | `number` | n/a | yes |
| <a name="input_secret_properties_content_type"></a> [secret\_properties\_content\_type](#input\_secret\_properties\_content\_type) | The Content-Type of the Certificate, such as application/x-pkcs12 for a PFX or application/x-pem-file for a PEM. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `map(string)` | `null` | no |
| <a name="input_x509_certificate_properties_extended_key_usage"></a> [x509\_certificate\_properties\_extended\_key\_usage](#input\_x509\_certificate\_properties\_extended\_key\_usage) | A list of Extended/Enhanced Key Usages. | `list(string)` | n/a | yes |
| <a name="input_x509_certificate_properties_key_usage"></a> [x509\_certificate\_properties\_key\_usage](#input\_x509\_certificate\_properties\_key\_usage) | A list of uses associated with this Key. Possible values include cRLSign, dataEncipherment, decipherOnly, digitalSignature, encipherOnly, keyAgreement, keyCertSign, keyEncipherment and nonRepudiation and are case-sensitive. | `list(string)` | n/a | yes |
| <a name="input_x509_certificate_properties_subject"></a> [x509\_certificate\_properties\_subject](#input\_x509\_certificate\_properties\_subject) | The Certificate's Subject. | `string` | n/a | yes |
| <a name="input_x509_certificate_properties_subject_alternative_names_dns_names"></a> [x509\_certificate\_properties\_subject\_alternative\_names\_dns\_names](#input\_x509\_certificate\_properties\_subject\_alternative\_names\_dns\_names) | A list of alternative DNS names (FQDNs) identified by the Certificate. | `list(string)` | n/a | yes |
| <a name="input_x509_certificate_properties_validity_in_months"></a> [x509\_certificate\_properties\_validity\_in\_months](#input\_x509\_certificate\_properties\_validity\_in\_months) | The Certificates Validity Period in Months. | `number` | `12` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_certificate_data"></a> [certificate\_data](#output\_certificate\_data) | The raw Key Vault Certificate data represented as a hexadecimal string. |
| <a name="output_certificate_data_base64"></a> [certificate\_data\_base64](#output\_certificate\_data\_base64) | The Base64 encoded Key Vault Certificate data |
| <a name="output_id"></a> [id](#output\_id) | The Key Vault Certificate ID. |
| <a name="output_name"></a> [name](#output\_name) | The Key Vault Certificate Name. |
| <a name="output_secret_id"></a> [secret\_id](#output\_secret\_id) | The ID of the associated Key Vault Secret. |
| <a name="output_thumbprint"></a> [thumbprint](#output\_thumbprint) | The X509 Thumbprint of the Key Vault Certificate represented as a hexadecimal string. |
| <a name="output_version"></a> [version](#output\_version) | The current version of the Key Vault Certificate. |
| <a name="output_versionless_id"></a> [versionless\_id](#output\_versionless\_id) | The Base ID of the Key Vault Certificate. |
| <a name="output_versionless_secret_id"></a> [versionless\_secret\_id](#output\_versionless\_secret\_id) | The Base ID of the Key Vault Secret. |
<!-- END_TF_DOCS -->