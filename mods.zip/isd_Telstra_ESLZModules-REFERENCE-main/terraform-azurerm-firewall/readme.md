<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall) | resource |
| [azurerm_firewall_policy.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy) | resource |
| [azurerm_public_ip.firewall](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_base_policy_id"></a> [base\_policy\_id](#input\_base\_policy\_id) | The ID of the Parent -or Base- Firewall Policy for this Firewall Policy. | `string` | `null` | no |
| <a name="input_default_log_analytics_workspace_id"></a> [default\_log\_analytics\_workspace\_id](#input\_default\_log\_analytics\_workspace\_id) | Is firewall policy insights enabled. | `string` | `null` | no |
| <a name="input_dns_proxy_enabled"></a> [dns\_proxy\_enabled](#input\_dns\_proxy\_enabled) | Set to `true` it sets DNS Enabled with DNS Proxy Enabled. | `bool` | `false` | no |
| <a name="input_dns_servers"></a> [dns\_servers](#input\_dns\_servers) | A list of DNS servers that the Azure Firewall will direct DNS traffic to the for name resolution. | `list(string)` | `null` | no |
| <a name="input_enable_insights"></a> [enable\_insights](#input\_enable\_insights) | Is firewall policy insights enabled. | `bool` | `false` | no |
| <a name="input_enable_intrusion_detection"></a> [enable\_intrusion\_detection](#input\_enable\_intrusion\_detection) | Is firewall policy insights enabled. | `bool` | `true` | no |
| <a name="input_enable_management_ip"></a> [enable\_management\_ip](#input\_enable\_management\_ip) | Is management IP configuration required. | `bool` | `true` | no |
| <a name="input_firewall_name"></a> [firewall\_name](#input\_firewall\_name) | Specifies the name of the Firewall. | `string` | n/a | yes |
| <a name="input_firewall_policy_name"></a> [firewall\_policy\_name](#input\_firewall\_policy\_name) | The name which should be used for this Firewall Policy. | `string` | n/a | yes |
| <a name="input_firewall_policy_sku"></a> [firewall\_policy\_sku](#input\_firewall\_policy\_sku) | The SKU Tier of the Firewall Policy. Possible values are Standard, Premium and Basic. | `string` | `"Premium"` | no |
| <a name="input_firewall_public_ip_count"></a> [firewall\_public\_ip\_count](#input\_firewall\_public\_ip\_count) | Optional. The number of Public IP Addresses associated with the firewall. | `number` | `1` | no |
| <a name="input_firewall_public_ip_name_prefix"></a> [firewall\_public\_ip\_name\_prefix](#input\_firewall\_public\_ip\_name\_prefix) | The Public IP Address name prefix. | `string` | `"tcg-dvae-plz-pip10"` | no |
| <a name="input_firewall_sku_name"></a> [firewall\_sku\_name](#input\_firewall\_sku\_name) | Sku Name of the Firewall. Possible values are `AZFW_Hub` and `AZFW_VNet`. | `string` | `"AZFW_VNet"` | no |
| <a name="input_firewall_sku_tier"></a> [firewall\_sku\_tier](#input\_firewall\_sku\_tier) | Sku Tier of the Firewall. Possible values are `Premium` and `Standard`. | `string` | `"Premium"` | no |
| <a name="input_intrusion_detection_mode"></a> [intrusion\_detection\_mode](#input\_intrusion\_detection\_mode) | The mode of the Threat Intelligence. Possible values are Alert, Deny and Off. | `string` | `"Alert"` | no |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. | `string` | n/a | yes |
| <a name="input_management_public_ip_address_id"></a> [management\_public\_ip\_address\_id](#input\_management\_public\_ip\_address\_id) | The ID of the Public IP Address associated with the firewall | `string` | `""` | no |
| <a name="input_management_subnet_id"></a> [management\_subnet\_id](#input\_management\_subnet\_id) | Reference to the subnet associated with the Management IP Configuration. | `string` | `""` | no |
| <a name="input_private_ip_ranges"></a> [private\_ip\_ranges](#input\_private\_ip\_ranges) | A list of private IP ranges to which traffic will not be SNAT. | `list(string)` | n/a | yes |
| <a name="input_public_ip_address_id"></a> [public\_ip\_address\_id](#input\_public\_ip\_address\_id) | Optional. The ID of the Public IP Address associated with the firewall. | `string` | `""` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the Firewall. | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | Reference to the subnet associated with the IP Configuration. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the Firewall. | `map(string)` | `null` | no |
| <a name="input_threat_intelligence_mode"></a> [threat\_intelligence\_mode](#input\_threat\_intelligence\_mode) | The mode of the Threat Intelligence. Possible values are Alert, Deny and Off. | `string` | `"Alert"` | no |
| <a name="input_zones"></a> [zones](#input\_zones) | The list of Availability Zones to deploy the Azure Firewall accross. Accepted values are combinations of `1`, `2`, `3`. Example: `["1" ,"2"]`. | `list(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_child_policies"></a> [child\_policies](#output\_child\_policies) | A list of references to child Firewall Policies of the Firewall Policy. |
| <a name="output_firewall_id"></a> [firewall\_id](#output\_firewall\_id) | The ID of created Firewall. |
| <a name="output_id"></a> [id](#output\_id) | The ID of the created Firewall Policy. |
| <a name="output_name"></a> [name](#output\_name) | Name of the Firewall. |
| <a name="output_private_ip_addresses"></a> [private\_ip\_addresses](#output\_private\_ip\_addresses) | Private IP of Firewall. |
<!-- END_TF_DOCS -->
