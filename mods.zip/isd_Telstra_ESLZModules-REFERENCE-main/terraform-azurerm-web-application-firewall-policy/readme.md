<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.42.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_web_application_firewall_policy.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/web_application_firewall_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_custom_rules"></a> [custom\_rules](#input\_custom\_rules) | List of Custom rule Configuration. | <pre>map(object({<br>    name      = string<br>    priority  = number<br>    rule_type = string<br>    action    = string<br>    match_conditions = list(object({<br>      match_variables = list(object({<br>        variable_name = string<br>        selector      = string<br>      }))<br>      operator           = string<br>      negation_condition = bool<br>      match_values       = list(string)<br>      transforms         = list(string)<br>    }))<br>  }))</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_managed_rules"></a> [managed\_rules](#input\_managed\_rules) | List of Managed Rules Configuration | <pre>map(object({<br>    exclusions = list(object({<br>      match_variable          = string<br>      selector                = string<br>      selector_match_operator = string<br>    }))<br>    managed_rule_sets = list(object({<br>      type    = string<br>      version = string<br>      rule_group_overrides = list(object({<br>        rule_group_name = string<br>        rules = list(object({<br>          id      = string<br>          enabled = bool<br>          action  = string<br>        }))<br>      }))<br>    }))<br>  }))</pre> | n/a | yes |
| <a name="input_policy_settings"></a> [policy\_settings](#input\_policy\_settings) | List of policy setting configuration | <pre>object({<br>    enabled                     = bool<br>    mode                        = string<br>    file_upload_limit_in_mb     = number<br>    request_body_check          = bool<br>    max_request_body_size_in_kb = number<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the Key Vault. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |
| <a name="input_web_application_firewall_policy_name"></a> [web\_application\_firewall\_policy\_name](#input\_web\_application\_firewall\_policy\_name) | The name of the policy. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |
<!-- END_TF_DOCS -->
