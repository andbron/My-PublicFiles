# CHANGELOG (aligned to versions.tf)
## [1.0.3] - [2023-06-08]
### Added
- Resource block for Consumer Group

## [1.0.2] - [2023-05-25]
### Added
- Updated code to use dynamic parameters
- Authorization Rule block

## [1.0.1] - [2022-12-22]
### Added

- Initialization
