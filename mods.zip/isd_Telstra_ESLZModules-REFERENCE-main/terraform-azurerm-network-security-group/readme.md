<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_security_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_subnet_network_security_group_association.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. | `string` | n/a | yes |
| <a name="input_network_security_group_name"></a> [network\_security\_group\_name](#input\_network\_security\_group\_name) | Specifies the name of the network security group. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the network security group. | `string` | n/a | yes |
| <a name="input_security_rules"></a> [security\_rules](#input\_security\_rules) | List of objects representing security rules, as defined above. | <pre>map(object({<br>    description                                = string       # A description for this rule. Restricted to 140 characters.<br>    protocol                                   = string       # Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, Esp, Ah or * (which matches all).<br>    direction                                  = string       # The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound.<br>    access                                     = string       # Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny.<br>    priority                                   = number       # Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule.<br>    source_address_prefix                      = string       # CIDR or source IP range or * to match any IP. Tags such as ‘VirtualNetwork’, ‘AzureLoadBalancer’ and ‘Internet’ can also be used. This is required if source_address_prefixes is not specified.<br>    source_address_prefixes                    = list(string) # List of source address prefixes. Tags may not be used. This is required if source_address_prefix is not specified.<br>    destination_address_prefix                 = string       # CIDR or destination IP range or * to match any IP. Tags such as ‘VirtualNetwork’, ‘AzureLoadBalancer’ and ‘Internet’ can also be used. Besides, it also supports all available Service Tags like ‘Sql.WestEurope‘, ‘Storage.EastUS‘, etc. You can list the available service tags with the CLI: shell az network list-service-tags --location westcentralus. For further information please see Azure CLI - az network list-service-tags. This is required if destination_address_prefixes is not specified.<br>    destination_address_prefixes               = list(string) # List of destination address prefixes. Tags may not be used. This is required if destination_address_prefix is not specified.<br>    source_port_range                          = string       # Source Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if source_port_ranges is not specified.<br>    source_port_ranges                         = list(string) # List of source ports or port ranges. This is required if source_port_range is not specified.<br>    destination_port_range                     = string       # Destination Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if destination_port_ranges is not specified.<br>    destination_port_ranges                    = list(string) # List of destination ports or port ranges. This is required if destination_port_range is not specified.<br>    source_application_security_group_ids      = list(string) # A List of source Application Security Group IDs<br>    destination_application_security_group_ids = list(string) # A List of destination Application Security Group IDs<br>  }))</pre> | `{}` | no |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The ID of the subnet to be associated with. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the Network Security Group.. |
| <a name="output_name"></a> [name](#output\_name) | The Name of the Network Security Group.. |
<!-- END_TF_DOCS -->
