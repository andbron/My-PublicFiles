# CHANGELOG (aligned to version.tf)
## [1.0.0] - [2024-03-05]

### Added

Policy Exemption module from  https://github.com/gettek/terraform-azurerm-policy-as-code/tree/main/modules/exemption adapted for AZTECH module structure

- Initialization

### Added
### Changed
### Fixed
### Features
