# CHANGELOG (aligned to versions.tf)

## [2.0.2] - [2024-01-29]

- Added Action group
- Added postgresql_flexible_server

## [2.0.1] - [2023-09-28]

- Added postgreqsql server and database

## [2.0.0] - [2023-09-08]

- Introduced pseudo types `computer_name_windows` and `computer_name_linux` to be used for VM hostnames. These are derived from the `virtual_machine_name_windows` and `virtual_machine_name_linux` types e.g. with tcg (`product_group`) in non_production (`environment`) and a0000 (`domain`) you get for example:
  - "virtual_machine" = ["tcg-npase-a0000-avm001"]
  - "virtual_machine_linux" = ["tcg-npase-a0000-lxc001"] > "computer_name_linux" = ["lxcnpasea000001"]
  - "virtual_machine_windows" = ["tcg-npase-a0000-wsc001"] > "computer_name_windows" = ["wscnpasea000001"]
- Introduced `affix` to be used for custom naming of resources

## [1.0.9] - [2023-09-06]

- Introduced AEN (Az-Tech Environment Network) to be allowed as prefix

## [1.0.8] - [2023-03-22]

- Fixes, added SQL MI Failover group and introduced custom abbreviation.

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
