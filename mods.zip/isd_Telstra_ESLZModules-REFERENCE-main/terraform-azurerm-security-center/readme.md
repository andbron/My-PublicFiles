<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_security_center_contact.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_subscription_pricing.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_security_center_workspace.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/security_center_workspace) | resource |
| [azurerm_log_analytics_workspace.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/data-sources/log_analytics_workspace) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alert_notifications"></a> [alert\_notifications](#input\_alert\_notifications) | Whether to send security alerts notifications to the security contact. | `bool` | n/a | yes |
| <a name="input_alerts_to_admins"></a> [alerts\_to\_admins](#input\_alerts\_to\_admins) | Whether to send security alerts notifications to subscription admins. | `bool` | n/a | yes |
| <a name="input_email"></a> [email](#input\_email) | The email of the Security Center Contact. | `string` | n/a | yes |
| <a name="input_log_analytics_resource_group_name"></a> [log\_analytics\_resource\_group\_name](#input\_log\_analytics\_resource\_group\_name) | The resource group name where the log analytics is deployed. | `string` | n/a | yes |
| <a name="input_log_analytics_workspace_name"></a> [log\_analytics\_workspace\_name](#input\_log\_analytics\_workspace\_name) | This is the existing log analytics workspace that azure security center will use. | `string` | n/a | yes |
| <a name="input_phone"></a> [phone](#input\_phone) | The phone number of the Security Center Contact. | `number` | `null` | no |
| <a name="input_scope"></a> [scope](#input\_scope) | The scope of VMs to send their security data to the desired workspace, unless overridden by a setting with more specific scope. (The Subscription, example /subscriptions/00000000-0000-0000-0000-000000000000) | `string` | n/a | yes |
| <a name="input_security_center_subscription_pricing_resource_type"></a> [security\_center\_subscription\_pricing\_resource\_type](#input\_security\_center\_subscription\_pricing\_resource\_type) | The resource type this setting affects. Possible values are AppServices, ContainerRegistry, KeyVaults, KubernetesService, SqlServers, SqlServerVirtualMachines, StorageAccounts, VirtualMachines, Arm, OpenSourceRelationalDatabases, Containers and Dns. Defaults to VirtualMachines. | `string` | `"VirtualMachines"` | no |
| <a name="input_security_center_subscription_pricing_tier"></a> [security\_center\_subscription\_pricing\_tier](#input\_security\_center\_subscription\_pricing\_tier) | The pricing tier to use. Possible values are Free and Standard. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_security_center_id"></a> [security\_center\_id](#output\_security\_center\_id) | The Security Center Contact ID. |
| <a name="output_security_center_workspace_id"></a> [security\_center\_workspace\_id](#output\_security\_center\_workspace\_id) | The Security Center Workspace ID. |
| <a name="output_subscription_pricing_id"></a> [subscription\_pricing\_id](#output\_subscription\_pricing\_id) | The subscription pricing ID |
<!-- END_TF_DOCS -->
