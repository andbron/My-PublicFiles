<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_vpn_gateway.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/vpn_gateway) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_asn"></a> [asn](#input\_asn) | The ASN of the BGP Speaker. | `string` | n/a | yes |
| <a name="input_bgp_route_translation_for_nat_enabled"></a> [bgp\_route\_translation\_for\_nat\_enabled](#input\_bgp\_route\_translation\_for\_nat\_enabled) | Is BGP route translation for NAT on this VPN Gateway enabled? Defaults to false. | `string` | `"false"` | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure location where this VPN Gateway should be created. | `string` | n/a | yes |
| <a name="input_peer_weight"></a> [peer\_weight](#input\_peer\_weight) | The weight added to Routes learned from this BGP Speaker. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The Name of the Resource Group in which this VPN Gateway should be created. | `string` | n/a | yes |
| <a name="input_routing_preference"></a> [routing\_preference](#input\_routing\_preference) | Azure routing preference lets you to choose how your traffic routes between Azure and the internet. You can choose to route traffic either via the Microsoft network (default value, Microsoft Network), or via the ISP network (public internet, set to Internet). | `string` | `"Microsoft Network"` | no |
| <a name="input_scale_unit"></a> [scale\_unit](#input\_scale\_unit) | The Scale Unit for this VPN Gateway. Defaults to 1. | `string` | `"1"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the VPN Gateway. | `map(string)` | `null` | no |
| <a name="input_virtual_hub_id"></a> [virtual\_hub\_id](#input\_virtual\_hub\_id) | The ID of the Virtual Hub within which this VPN Gateway should be created. | `string` | n/a | yes |
| <a name="input_vpngateway_name"></a> [vpngateway\_name](#input\_vpngateway\_name) | The Name which should be used for this VPN Gateway.. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bgp_settings"></a> [bgp\_settings](#output\_bgp\_settings) | The Address which should be used for the BGP Peering.The pre-defined id of VPN Gateway IP Configuration.The list of default BGP peering addresses which belong to the pre-defined VPN Gateway IP configuration.The list of tunnel public IP addresses which belong to the pre-defined VPN Gateway IP configuration. |
| <a name="output_id"></a> [id](#output\_id) | The ID of the VPN Gateway. |
<!-- END_TF_DOCS -->
