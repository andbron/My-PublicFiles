# CHANGELOG (aligned to versions.tf)
## [1.0.2] - [2022-01-05]

### Changed

- Remove the parent management group id as output from module
- Remove the root_management_group_id as input

## [1.0.1] - [2022-11-29]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
