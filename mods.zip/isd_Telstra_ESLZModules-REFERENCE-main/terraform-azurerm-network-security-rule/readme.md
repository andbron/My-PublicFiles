<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_security_rule.inbound_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.outbound_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_nsg"></a> [nsg](#input\_nsg) | (Required) The Network Security Group that the rules should be created in. | <pre>object({<br>    name                = string<br>    resource_group_name = string<br>  })</pre> | n/a | yes |
| <a name="input_nsg_inbound_rules"></a> [nsg\_inbound\_rules](#input\_nsg\_inbound\_rules) | (Optional) A list of the NSG inbound rules. The string should be formatted as: #Name = [0-priority, 1-src, 2-dst, 3-dst ports, 4-protocol, 5-(opt)access]. 5-access ('Allow' or 'Deny'), defaults to 'Allow'. The priority should start from 200 and it should be at least 5-10 integers apart between rules. i.e. WEB-to-DB-MSSQLB-Allow-In = [270, module.asg\_web.id, module.asg\_dbase.id, "1434", "UDP"] | `any` | `{}` | no |
| <a name="input_nsg_outbound_rules"></a> [nsg\_outbound\_rules](#input\_nsg\_outbound\_rules) | (Optional) A list of the NSG outbound rules. The string should be formatted as: #Name = [0-priority, 1-src, 2-dst, 3-dst ports, 4-protocol, 5-(opt)access]. 5-access ('Allow' or 'Deny'), defaults to 'Allow'. The priority should start from 200 and it should be at least 5-10 integers apart between rules. i.e. WEB-to-DB-MSSQLB-Allow-In = [270, module.asg\_web.id, module.asg\_dbase.id, "1434", "UDP"] | `any` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_inbound_rules"></a> [inbound\_rules](#output\_inbound\_rules) | The inbound NSG rule |
| <a name="output_outbound_rules"></a> [outbound\_rules](#output\_outbound\_rules) | The outbound NSG rule |
<!-- END_TF_DOCS -->
