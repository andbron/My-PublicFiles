<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_resolver.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver) | resource |
| [azurerm_private_dns_resolver_dns_forwarding_ruleset.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_dns_forwarding_ruleset) | resource |
| [azurerm_private_dns_resolver_forwarding_rule.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_forwarding_rule) | resource |
| [azurerm_private_dns_resolver_inbound_endpoint.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_inbound_endpoint) | resource |
| [azurerm_private_dns_resolver_outbound_endpoint.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_outbound_endpoint) | resource |
| [azurerm_private_dns_resolver_virtual_network_link.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_virtual_network_link) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_domain_name"></a> [domain\_name](#input\_domain\_name) | Specifies the domain name for the Private DNS Resolver Forwarding Rule. | `string` | `"onprem.local."` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Specifies the state of the Private DNS Resolver Forwarding Rule. | `bool` | `true` | no |
| <a name="input_inbound_subnet_id"></a> [inbound\_subnet\_id](#input\_inbound\_subnet\_id) | The id of the virtual network subnet to which to attach the DNS resolver inbound endpoint. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_ip_address"></a> [ip\_address](#input\_ip\_address) | DNS server IP address. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_outbound_subnet_id"></a> [outbound\_subnet\_id](#input\_outbound\_subnet\_id) | The id of the virtual network subnet to which to attach the DNS resolver outbound endpoint. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_port"></a> [port](#input\_port) | DNS server port. | `number` | `53` | no |
| <a name="input_private_dns_resolver_dns_forwarding_ruleset_name"></a> [private\_dns\_resolver\_dns\_forwarding\_ruleset\_name](#input\_private\_dns\_resolver\_dns\_forwarding\_ruleset\_name) | The name of Private DNS Resolver Forwarding Ruleset | `string` | `"default_ruleset"` | no |
| <a name="input_private_dns_resolver_forwarding_rule_name"></a> [private\_dns\_resolver\_forwarding\_rule\_name](#input\_private\_dns\_resolver\_forwarding\_rule\_name) | The name of the Private DNS Resolver Forwarding Rule. | `string` | `"default_rule"` | no |
| <a name="input_private_dns_resolver_inbound_endpoint_name"></a> [private\_dns\_resolver\_inbound\_endpoint\_name](#input\_private\_dns\_resolver\_inbound\_endpoint\_name) | The name of Private DNS Resolver Inbound Endpoint | `string` | `"default_inbound_endpoint"` | no |
| <a name="input_private_dns_resolver_name"></a> [private\_dns\_resolver\_name](#input\_private\_dns\_resolver\_name) | The name of Private DNS Resolver | `string` | n/a | yes |
| <a name="input_private_dns_resolver_outbound_endpoint_name"></a> [private\_dns\_resolver\_outbound\_endpoint\_name](#input\_private\_dns\_resolver\_outbound\_endpoint\_name) | The name of Private DNS Resolver Outbound Endpoint | `string` | `"default_outbound_endpoint"` | no |
| <a name="input_private_dns_resolver_virtual_network_link_name"></a> [private\_dns\_resolver\_virtual\_network\_link\_name](#input\_private\_dns\_resolver\_virtual\_network\_link\_name) | Specifies the name which should be used for this Private DNS Resolver Virtual Network Link. Changing this forces a new Private DNS Resolver Virtual Network Link to be created. | `string` | `"default_virtual_network_link"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | the name of Resources Group | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags of the Private DNS Resolver. | `map(string)` | `null` | no |
| <a name="input_virtual_network_id"></a> [virtual\_network\_id](#input\_virtual\_network\_id) | The id of the virtual network to which to attach the DNS resolver. Changing this forces a new resource to be created. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_forwarding_rule_id"></a> [forwarding\_rule\_id](#output\_forwarding\_rule\_id) | The Private DNS Resolver Forwarding Rule ID. |
| <a name="output_forwarding_ruleset_id"></a> [forwarding\_ruleset\_id](#output\_forwarding\_ruleset\_id) | The Private DNS Resolver Forwarding RuleSet ID. |
| <a name="output_id"></a> [id](#output\_id) | The Private DNS Resolver ID. |
| <a name="output_inbound_endpoint_id"></a> [inbound\_endpoint\_id](#output\_inbound\_endpoint\_id) | The Private DNS Resolver Inbound Endpoint ID. |
| <a name="output_outbound_endpoint_id"></a> [outbound\_endpoint\_id](#output\_outbound\_endpoint\_id) | The Private DNS Resolver Outbound Endpoint ID. |
| <a name="output_virtual_network_link_id"></a> [virtual\_network\_link\_id](#output\_virtual\_network\_link\_id) | The Private DNS Resolver Virtual Network Link ID. |
<!-- END_TF_DOCS -->