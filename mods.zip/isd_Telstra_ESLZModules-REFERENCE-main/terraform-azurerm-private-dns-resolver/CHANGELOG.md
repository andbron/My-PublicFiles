# CHANGELOG (aligned to versions.tf)

## [1.0.3] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.3] - [2023-02-24]

### Added

- Add provision to enter a second DNS server when declaring an outbound ruleset

- Initialization

### Added

### Changed

### Fixed

### Features
