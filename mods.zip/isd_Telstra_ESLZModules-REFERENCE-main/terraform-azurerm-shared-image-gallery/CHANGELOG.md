# CHANGELOG (aligned to versions.tf)

## [1.0.3] - [2023-06-09]

- Added more tags to the image gallery
- Removed lifecycle to ignore all tags

## [1.0.2] - [2023-02-02]

### Added

- Added 'Prevent destroy' to prevent images from being accidentally deleted.

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
