# CHANGELOG (aligned to versions.tf)

## [1.2.0] - [2024-03-21]

### Added

- Added `ignore_changes` for storage

## [1.1.0] - [2024-02-25]

### Added

- Added `auto_rotation_enabled` switch and made TDE optional
- Added `principal_id` and `key_vault_key_id` outputs

## [1.0.5] - [2023-09-11]

### Added

- Outsourced Key Vault Key creation
- Added User-assigned Identity support

## [1.0.4] - [2023-06-30]

### Added

- Outputs for fqdn, admin_login and admin_login_password

### Changed

- azpi resource to azurerm

## [1.0.3] - [2023-04-11]

### Added

- transformed into azapi (due to SQL MI Azure Policy requirement for CMK)

## [1.0.2] - [2023-03-15]

### Added

- Initialization

