# CHANGELOG (aligned to versions.tf)
## [1.0.2] - [2023-12-07]

### Changed

- Fix the DNS server variable to allow multiple DNS IP addresses
- Fix the variable type from string to list(string) for dns_server
- Retained module version.

## [1.0.1] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
