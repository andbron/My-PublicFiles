# CHANGELOG (aligned to versions.tf)
## [1.0.6] - [2023-11-29]
### Added
Added retention of Audit logs as Variable to parameterize the value.Default to Unlimited retention as per Azure Baseline

## [1.0.4] - [2023-02-23]
### Added
Removed data blocks from inside module

## [1.0.3] - [2023-02-20]
### Added
Change resource to use azapi due to policy restriction

## [1.0.2] - [2023-01-05]
### Added
Audit Log Settings 

## [1.0.1] - [2023-01-03]
### Added
Initial base module
