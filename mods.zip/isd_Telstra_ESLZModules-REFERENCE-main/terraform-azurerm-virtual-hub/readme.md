<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_virtual_hub.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/virtual_hub) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_address_prefix"></a> [address\_prefix](#input\_address\_prefix) | The Address Prefix which should be used for this Virtual Hub.The address prefix subnet cannot be smaller than a /24. Azure recommends using a /23. | `string` | n/a | yes |
| <a name="input_address_prefixes"></a> [address\_prefixes](#input\_address\_prefixes) | A list of Address Prefixes. | `list(string)` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. | `string` | n/a | yes |
| <a name="input_next_hop_ip_address"></a> [next\_hop\_ip\_address](#input\_next\_hop\_ip\_address) | The IP Address that Packets should be forwarded to as the Next Hop. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the Virtual WAN. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the Virtual WAN. | `map(string)` | `null` | no |
| <a name="input_virtual_wan_id"></a> [virtual\_wan\_id](#input\_virtual\_wan\_id) | The ID of a Virtual WAN within which the Virtual Hub should be created | `string` | n/a | yes |
| <a name="input_virtualhub_name"></a> [virtualhub\_name](#input\_virtualhub\_name) | The name of the Virtual Hub. | `string` | n/a | yes |
| <a name="input_virtualhub_sku"></a> [virtualhub\_sku](#input\_virtualhub\_sku) | The SKU of the Virtual Hub. Possible values are Basic and Standard. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_default_route_table_id"></a> [default\_route\_table\_id](#output\_default\_route\_table\_id) | The ID of the default Route Table in the Virtual Hub. |
| <a name="output_id"></a> [id](#output\_id) | The ID of the Virtual Hub. |
| <a name="output_virtual_router_asn"></a> [virtual\_router\_asn](#output\_virtual\_router\_asn) | The Autonomous System Number of the Virtual Hub BGP router. |
| <a name="output_virtual_router_ips"></a> [virtual\_router\_ips](#output\_virtual\_router\_ips) | The IP addresses of the Virtual Hub BGP router. |
<!-- END_TF_DOCS -->
