<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_managed_disk.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_virtual_machine_data_disk_attachment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_caching"></a> [caching](#input\_caching) | Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite. | `string` | `"ReadWrite"` | no |
| <a name="input_create_option"></a> [create\_option](#input\_create\_option) | The create option for the disk | `string` | `"Empty"` | no |
| <a name="input_create_option_data_disk_attachment"></a> [create\_option\_data\_disk\_attachment](#input\_create\_option\_data\_disk\_attachment) | The Create Option of the Data Disk, such as Empty or Attach. Defaults to Attach. Changing this forces a new resource to be created. | `string` | `"Attach"` | no |
| <a name="input_disk_access_id"></a> [disk\_access\_id](#input\_disk\_access\_id) | The ID of the disk access resource for using private endpoints on disks. | `string` | `null` | no |
| <a name="input_disk_encryption_set_id"></a> [disk\_encryption\_set\_id](#input\_disk\_encryption\_set\_id) | The ID of a Disk Encryption Set which should be used to encrypt this Managed Disk. Conflicts with secure\_vm\_disk\_encryption\_set\_id. | `string` | n/a | yes |
| <a name="input_disk_size_gb"></a> [disk\_size\_gb](#input\_disk\_size\_gb) | The size of the disk. | `number` | `127` | no |
| <a name="input_edge_zone"></a> [edge\_zone](#input\_edge\_zone) | Specifies the Edge Zone within the Azure Region where this Managed Disk should exist. | `string` | `null` | no |
| <a name="input_gallery_image_reference_id"></a> [gallery\_image\_reference\_id](#input\_gallery\_image\_reference\_id) | ID of a Gallery Image Version to copy when create\_option is FromImage. | `string` | `null` | no |
| <a name="input_hyper_v_generation"></a> [hyper\_v\_generation](#input\_hyper\_v\_generation) | he HyperV Generation of the Disk when the source of an Import or Copy operation targets a source that contains an operating system. Possible values are V1 and V2. | `string` | `null` | no |
| <a name="input_image_reference_id"></a> [image\_reference\_id](#input\_image\_reference\_id) | ID of an existing platform/marketplace disk image to copy when create\_option is FromImage. | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | Specified the supported Azure location where the resource exists. | `string` | n/a | yes |
| <a name="input_lun"></a> [lun](#input\_lun) | The Logical Unit Number of the Data Disk, which needs to be unique within the Virtual Machine. Changing this forces a new resource to be created. | `number` | `0` | no |
| <a name="input_max_shares"></a> [max\_shares](#input\_max\_shares) | The maximum number of VMs that can attach to the disk at the same time. Value greater than one indicates a disk that can be mounted on multiple VMs at the same time. | `string` | `null` | no |
| <a name="input_name"></a> [name](#input\_name) | Specifies the name of the Managed Disk. | `string` | n/a | yes |
| <a name="input_on_demand_bursting_enabled"></a> [on\_demand\_bursting\_enabled](#input\_on\_demand\_bursting\_enabled) | Specifies if On-Demand Bursting is enabled for the Managed Disk. Defaults to false. | `bool` | `false` | no |
| <a name="input_os_type"></a> [os\_type](#input\_os\_type) | Specify a value when the source of an Import or Copy operation targets a source that contains an operating system. Valid values are Linux or Windows. | `string` | `null` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the Managed Disk should exist. | `string` | n/a | yes |
| <a name="input_security_type"></a> [security\_type](#input\_security\_type) | Security Type of the Managed Disk when it is used for a Confidential VM. Possible values are ConfidentialVM\_VMGuestStateOnlyEncryptedWithPlatformKey, ConfidentialVM\_DiskEncryptedWithPlatformKey and ConfidentialVM\_DiskEncryptedWithCustomerKey. | `string` | `null` | no |
| <a name="input_source_uri"></a> [source\_uri](#input\_source\_uri) | URI to a valid VHD file to be used when create\_option is Import. | `string` | `null` | no |
| <a name="input_storage_account_id"></a> [storage\_account\_id](#input\_storage\_account\_id) | The ID of the Storage Account where the source\_uri is located. Required when create\_option is set to Import. | `string` | `null` | no |
| <a name="input_storage_account_type"></a> [storage\_account\_type](#input\_storage\_account\_type) | The type of storage to use for the managed disk. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |
| <a name="input_tier"></a> [tier](#input\_tier) | The disk performance tier to use.This feature is currently supported only for premium SSDs. | `string` | `null` | no |
| <a name="input_trusted_launch_enabled"></a> [trusted\_launch\_enabled](#input\_trusted\_launch\_enabled) | The maximum number of VMs that can attach to the disk at the same time. Value greater than one indicates a disk that can be mounted on multiple VMs at the same time. | `bool` | `false` | no |
| <a name="input_virtual_machine_id"></a> [virtual\_machine\_id](#input\_virtual\_machine\_id) | The ID of the Virtual Machine to which the Data Disk should be attached. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_write_accelerator_enabled"></a> [write\_accelerator\_enabled](#input\_write\_accelerator\_enabled) | Specifies if Write Accelerator is enabled on the disk. This can only be enabled on Premium\_LRS managed disks with no caching and M-Series VMs. Defaults to false. | `bool` | `false` | no |
| <a name="input_zone"></a> [zone](#input\_zone) | Specifies the Availability Zone in which this Managed Disk should be located. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_data_disk_attachment_id"></a> [data\_disk\_attachment\_id](#output\_data\_disk\_attachment\_id) | The ID of the Virtual Machine Data Disk attachment. |
| <a name="output_id"></a> [id](#output\_id) | The id of the created managed disk. |
<!-- END_TF_DOCS -->
