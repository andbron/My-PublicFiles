Param(
    [string]$destinationFolder = ".",
    [string]$org = "9025-CICD",
    [array]$projects = (
        "ESLZ Modules",
        "ESLZ Platform",
        "ESLZ Application Landing Zones",
        "ESLZ Infrastructure Application Landing Zones",
        "ESLZ Application Jump Starts",
        "ESLZ Application Source Code"
     )
)

# .CHANGELOG

# 2021-06-19 - Initial version
# 2024-01-22 - Added support for users with VPN hybrid connectons

# Make sure you have the Azure CLI installed (az extension add --name azure-devops) and logged in via az login or az devops login
# If you face /_apis authentication issues make sure to login via az login --allow-no-subscriptions

# ask to make sure the user is not logged into the VPN
Read-Host -Prompt "Make sure you are not connected to the VPN (Press Enter to continue)"

az devops configure --defaults organization=https://dev.azure.com/$org

# storing all repos per project in an array before connecting to VPN since az cli using REST doesn't work while being connected to the VPN
$allRepos = @()

foreach ($project in $projects) {
    $repos = az repos list --project $project | ConvertFrom-Json | Sort-Object -Property name
    $allRepos += $repos
}

# ask a question to connect to the VPN
Read-Host -Prompt "Please make sure to reconnect to the VPN (Press Enter to continue)"

foreach ($repo in $allRepos) {
    If(!(test-path -PathType container $destinationFolder/$($repo.project.name)))
    {
        New-Item -ItemType Directory -Path $destinationFolder/$($repo.project.name)
    }
    If(!(test-path -PathType container $destinationFolder/$($repo.project.name)/$($repo.name)))
    {
        Write-Output "Cloning repository $($repo.name) from $($repo.project.name)"
        git clone $($repo.remoteUrl) $destinationFolder/$($repo.project.name)/$($repo.name)
    } else
    {
        Write-Output "Repository folder $($repo.name) already exists, skipping ..."
    }
}
