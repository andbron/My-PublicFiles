Param(
    [array]$subscriptions = @(
        # "tcg-azu0000-nonprod-conn",
        "tcg-azu0000-nonprod-devsecops",
        "tcg-azu0000-nonprod-mgmt",
        "tcg-azu0000-nonprod-shared",
        "tcg-np-ppat01-sub001",
        "tcg-np-ppat02-sub001",
        "tcg-np-ppat03-sub001",
        "tcg-np-ppat04-sub001",
        "tcg-azu0000-nonprod-identity",
        "tcg-azu0000-nonprod-pbmn"),
    [array]$resourceGroupExceptions = @(
        "tcg-npase-mgmt-network-rg001",
        "tcg-npae-shared-compute_gallery-rg001",
        "tcg-npae-a1661-rg001",
        "tcg-npae-a2433-rg001",
        "tcg-npae-a4362-rg001",
        "tcg-npae-a4751-rg001",
        "tcg-npae-a9999-rg001",
        "tcg-pdae-a1661-rg001",
        "tcg-pdae-a2433-rg001",
        "tcg-pdae-a4362-rg001",
        "tcg-pdae-a4751-rg001"),
    [object]$tags = @{
        "telstra_applicationid"             = "app-4904"
        "telstra_environmentclass"          = "nonproduction" # nonproduction
        "telstra_environmentuse"            = "nonprod" # nonprod
        "telstra_internetfacing"            = "false"
        "telstra_platform"                  = "az-tech"
        "telstra_version"                   = "1.0"
        "telstra_dataclassification"        = "general"
        "telstra_dataclassificationsubtype" = "none"
        "telstra_dataregion"                = "none"
        "telstra_costcentre"                = "alz"
        "app_contact"                       = "az-tech@team.telstra.com"
    }
)

# check if logged in via Connect-AzAccount already
if ($null -eq (Get-AzContext).Account) {
    Connect-AzAccount -UseDeviceAuthentication
}

# Enabling TSL 1.2 if not set already
if (![Net.ServicePointManager]::SecurityProtocol -band [Net.SecurityProtocolType]::Tls12) {
    Write-Host "Enabling TLS 1.2"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

try {
    # if $resourceGroups contains value output the exception
    if ($resourceGroupExceptions) {
        Write-Host "Excluding the following resource groups:"
        $resourceGroupExceptions
    }

    foreach ($subscription in $subscriptions) {
        # Set the context based on subscription name
        Set-AzContext -SubscriptionName $subscription

        # Write Output that we're going to apply the following tags onto all resources in the current subscription
        Write-Host "Applying tags onto all resources in $($subscription):"
        $tags | ConvertTo-Json

        # Get all resource groups in the current subscription except the ones from $resourceGroupExceptions
        $resourceGroups = Get-AzResourceGroup | Where-Object { $_.ResourceGroupName -notin $resourceGroupExceptions }

        # Loop through all resource groups
        foreach ($resourceGroup in $resourceGroups) {
            # Get all resources in the current resource group
            $resources = Get-AzResource -ResourceGroupName $resourceGroup.ResourceGroupName

            # Loop through all resources
            foreach ($resource in $resources) {
                # Get the current tags
                $currentTags = (Get-AzTag -ResourceId $resource.ResourceId).Tags
                Write-Host "Applying tags onto resource $($resource.Name)."

                # Merge the current tags with the new tags
                $mergedTags = $currentTags + $tags

                # Update the tags
                Update-AzTag -ResourceId $resource.ResourceId -Tag $mergedTags -Operation Merge
            }
        }
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}
