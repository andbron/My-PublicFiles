<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_vpn_site.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/vpn_site) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_endpoint_enabled"></a> [allow\_endpoint\_enabled](#input\_allow\_endpoint\_enabled) | Is allow endpoint enabled? The Allow endpoint is required for connectivity to specific O365 services and features, but are not as sensitive to network performance and latency as other endpoint types. Defaults to false. | `string` | `"false"` | no |
| <a name="input_asn"></a> [asn](#input\_asn) | The BGP speaker's ASN.. | `string` | n/a | yes |
| <a name="input_default_endpoint_enabled"></a> [default\_endpoint\_enabled](#input\_default\_endpoint\_enabled) | Is default endpoint enabled? The Default endpoint represents O365 services and dependencies that do not require any optimization, and can be treated by customer networks as normal Internet bound traffic. Defaults to false. | `string` | `"false"` | no |
| <a name="input_device_model"></a> [device\_model](#input\_device\_model) | The model of the vpn device. | `string` | n/a | yes |
| <a name="input_device_vendor"></a> [device\_vendor](#input\_device\_vendor) | The name of the vpn device vendor. | `string` | n/a | yes |
| <a name="input_ip_address"></a> [ip\_address](#input\_ip\_address) | The IP address of this vpn site link. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure location where this vpn Gateway should be created. | `string` | n/a | yes |
| <a name="input_optimize_endpoint_enabled"></a> [optimize\_endpoint\_enabled](#input\_optimize\_endpoint\_enabled) | Is optimize endpoint enabled? The Optimize endpoint is required for connectivity to every O365 service and represents the O365 scenario that is the most sensitive to network performance, latency, and availability. Defaults to false. | `string` | `"false"` | no |
| <a name="input_peering_address"></a> [peering\_address](#input\_peering\_address) | The BGP peering IP address. | `string` | n/a | yes |
| <a name="input_provider_name"></a> [provider\_name](#input\_provider\_name) | The name of the physical link at the vpn site. Example: ATT, Verizon. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the vpn site should exist. Changing this forces a new vpn site to be created. | `string` | n/a | yes |
| <a name="input_speed_in_mbps"></a> [speed\_in\_mbps](#input\_speed\_in\_mbps) | The speed of the vpn device at the branch location in unit of mbps. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags which should be assigned to the vpn site. | `map(string)` | `null` | no |
| <a name="input_virtual_wan_id"></a> [virtual\_wan\_id](#input\_virtual\_wan\_id) | The ID of the Virtual Wan where this vpn site resides in. Changing this forces a new vpn site to be created. | `string` | n/a | yes |
| <a name="input_vpnsitelink_name"></a> [vpnsitelink\_name](#input\_vpnsitelink\_name) | The name which should be used for this vpn site link.. | `string` | n/a | yes |
| <a name="input_vpnsites_name"></a> [vpnsites\_name](#input\_vpnsites\_name) | The name which should be used for this vpn site. Changing this forces a new vpn site to be created. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the VPN Site. |
| <a name="output_link"></a> [link](#output\_link) | The ID of the VPN Site Link. |
<!-- END_TF_DOCS -->