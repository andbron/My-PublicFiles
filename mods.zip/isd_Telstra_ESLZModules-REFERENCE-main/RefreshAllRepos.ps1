# First you need to authenticate to the AZ CLi
# Interactive session, type: az login --use-device-code

Param(
   [string]$destinationFolder = ".",
   [string]$org = "9025-CICD",
   [string]$project = "ESLZ Modules"
)

az devops configure --defaults organization=https://dev.azure.com/$org project=$project
$currentPath = $($pwd.path)
$repos = az repos list | ConvertFrom-Json

foreach($repo in $repos) {
   $modulePath = Join-Path $currentPath $repo.name
   $testPath = Test-Path -Path $modulePath
   if ($testPath) {
      Write-Host "`nINFO: Repository folder already exists - $($repo.name)"
      Set-Location $modulePath
      git checkout main
      git pull
      Set-Location $currentPath
   } else {
      Write-Host "`nINFO: Creating Repository Folder  - $($repo.name)"
      New-Item -Path $modulePath -ItemType Directory
      Set-Location $currentPath
      $newModulePath = Join-Path $destinationFolder $repo.Name
      git clone $($repo.webUrl) $newModulePath
   }
}