# CHANGELOG (aligned to versions.tf)

## [1.0.4] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.4] - [2023-03-14]

### Added

- Allow for deployments with platform managed keys due to issue with customer managed keys not working with private endpointed key vaults

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
