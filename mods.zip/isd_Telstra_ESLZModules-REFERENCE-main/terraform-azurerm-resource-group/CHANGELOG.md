# CHANGELOG (aligned to versions.tf)

## [1.0.1] - [2023-06-21]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.1] - [2022-12-07]

### Changed

- Changed/Updated azurerm provider to support versions equal and higher than 3.25.

## [1.0.0] - [2022-11-25]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
