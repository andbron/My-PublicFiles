# CHANGELOG (aligned to versions.tf)

## [1.0.3] - [2024-01-29]

### Changed

- Automatically adds rotation policy for the keys getting created. Defined three variables rotation_policy_time_after_creation, rotation_policy_expire_after and rotation_policy_notify_before_expiry for rotation policy.

## [1.0.2] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.2] - [2023-03-30]

### Added

- Added time_rotating resource for expiration date

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
