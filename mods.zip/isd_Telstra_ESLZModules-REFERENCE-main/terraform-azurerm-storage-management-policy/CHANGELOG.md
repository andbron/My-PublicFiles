# CHANGELOG (aligned to versions.tf)

## [1.0.1] - [2023-08-16]

### Changed

- Retained module version.

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
