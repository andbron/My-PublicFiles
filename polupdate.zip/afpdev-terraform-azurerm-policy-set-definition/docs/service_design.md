# Policy Set (Initiative) Definitions

## Policy Set (Initiative) Definition Files

Policy Set definition files are managed within the folder policySetDefinitions under Definitions. The definition files are structured based on the official Azure Initiative definition structure published by Microsoft. There are numerous definition samples available on Microsoft's GitHub repository for azure-policy.

**_Note:_**
When authoring Policy or Policy Set definitions, check out the Maximum count of Azure Policy objects

The names of the definition JSON files don't matter, the Policy Sets are registered based on the name attribute. The solution also allows the use of JSON with comments by using .jsonc instead of .json for the file extension.

Optionally, **_Policy definition groups_** allow custom Policy Sets to map to different regulatory compliance requirements. These will show up in the **_regulatory compliance blade in the Microsoft Defender for Cloud portal_**. In order to use this, the custom Policy Sets must have both policy definition groups and group names defined.

Policy definition groups must be pulled from a built-in Policy Sets such as the Azure Security Benchmark initiative (Azure Initiative definition structure published by Microsoft). There are numerous definition samples available on Microsoft's GitHub Azure Security Benchmark Code.

### Recommendations

- `name` Is required and should be unique. It can be a GUID or a unique short name.
- Custom Policies: use policyDefinitionName. The solution constructs the policyDefinitionId based on the deploymentRootScope in global-settings.jsonc.
- Builtin Policies: use policyDefinitionId. The solution can constructs the policyDefinitionId from policyDefinitionName for builtin Policies; however using policyDefinitionId is more explicit/cleaner.
- **_Do not specify an id. The solution will ignore it._**
- Make the effects parameterized
