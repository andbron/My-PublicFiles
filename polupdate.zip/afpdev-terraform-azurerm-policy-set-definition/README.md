# Module README

<!-- BEGIN_TF_DOCS -->



# CHANGELOG

## 1.0.0 05/04/2024

- initial module creation

---

**_CHANGELOG Notes_**

- _Add new changelog entries to the top of the file_
- _Document changes to module inputs (vars) and outputs_
- _Highlight breaking changes using the notation:_ **[BREAKING CHANGE]**
  

## Service Design
# Policy Set (Initiative) Definitions

## Policy Set (Initiative) Definition Files

Policy Set definition files are managed within the folder policySetDefinitions under Definitions. The definition files are structured based on the official Azure Initiative definition structure published by Microsoft. There are numerous definition samples available on Microsoft's GitHub repository for azure-policy.

**_Note:_**
When authoring Policy or Policy Set definitions, check out the Maximum count of Azure Policy objects

The names of the definition JSON files don't matter, the Policy Sets are registered based on the name attribute. The solution also allows the use of JSON with comments by using .jsonc instead of .json for the file extension.

Optionally, **_Policy definition groups_** allow custom Policy Sets to map to different regulatory compliance requirements. These will show up in the **_regulatory compliance blade in the Microsoft Defender for Cloud portal_**. In order to use this, the custom Policy Sets must have both policy definition groups and group names defined.

Policy definition groups must be pulled from a built-in Policy Sets such as the Azure Security Benchmark initiative (Azure Initiative definition structure published by Microsoft). There are numerous definition samples available on Microsoft's GitHub Azure Security Benchmark Code.

### Recommendations

- `name` Is required and should be unique. It can be a GUID or a unique short name.
- Custom Policies: use policyDefinitionName. The solution constructs the policyDefinitionId based on the deploymentRootScope in global-settings.jsonc.
- Builtin Policies: use policyDefinitionId. The solution can constructs the policyDefinitionId from policyDefinitionName for builtin Policies; however using policyDefinitionId is more explicit/cleaner.
- **_Do not specify an id. The solution will ignore it._**
- Make the effects parameterized
  

## Example usage

```hcl
### A provider block is required in order to interact with an azure subscription
### Note: the Unit testing pipeline handles the necessary authentication steps 
terraform {
  required_version = "~> 1.7.2" # Terraform Version
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90.0"
    }
  }
}

provider "azurerm" {
  features {}
  skip_provider_registration = true # https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs#skip_provider_registration
}


### Create any test dependencies by calling other modules, or creating resources directly
resource "random_string" "suffix" {
  length  = 6
  special = false
}


locals {
  policy_set_initiative_inputs = jsondecode(file("${path.root}/input.json")).input_parameters

  definition_groups = length(local.policy_set_initiative_inputs.policy_definition_groups) > 0 ? local.policy_set_initiative_inputs.policy_definition_groups : []

  member_builtin_definitions_transformed = { for k, v in local.policy_set_initiative_inputs.builtin_policies : v.policy_def_id => {
    policy_def_id = v.policy_def_id
    group_names   = v.group_names
  } }

  member_custom_definitions_transformed = { for k, v in local.policy_set_initiative_inputs.custom_policies : v.policy_def_id => {
    policy_def_id = v.policy_def_id
    group_names   = v.group_names
  } }

  member_builtin_definitions_merged = {
    for key, config in data.azurerm_policy_definition.builtin_policies : key =>
    merge(
      local.member_builtin_definitions_transformed[key],
      config
    )
  }

  member_custom_definitions_merged = {
    for key, config in data.azurerm_policy_definition.custom_policies : key =>
    merge(
      local.member_custom_definitions_transformed[key],
      config
    )
  }
}


### Create any test dependencies by calling other modules, or creating resources directly
data "azurerm_management_group" "org" {
  name = "root.ecp"
}

data "azurerm_policy_definition" "builtin_policies" {
  for_each = local.member_builtin_definitions_transformed
  name     = each.key
}

data "azurerm_policy_definition" "custom_policies" {
  for_each              = local.member_custom_definitions_transformed
  name                  = each.key
  management_group_name = "2449bd8c-857f-4212-84c6-819ed04fe712"
}


### This code snippet will call the module that this test is designed for using a relative path
module "create_policy_set_initiative" {
  source                  = "../../"
  initiative_name         = "ModuleTestingInitiativeSet"
  initiative_display_name = "AFP Module Testing Policy Set Initiative "
  initiative_description  = "Deploys and configures the AFP Module Policy Set Initiative"
  initiative_category     = "Testing"
  management_group_id     = data.azurerm_management_group.org.id
  merge_effects           = false
  merge_parameters        = false
  member_definitions = merge(
    local.member_builtin_definitions_merged,
    local.member_custom_definitions_merged
  )
  definition_groups = local.definition_groups
}
  
{
    "plan": true,
    "apply": true,
    "destroy": true
}
 
### Create any test dependencies by calling other modules, or creating resources directly
data "azurerm_management_group" "org" {
  name = "Sandbox"
}

data "azurerm_policy_definition" "builtinpolicies" {
  for_each = var.builtin_policies
  name     = each.key
}

module "configure_initiative" {
  source                  = "git::https://afpgovau@dev.azure.com/afpgovau/Azure-Modules/_git/terraform-azurerm-policy-set-definition?ref=1.0.0"   #required
  initiative_name         = "ApplicationAzureLandingZone"                                     #required
  initiative_display_name = "AFP Application Landing Zone Policy Set Initiative"              #required
  initiative_description  = "Creates the AFP Application Landing Zone Policy Set Initiative"  #optional
  initiative_category     = "Platform"                                                        #optional
  management_group_id     = data.azurerm_management_group.org.id                              #optional
  merge_effects           = false                                                             #optional
  merge_parameters        = false                                                             #optional
  member_definitions      = data.azurerm_policy_definition.builtinpolicies                    #required
}

   
```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.7.2 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.90.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.90.0 |  

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_policy_set_definition.set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/policy_set_definition) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_definition_groups"></a> [definition\_groups](#input\_definition\_groups) | Policy Defenition Groups referenced to show compliance against controls | `any` | `[]` | no |
| <a name="input_initiative_category"></a> [initiative\_category](#input\_initiative\_category) | The category of the initiative | `string` | `"General"` | no |
| <a name="input_initiative_description"></a> [initiative\_description](#input\_initiative\_description) | Policy initiative description | `string` | `""` | no |
| <a name="input_initiative_display_name"></a> [initiative\_display\_name](#input\_initiative\_display\_name) | Policy initiative display name | `string` | n/a | yes |
| <a name="input_initiative_metadata"></a> [initiative\_metadata](#input\_initiative\_metadata) | The metadata for the policy initiative. This is a JSON object representing additional metadata that should be stored with the policy initiative. Omitting this will default to merge var.initiative\_category and var.initiative\_version | `any` | `null` | no |
| <a name="input_initiative_name"></a> [initiative\_name](#input\_initiative\_name) | Policy initiative name. Changing this forces a new resource to be created | `string` | n/a | yes |
| <a name="input_initiative_version"></a> [initiative\_version](#input\_initiative\_version) | The version for this initiative, defaults to 1.0.0 | `string` | `"1.0.0"` | no |
| <a name="input_management_group_id"></a> [management\_group\_id](#input\_management\_group\_id) | The management group scope at which the initiative will be defined. Defaults to current Subscription if omitted. Changing this forces a new resource to be created. Note: if you are using azurerm\_management\_group to assign a value to management\_group\_id, be sure to use name or group\_id attribute, but not id. | `string` | `null` | no |
| <a name="input_member_definitions"></a> [member\_definitions](#input\_member\_definitions) | Policy Defenition resource nodes that will be members of this initiative | `any` | n/a | yes |
| <a name="input_merge_effects"></a> [merge\_effects](#input\_merge\_effects) | Should the module merge all member definition effects? Defauls to true | `bool` | `true` | no |
| <a name="input_merge_parameters"></a> [merge\_parameters](#input\_merge\_parameters) | Should the module merge all member definition parameters? Defauls to true | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The Id of the Policy Set Definition |
| <a name="output_initiative"></a> [initiative](#output\_initiative) | The combined Policy Initiative resource node |
| <a name="output_metadata"></a> [metadata](#output\_metadata) | The metadata of the Policy Set Definition |
| <a name="output_name"></a> [name](#output\_name) | The name of the Policy Set Definition |
| <a name="output_parameters"></a> [parameters](#output\_parameters) | The combined parameters of the Policy Set Definition |
| <a name="output_role_definition_ids"></a> [role\_definition\_ids](#output\_role\_definition\_ids) | Role definition IDs for remediation |


<!-- END_TF_DOCS -->