# CHANGELOG

## 2.0.0 05/04/2024

- **[BREAKING CHANGE]** Introduce the ability the declare "policy_definition_groups" in the module input, then leverage "group_index" to reference the group in the policy set definition. This requires an updated data input structure for the module. A second unit test shows the updated data structure without declaring definition groups.

**_policy_definition_groups_**

```PowerShell
//This is a new mandatory attribute, configuration is optional
    "policy_definition_groups": []

//This is an example of the new data structure populated with the new policy definition groups
    "policy_definition_groups": [
      {
        "name": "Azure_Security_Benchmark_v3.0_NS-1",
        "additionalMetadataId": "/providers/Microsoft.PolicyInsights/policyMetadata/Azure_Security_Benchmark_v3.0_NS-1"
      },
      {
        "name": "Azure_Security_Benchmark_v3.0_NS-2",
        "additionalMetadataId": "/providers/Microsoft.PolicyInsights/policyMetadata/Azure_Security_Benchmark_v3.0_NS-2"
      }
    ],
```

**_group_names_**

```PowerShell
//This is a new mandatory attribute, configuration is optional
    "builtin_policies": [
      {
        "policy_def_id": "<insert policy definition id here>",
        "group_names": []
      }
    ]

//This is an example of the new data structure populated with the new group names
    "builtin_policies": [
      {
        "policy_def_id": "a7aca53f-2ed4-4466-a25e-0b45ade68efd",
        "group_names": ["Azure_Security_Benchmark_v3.0_NS-1"]
      },
      {
        "policy_def_id": "dfc212af-17ea-423a-9dcb-91e2cb2caa6b",
        "group_names": ["Azure_Security_Benchmark_v3.0_NS-1"]
      },
    ]
```

## 1.0.0 05/04/2024

- Initial module creation.

---

**_CHANGELOG Notes_**

- _Add new changelog entries to the top of the file_
- _Document changes to module inputs (vars) and outputs_
- _Highlight breaking changes using the notation:_ **[BREAKING CHANGE]**
