<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_netapp_account.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/netapp_account) | resource |
| [azurerm_netapp_pool.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/netapp_pool) | resource |
| [azurerm_key_vault_secret.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault_secret) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_dns_servers"></a> [dns\_servers](#input\_dns\_servers) | A list of DNS server IP addresses for the Active Directory domain. Only allows IPv4 address. | `list(string)` | n/a | yes |
| <a name="input_domain"></a> [domain](#input\_domain) | The name of the Active Directory domain. | `string` | `"onprem.local."` | no |
| <a name="input_key_vault_id"></a> [key\_vault\_id](#input\_key\_vault\_id) | The KeyVault Secret Name containing the password associated with the 'username'. | `string` | n/a | yes |
| <a name="input_key_vault_secret_name"></a> [key\_vault\_secret\_name](#input\_key\_vault\_secret\_name) | The KeyVault Secret Name containing the password associated with the 'username'. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_netapp_account_name"></a> [netapp\_account\_name](#input\_netapp\_account\_name) | The name of the NetApp Account. | `string` | n/a | yes |
| <a name="input_netapp_pool_name"></a> [netapp\_pool\_name](#input\_netapp\_pool\_name) | The name of the NetApp Pool. | `string` | n/a | yes |
| <a name="input_organizational_unit"></a> [organizational\_unit](#input\_organizational\_unit) | The Organizational Unit (OU) within the Active Directory Domain. | `string` | `null` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of Resources Group | `string` | n/a | yes |
| <a name="input_service_level"></a> [service\_level](#input\_service\_level) | The name of the NetApp Pool. | `string` | `"Premium"` | no |
| <a name="input_size_in_tb"></a> [size\_in\_tb](#input\_size\_in\_tb) | The name of the NetApp Pool. | `number` | `4` | no |
| <a name="input_smb_server_name"></a> [smb\_server\_name](#input\_smb\_server\_name) | The NetBIOS name which should be used for the NetApp SMB Server, which will be registered as a computer account in the AD and used to mount volumes. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags of the MS SQL Server. | `map(string)` | `null` | no |
| <a name="input_username"></a> [username](#input\_username) | The Username of Active Directory Domain Administrator. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The NetApp Account ID. |
| <a name="output_netapp_pool_id"></a> [netapp\_pool\_id](#output\_netapp\_pool\_id) | The NetApp Pool ID. |
<!-- END_TF_DOCS -->