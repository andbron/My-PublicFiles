# CHANGELOG (aligned to versions.tf)
## [4.0.13] - [2023-12-01]

### Added

- Added Secure boot setting and vTPM security setting.This needs VM image upgrade to Gen2
 
## [4.0.12] - [2023-11-20]

### Fixed

- Fix tag inheritance for child modules via AzApi
- Fix tag inheritance for extensions
- Deny public endpoint for managed disk (OS) via AzApi

## [4.0.11] - [2023-11-20]

### Changed

- was skipped to align with the Win VM module

## [4.0.10] - [2023-07-27]

### Changed

- added a sleep bootstrap script

## [4.0.9] - [2023-07-27]

### Changed

- added proxy variablesi in the ADO agent bootstrap script

## [4.0.8] - [2023-06-27]

### Changed

- updated install.sh file to update the DNS config
- Removed lifecycle block to allow for updates for tags.
- Aligned outputs.

## [4.0.7] - [2023-06-20]

### Changed

-updated CSE scripts includes:
-computername (this is used to calculate the splunk clientName value as well as the DevOps agent name)
-updated syntax in both install_with_ado_as_root_with_apps scripts to resolve post application install issues

## [4.0.6] - [2023-05-19]

### Changed

-updated CSE scripts includes:
-add splunk log rotate
-custom dns config
-recover deleted lifecycle block on CSE
-expose telstra_dns attribute (env/region iLB DNS bind9 service)

## [4.0.5] - [2023-05-15]

### Changed

- update guest configuration extention

## [4.0.4] - [2023-05-03]

### Changed

- updated the install.sh script.

## [4.0.3] - [2023-04-27]

### Changed

- Added Lifecycle Ignore Changes tag to CSE Settings attribute

## [4.0.2] - [2023-04-24]

### Changed

- Removed special character from install.sh to fix newrelic installation.
- Changed the order of CommVault configuration.
- Formatted install.sh.

## [4.0.1] - [2023-04-20]

### Changed

- Updated install.sh to include the configs for RHEL VM.

## [4.0.0] - [2023-04-19]

### Changed

- Generalise Custom Script Extension by using one object parameter.
- Generalise Cloud Init File Variables by using one object parameter to identify all variables and values used.

## [3.0.8] - [2023-04-11]

### Changed

- Guest configuration assignment changed to LinuxNoPasswordForSSH

## [3.0.7] - [2023-04-10]

### Added

- Guest configuration extention

## [3.0.6] - [2023-04-10]

### Features

- Guest configuration extention assignment
- use_managed_identity parameter default value changed to true

### Removed

- Guest configuration extention

## [3.0.5] - [2023-04-06]

### Features

- Add guest configuration extention

## [3.0.4] - [2023-03-29]

### Changed

- Add managed identity principal ID output

## [3.0.3] - [2023-03-29]

### Changed

- Updated nic ip configuration primary value to 'true'.

## [3.0.2] - [2023-03-16]

### Changed

- Removed the 'splunk' name from custom script extension.

## [3.0.1] - [2023-03-10]

### Changed

- Added Admin ssh key in lifecycle ignore to fixed Vm drop issue.

## [3.0.0] - [2023-03-07]

### Changed

- Included new variable exposed in Custom Script Extension agent installation script

## [2.0.2] - [2023-02-21]

### Changed

- Updated the code for static/dynamic IP address

## [2.0.1] - [2023-02-20]

### Changed

- Added Identity Type as paremeter so UserAssigned identity can also be enabled

## [2.0.0] - [2023-02-17]

### Changed

- Added a cloud init configuration file using the custom data attribute. This script is optional (by using the enable_cloudinit variable) to get VM to download and install the ADO agent binaries then register as an agent in the declared ADO agent pool. Script called install_ado_agent.tpl and is located in the scripts subfolder - all scripts now move to sub folder

## [1.0.4] - [2023-02-09]

### Changed

- Updated variable name relickey to newrelickey

## [1.0.3] - [2023-02-06]

### Features

- Added code to install splunk agent

## [1.0.2] - [2022-12-12]

### Features

- Added ssh key instead of user/password

## [1.0.1] - [2022-12-07]

### Added

- Initialization
