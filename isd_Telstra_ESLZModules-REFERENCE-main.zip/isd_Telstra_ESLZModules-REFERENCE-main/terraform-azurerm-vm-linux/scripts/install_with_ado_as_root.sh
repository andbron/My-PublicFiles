#!/bin/sh

# This script is created for the ADO custom agent builds based of a Telstra Ubuntu golden image.

## Newrelic config part ##
    if grep -q "${key}" "/etc/newrelic-infra.yml"; then
        echo "Newrelic already configured"
    else
        echo "license_key: ${key}" > /etc/newrelic-infra.yml
        echo "proxy: http://${newrelic_proxy}" >> /etc/newrelic-infra.yml
    fi
## Newrelic config part ends##


## DNS Config ##
## Refer lines 83-87
## DNS Config ends ##


## Splunk Installation and config part ##

    # Get the os name
    os_name=$(cat /etc/os-release | grep -w NAME | cut -d= -f2 | tr -d '"')
    service_status=$(systemctl is-active SplunkForwarder)
    if [ "$service_status" != "running" ]; then
    # Check if the os is ubuntu or rhel
    if [ "$os_name" == "Red Hat Enterprise Linux Server" ]; then
        yum install /home/linux-soe/splunkforwarder-9.0.2-17e00c557dc1-linux-2.6-x86_64.rpm -y
        chmod +0777 /home/clearhostname.sh
        bash -c "/home/clearhostname.sh" # This script is required to set the correct hostname for commvault

    else
        tar -xvzf /home/splunk/splunk/splunk-linux.tar -C /home/splunk/
        dpkg -i /home/splunk/splunkforwarder-9.0.3-dd0128b1f8cd-linux-2.6-amd64.deb
    fi

    # Common splunk config part
    mkdir -p /opt/splunkforwarder/etc/apps/onesplunk_ds/local

    echo "[target-broker:deploymentServer]" > /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "targetUri = ${splunk_targeturi}" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "[deployment-client]" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf
    echo "clientName = OneSplunk-UF-${network}-${env}-${appname}-${computername}" >> /opt/splunkforwarder/etc/apps/onesplunk_ds/local/deploymentclient.conf

    bash -c '/opt/splunkforwarder/bin/splunk enable boot-start -systemd-managed 1 -user splunk --accept-license --answer-yes --auto-ports --no-prompt'

    chown  -R splunk:splunk /opt/splunkforwarder/

    systemctl start SplunkForwarder

    else
        echo "Splunk already configured"
    fi

    # Splunk log rotate config part
    if [ "$os_name" == "Red Hat Enterprise Linux Server" ]; then
        cat << EOF > /etc/logrotate.d/Splunk_syslogs_permissions
/var/log/waagent.log
/var/log/messages
/var/log/dmesg
/var/log/secure
/var/log/audit/audit.log
{
      weekly
      maxsize 100M
      su root root
      rotate 4
      create 0640 root root
      dateext
      compress
      postrotate
            /usr/bin/setfacl -m g:splunk:r /var/log/waagent.log
            /usr/bin/setfacl -m g:splunk:r /var/log/messages
            /usr/bin/setfacl -m g:splunk:r /var/log/dmesg
            /usr/bin/setfacl -m g:splunk:r /var/log/secure
            /usr/bin/setfacl -m g:splunk:r /var/log/audit/audit.log
      endscript
}
EOF
        sudo logrotate -vf Splunk_syslogs_permissions
    else
        cat << EOF > /etc/logrotate.d/Splunk_syslogs_permissions
/var/log/syslog
/var/log/auth.log
/var/log/kern.log
/var/log/waagent.log
/var/log/audit/audit.log
{
    weekly
    maxsize 100M
    su root adm
    rotate 4
    create 0640 root  adm
    dateext
    compress
    postrotate
            /usr/bin/setfacl -m g:splunk:r /var/log/syslog
            /usr/bin/setfacl -m g:splunk:r /var/log/auth.log
            /usr/bin/setfacl -m g:splunk:r /var/log/kern.log
            /usr/bin/setfacl -m g:splunk:r /var/log/waagent.log
            /usr/bin/setfacl -m g:splunk:r /var/log/audit/audit.log
    endscript
}
EOF
        sudo logrotate -vf Splunk_syslogs_permissions
    fi

## Splunk Installation and config part ends##


## Config commvault ##
## Not applicable for ADO custom agents
## Config commvault ends ##


## cleanup part ##
    # This will remove all the files and folders which are not needed
    for file in "/home/clearhostname.sh" "/home/clearhostname.service" "/home/clearhostname.sh" "/home/rhel7securitybaseline.py" "/home/securitycheck.py" "/tmp/sshd_banner" "/home/linux-soe"; do
        if [ -e "$file" ]; then
            
            rm -rf "$file"
            #echo "Removed $file"
        else
            echo "$file does not exist or removed previously"
        fi
    done

## cleanup part ends ##


############################### Azure DevOps Agent Install and Pool Registration ########################################

sudo echo -e 'Acquire::http::Proxy "http://proxy.nexus.telstra.com.au:8080";\nAcquire::https::Proxy "http://proxy.nexus.telstra.com.au:8080";\n' > /etc/apt/apt.conf
sudo echo -e 'azure-user ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/waagent

sudo echo -e "DNS=${telstra_dns}\nFallbackDNS=168.63.129.16\n" >> /etc/systemd/resolved.conf
sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf
sudo service systemd-resolved restart 1> /dev/null 2> /dev/null
## To manually check DNS run: systemd-resolve --status

sudo echo 'export AGENT_ALLOW_RUNASROOT="1"' >> /root/.profile
sudo echo 'export VSTS_HTTP_PROXY="http://proxy.nexus.telstra.com.au:8080"' >> /root/.profile
sudo echo 'export VSTS_HTTPS_PROXY="http://proxy.nexus.telstra.com.au:8080"' >> /root/.profile
sudo echo 'export http_proxy="http://proxy.nexus.telstra.com.au:8080"' >> /root/.profile
sudo echo 'export https_proxy="http://proxy.nexus.telstra.com.au:8080"' >> /root/.profile
sudo echo 'export no_proxy="169.254.169.254,168.63.129.16,*.blob.core.windows.net,*.file.core.windows.net,*.table.core.windows.net,*.vault.azure.net"' >> /root/.profile
sudo echo 'export use_proxy="yes"' >> /root/.profile

sudo -s <<EOF
source /root/.profile

echo "[$(date +%F_%T)] Starting DevOp Agent download and install"
mkdir /azagent;cd /azagent

echo "#####################################################################################" >> ./ado_cloud_init.log
whoami >> ./ado_cloud_init.log
echo "#####################################################################################" >> ./ado_cloud_init.log

echo "[$(date +%F_%T)] Output rutime variable values" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] server_url: ${server_url}" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] vers: ${vers}" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] pool_name: ${pool_name}" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] proxy_url: ${proxy_url}" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] no_proxy: $no_proxy" >> ./ado_cloud_init.log

echo "[$(date +%F_%T)] $(pwd)" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] Starting DevOp Agent download and install" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] set environment variables for proxy" >> ./ado_cloud_init.log

echo "[$(date +%F_%T)] Downloading Agent from https://vstsagentpackage.azureedge.net/agent/${vers}/vsts-agent-linux-x64-${vers}.tar.gz" >> ./ado_cloud_init.log
wget https://vstsagentpackage.azureedge.net/agent/${vers}/vsts-agent-linux-x64-${vers}.tar.gz

echo "[$(date +%F_%T)] Setting agent proxy" >> ./ado_cloud_init.log
echo http://proxy.nexus.telstra.com.au:8080 > .proxy

echo "[$(date +%F_%T)] Extracting Agent" >> ./ado_cloud_init.log
tar -zxvf vsts-agent-linux-x64-${vers}.tar.gz
chmod ugo+rwx -R /azagent

echo "[$(date +%F_%T)] Running installdependencies.sh" >> ./ado_cloud_init.log
sudo ./bin/installdependencies.sh

echo "#####################################################################################" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] Running config.sh" >> ./ado_cloud_init.log

export AGENT_ALLOW_RUNASROOT="1"
echo "[$(date +%F_%T)] AGENT_ALLOW_RUNASROOT: $AGENT_ALLOW_RUNASROOT" >> ./ado_cloud_init.log
./config.sh --unattended --url ${server_url} --auth pat --token ${pat_token} --pool ${pool_name} --agent ${computername}-01 --work _work --acceptTeeEula --replace --proxyurl ${proxy_url}
chmod ugo+rwx -R /azagent
sudo chown -R root /azagent

echo "#####################################################################################" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] Running svc.sh" >> ./ado_cloud_init.log
sudo ./svc.sh install
sudo ./svc.sh start
STR='${proxy_bypass}'; echo "$STR" > /azagent/.proxybypass

############################### Second Azure DevOps Agent Install and Pool Registration #################################

echo "[$(date +%F_%T)] Create second agent folder" >> ./ado_cloud_init.log
mkdir /azagent2
cp -p vsts-agent-linux-x64-${vers}.tar.gz /azagent2/;cd /azagent2
chmod ugo+rwx -R /azagent2

echo "[$(date +%F_%T)] Extracting Agent2" >> ./ado_cloud_init.log
tar -zxvf vsts-agent-linux-x64-${vers}.tar.gz
chmod ugo+rwx -R /azagent2

echo "#####################################################################################" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] Running agent2 config.sh" >> ./ado_cloud_init.log

./config.sh --unattended --url ${server_url} --auth pat --token ${pat_token} --pool ${pool_name} --agent ${computername}-02 --work _work --acceptTeeEula --replace --proxyurl ${proxy_url}
chmod ugo+rwx -R /azagent2
sudo chown -R root /azagent2

echo "#####################################################################################" >> ./ado_cloud_init.log
echo "[$(date +%F_%T)] Running agent2 svc.sh" >> ./ado_cloud_init.log
sudo ./svc.sh install
sudo ./svc.sh start
STR='${proxy_bypass}'; echo "$STR" > /azagent2/.proxybypass

EOF
