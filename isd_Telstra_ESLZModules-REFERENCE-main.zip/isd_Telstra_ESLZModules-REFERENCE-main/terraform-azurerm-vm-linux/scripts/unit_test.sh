#!/bin/sh
export VSTS_HTTP_PROXY=http://proxy.nexus.telstra.com.au:8080
export VSTS_HTTPS_PROXY=http://proxy.nexus.telstra.com.au:8080
export http_proxy=http://proxy.nexus.telstra.com.au:8080
export https_proxy=http://proxy.nexus.telstra.com.au:8080
export use_proxy=yes


