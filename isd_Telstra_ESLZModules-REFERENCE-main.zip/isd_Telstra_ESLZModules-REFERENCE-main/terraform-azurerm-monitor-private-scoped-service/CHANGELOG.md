# CHANGELOG (aligned to versions.tf)
## [1.0.1] - [2022-12-27]
### Added
- Initial code