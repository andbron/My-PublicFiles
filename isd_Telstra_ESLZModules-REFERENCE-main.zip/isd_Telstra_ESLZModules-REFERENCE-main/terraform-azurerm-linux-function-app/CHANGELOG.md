# CHANGELOG (aligned to versions.tf)
## [1.0.3] - [2023-11-15]

### Added

- App setting   FUNCTION_APP_EDIT_MODE   as readonly
- Added validation to disallow cors origin as *


## [1.0.0] - [2023-08-23]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
