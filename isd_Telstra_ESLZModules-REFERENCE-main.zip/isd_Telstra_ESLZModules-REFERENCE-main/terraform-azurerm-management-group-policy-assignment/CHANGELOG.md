# CHANGELOG (aligned to version.tf)

## [2.0.0] - [2024-03-06]

### Changed

-Replaced AZAPI policy exemption resource with a call to the new policy exemption module.
This resolves an issue with the use of azapi where Terraform incorrectly tries to update the exemption instead of replacing it when the assignment name changes, causing the apply to fail.

## [1.0.3] - [2023-04-04]

### Fixed

- policyDefinitionReferenceIds was only taking single policy id instead of list

## [1.0.2] - [2023-03-24]

### Added

- Added AzApi Resource to add policy exception in management group

## [1.0.1] - [2022-12-12]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
