# CHANGELOG (aligned to versions.tf)
## [1.0.7] - [2023-011-20]
### Added
- Changed Variables.tf to update Allowed origin validation condition

## [1.0.6] - [2023-05-09]
### Fix
- Fixed SKU Name validation condition

## [1.0.5] - [2023-03-08]
### Added
- Add use_32_bit_worker variable

## [1.0.4] - [2023-03-08]
### Added
- Fixed ip_restriction bug
- Added client_certificate_mode variable to comply with Security Baseline Standard update

## [1.0.3] - [2023-02-22]
### Added
- Additional Output for app_service_principal_id

## [1.0.2] - [2023-01-13]
### Added
- Security baseline changes are done

## [1.0.1] - [2022-12-27]
### Added
- Initialization
