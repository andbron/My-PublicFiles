# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.2] - [2022-02-09]

### Features

- - Align code with security baseline

## [1.0.1] - [2022-12-02]

### Added

- - Initialization

### Added

### Changed

### Fixed

### Features
