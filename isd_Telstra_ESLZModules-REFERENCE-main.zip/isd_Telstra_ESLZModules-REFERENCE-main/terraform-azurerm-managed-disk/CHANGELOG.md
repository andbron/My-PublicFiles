# CHANGELOG (aligned to versions.tf)
## [1.0.6] - [2023-11-09]

### Changed

- Updated module to align with new sandbox environment.
- Updated examples/main.tf to add Keyvault, Storage, Vnet, Subnet, KV role definition data resources to use existing coresponding resources
- Updated examples/main.tf to use latest VM module . Added splunk and new relic configuration.
- Updated examples/main.tf to add sleep resource to let role assignment come into action.

## [1.0.5] - [2023-07-05]

### Changed

- Updated variable value from null to DenyAll for network_access_policy.

## [1.0.4] - [2023-07-03]

### Changed

- Removed provider block added in last version.

## [1.0.3] - [2023-06-22]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.3] - [2023-05-30]

### Added

- Remove public_network_access_enabled parameter and set static value as false.

## [1.0.2] - [2023-04-05]

### Added

- Added code to support data disk attachment for VM.
- Made disk encryption set id mandatory field.

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
