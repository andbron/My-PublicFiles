<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_storage_management_policy.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_management_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_blob_types"></a> [blob\_types](#input\_blob\_types) | An array of predefined values. Valid options are blockBlob and appendBlob. | `string` | `"blockBlob"` | no |
| <a name="input_delete_after_last_access_greater_than"></a> [delete\_after\_last\_access\_greater\_than](#input\_delete\_after\_last\_access\_greater\_than) | (Optional) The age in days after last access time to delete the blob. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_delete_after_modification_greater_than"></a> [delete\_after\_modification\_greater\_than](#input\_delete\_after\_modification\_greater\_than) | (Optional) The age in days after last modification to delete the blob. Must be between 0 and 99999. | `number` | `365` | no |
| <a name="input_delete_blobsnapshot_creation_greater_than"></a> [delete\_blobsnapshot\_creation\_greater\_than](#input\_delete\_blobsnapshot\_creation\_greater\_than) | (Optional) The age in days after creation to delete the blob version. Must be between 0 and 99999. | `number` | `365` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Boolean to specify whether the rule is enabled. | `bool` | `true` | no |
| <a name="input_match_blob_index_tag"></a> [match\_blob\_index\_tag](#input\_match\_blob\_index\_tag) | (Optional) A match\_blob\_index\_tag block as defined below. The block defines the blob index tag based filtering for blob objects. | `map(any)` | <pre>{<br>  "name": null,<br>  "operation": null,<br>  "value": null<br>}</pre> | no |
| <a name="input_move_blobsnapshot_to_archive_after_creation"></a> [move\_blobsnapshot\_to\_archive\_after\_creation](#input\_move\_blobsnapshot\_to\_archive\_after\_creation) | (Optional) The age in days after creation to tier blob snapshot to archive storage. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_move_blobsnapshot_to_cool_after_creation"></a> [move\_blobsnapshot\_to\_cool\_after\_creation](#input\_move\_blobsnapshot\_to\_cool\_after\_creation) | (Optional) The age in days after creation to tier blob snapshot to cool storage. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_move_to_archive_access_time_greater_than"></a> [move\_to\_archive\_access\_time\_greater\_than](#input\_move\_to\_archive\_access\_time\_greater\_than) | (Optional) The age in days after last access time to tier blobs to archive storage. Supports blob currently at Hot or Cool tier. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_move_to_archive_modification_greater_than"></a> [move\_to\_archive\_modification\_greater\_than](#input\_move\_to\_archive\_modification\_greater\_than) | (Optional) The age in days after last modification to tier blobs to archive storage. Supports blob currently at Hot or Cool tier. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_move_to_cool_access_time_greater_than"></a> [move\_to\_cool\_access\_time\_greater\_than](#input\_move\_to\_cool\_access\_time\_greater\_than) | (Optional) The age in days after last access time to tier blobs to cool storage. Supports blob currently at Hot tier. Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_move_to_cool_modification_greater_than"></a> [move\_to\_cool\_modification\_greater\_than](#input\_move\_to\_cool\_modification\_greater\_than) | (Optional) The age in days after last modification to tier blobs to cool storage. Supports blob currently at Hot tier.  Must be between 0 and 99999. | `number` | `null` | no |
| <a name="input_name"></a> [name](#input\_name) | The name of the rule. Rule name is case-sensitive. It must be unique within a policy. | `string` | n/a | yes |
| <a name="input_prefix_match"></a> [prefix\_match](#input\_prefix\_match) | (Optional) An array of strings for prefixes to be matched. | `list(string)` | `[]` | no |
| <a name="input_storage_account_id"></a> [storage\_account\_id](#input\_storage\_account\_id) | The id of the storage account to apply the management policy to. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The ID of the Storage Account Management Policy.. |
<!-- END_TF_DOCS -->