# CHANGELOG (aligned to versions.tf)

## [1.0.3] - [2023-03-30]

### Added

- Added time_rotating resource for expiration date

## [1.0.2] - [2023-01-09]

### Fixed
- Provider versions inconsistancy.
```
"hashicorp/azurerm"
      version = "~>3.25"
```
## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
