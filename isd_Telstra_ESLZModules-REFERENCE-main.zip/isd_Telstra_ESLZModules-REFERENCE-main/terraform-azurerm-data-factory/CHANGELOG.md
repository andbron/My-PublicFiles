# CHANGELOG (aligned to versions.tf)

## [1.0.7] - [2023-07-27]

### Changed

- Added Key Vault Secrets User role assignment to the user-assigned managed identity

## [1.0.6] - [2023-07-10]

### Changed

- Added tags to user-assigned managed identity

## [1.0.5] - [2023-06-30]

### Changed

- Provider version to remain consistent
- Cleaning up and removing commented code

## [1.0.4] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Added outputs.

## [1.0.3] - [2023-04-28]

### Features

- Azure Data Factory Multiple Integration Runtimes Support(SSIS,SHIR,Azure)

## [1.0.2] - [2023-03-31]

### Features

- Azure Data Factory Customer Managed Key

## [1.0.1] - [2023-03-23]

### Added

- Azure Data Factory

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
