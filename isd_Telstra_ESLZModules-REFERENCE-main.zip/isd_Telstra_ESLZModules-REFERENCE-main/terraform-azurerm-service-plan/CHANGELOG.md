# CHANGELOG (aligned to versions.tf)
## [1.0.0] - [2023-08-21]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
