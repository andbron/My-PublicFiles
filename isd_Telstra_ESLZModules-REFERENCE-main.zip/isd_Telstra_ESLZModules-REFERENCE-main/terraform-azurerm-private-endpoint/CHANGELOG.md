# CHANGELOG (aligned to versions.tf)
## [1.0.3] - [2023-11-20]
### Fixed

- Fix tag inheritance for child modules via AzApi

## [1.0.2] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
