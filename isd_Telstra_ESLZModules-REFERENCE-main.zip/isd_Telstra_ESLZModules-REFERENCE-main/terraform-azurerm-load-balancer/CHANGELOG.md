# CHANGELOG (aligned to versions.tf)
## [1.0.5] - [2023-11-24]

### Changed

- Updated validation for SKU in Variables.tf to add Gateway sku as per baseline.

## [1.0.3] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.3] - [2023-04-26]

### Changed

- Updated code to support private IP address only.

## [1.0.2] - [2022-03-08]

### Added

- Support for multiple backend address pool associations

## [1.0.1] - [2022-12-01]

### Added

- Added code to work for both public and private , backend address pool associations
