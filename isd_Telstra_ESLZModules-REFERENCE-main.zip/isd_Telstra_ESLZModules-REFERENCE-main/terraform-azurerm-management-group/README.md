<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.38.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_management_group.firstlayermgs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_group) | resource |
| [azurerm_management_group.secondlayermgs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_group) | resource |
| [azurerm_management_group.thirdlayermgs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_group) | resource |
| [azurerm_management_group.parent](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/management_group) | data source |
| [azurerm_management_group.parentname](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/management_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_managementgroup_first_layer_list"></a> [managementgroup\_first\_layer\_list](#input\_managementgroup\_first\_layer\_list) | First layer Management group list | <pre>map(object({<br>    display_name               = string<br>    parent_management_group_id = string<br>    subscription_ids           = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_managementgroup_second_layer_list"></a> [managementgroup\_second\_layer\_list](#input\_managementgroup\_second\_layer\_list) | Second layer Management group list | <pre>map(object({<br>    display_name               = string<br>    parent_management_group_id = string<br>    subscription_ids           = list(string)<br>  }))</pre> | `null` | no |
| <a name="input_managementgroup_third_layer_list"></a> [managementgroup\_third\_layer\_list](#input\_managementgroup\_third\_layer\_list) | Third layer Management group list | <pre>map(object({<br>    display_name               = string<br>    parent_management_group_id = string<br>    subscription_ids           = list(string)<br>  }))</pre> | `null` | no |
| <a name="input_parent_management_group"></a> [parent\_management\_group](#input\_parent\_management\_group) | Parent management group name | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_first_layer_mg_id"></a> [first\_layer\_mg\_id](#output\_first\_layer\_mg\_id) | management group resource id of first layer management group |
<!-- END_TF_DOCS -->
