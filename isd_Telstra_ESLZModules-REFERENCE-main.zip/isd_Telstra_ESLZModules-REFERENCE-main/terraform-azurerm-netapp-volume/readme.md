<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.37 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.37 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_netapp_volume.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/netapp_volume) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_netapp_account_name"></a> [netapp\_account\_name](#input\_netapp\_account\_name) | The name of the NetApp Account in which the NetApp Volume should be created.. | `string` | n/a | yes |
| <a name="input_netapp_pool_name"></a> [netapp\_pool\_name](#input\_netapp\_pool\_name) | The name of the NetApp pool in which the NetApp Volume should be created. | `string` | n/a | yes |
| <a name="input_netapp_volume_name"></a> [netapp\_volume\_name](#input\_netapp\_volume\_name) | The name of the NetApp Volume. | `string` | n/a | yes |
| <a name="input_network_features"></a> [network\_features](#input\_network\_features) | Indicates which network feature to use, accepted values are Basic or Standard. | `string` | `"Basic"` | no |
| <a name="input_protocols"></a> [protocols](#input\_protocols) | The target volume protocol expressed as a list. Supported single value include CIFS, NFSv3, or NFSv4.1. Dual protocol scenario is supported for CIFS and NFSv3 | `list(string)` | <pre>[<br>  "NFSv3"<br>]</pre> | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of Resources Group | `string` | n/a | yes |
| <a name="input_security_style"></a> [security\_style](#input\_security\_style) | Volume security style, accepted values are Unix or Ntfs. If not provided, single-protocol volume is created defaulting to Unix if it is NFSv3 or NFSv4.1 volume, if CIFS, it will default to Ntfs. In a dual-protocol volume, if not provided, its value will be Ntfs | `string` | `null` | no |
| <a name="input_service_level"></a> [service\_level](#input\_service\_level) | The target performance of the file system. Valid values include Premium, Standard, or Ultra. | `string` | `"Premium"` | no |
| <a name="input_snapshot_directory_visible"></a> [snapshot\_directory\_visible](#input\_snapshot\_directory\_visible) | Specifies whether the .snapshot (NFS clients) or ~snapshot (SMB clients) path of a volume is visible. | `bool` | `true` | no |
| <a name="input_storage_quota_in_gb"></a> [storage\_quota\_in\_gb](#input\_storage\_quota\_in\_gb) | The maximum Storage Quota allowed for a file system in Gigabytes. | `number` | `100` | no |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The ID of the Subnet the NetApp Volume resides in, which must have the Microsoft.NetApp/volumes delegation. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags of the MS SQL Server. | `map(string)` | `null` | no |
| <a name="input_volume_path"></a> [volume\_path](#input\_volume\_path) | A unique file path for the volume. Used when creating mount targets. | `string` | `"my-unique-file-path"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The NetApp Volume ID. |
| <a name="output_mount_ip_addresses"></a> [mount\_ip\_addresses](#output\_mount\_ip\_addresses) | A list of IPv4 Addresses which should be used to mount the volume. |
<!-- END_TF_DOCS -->