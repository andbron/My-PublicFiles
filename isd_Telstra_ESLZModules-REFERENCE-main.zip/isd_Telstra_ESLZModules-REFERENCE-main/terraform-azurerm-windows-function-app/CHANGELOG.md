# CHANGELOG (aligned to versions.tf)
## [1.0.3] - [2023-11-16]

### Added

- App setting   FUNCTION_APP_EDIT_MODE   as readonly
- Added validation to disallow cors origin as *
- Changed examples/main.tf for using existing Storage and Subnet 

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
