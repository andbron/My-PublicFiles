## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | 2.30.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.70 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.70 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_windows_function_app.windows_funct_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_function_app) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allowed_origins"></a> [allowed\_origins](#input\_allowed\_origins) | Specifies a list of origins that should be allowed to make cross-origin calls.Only needed when cors\_rule\_enabled is `true` | `list(string)` | `[]` | no |
| <a name="input_always_on"></a> [always\_on](#input\_always\_on) | If this windows Web App is Always On enabled. | `bool` | `false` | no |
| <a name="input_api_definition_url"></a> [api\_definition\_url](#input\_api\_definition\_url) | The URL of the API definition that describes this windows Function App. | `string` | `null` | no |
| <a name="input_api_management_api_id"></a> [api\_management\_api\_id](#input\_api\_management\_api\_id) | The ID of the API Management API for this windows Function App. | `string` | `null` | no |
| <a name="input_app_command_line"></a> [app\_command\_line](#input\_app\_command\_line) | The App command line to launch. | `string` | `null` | no |
| <a name="input_app_function_name"></a> [app\_function\_name](#input\_app\_function\_name) | The name which should be used for this windows Function App. Changing this forces a new windows Function App to be created. | `string` | n/a | yes |
| <a name="input_app_scale_limit"></a> [app\_scale\_limit](#input\_app\_scale\_limit) | The number of workers this function app can scale out to. Only applicable to apps on the Premium plan | `number` | `null` | no |
| <a name="input_app_settings"></a> [app\_settings](#input\_app\_settings) | A map of key-value pairs of App Settings. | `any` | `null` | no |
| <a name="input_application_insights_connection_string"></a> [application\_insights\_connection\_string](#input\_application\_insights\_connection\_string) | The Connection String for linking the windows Function App to Application Insights | `string` | `null` | no |
| <a name="input_application_stack"></a> [application\_stack](#input\_application\_stack) | Application Stack for windows function app. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#application_stack | `map(any)` | <pre>{<br>  "dotnet_version": "v6.0"<br>}</pre> | no |
| <a name="input_auth_settings"></a> [auth\_settings](#input\_auth\_settings) | auth settings for linux function. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#auth_settings | `map(any)` | `null` | no |
| <a name="input_auth_settings_v2"></a> [auth\_settings\_v2](#input\_auth\_settings\_v2) | auth settings version2 for linux function. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#auth_settings_v2 | `map(any)` | `null` | no |
| <a name="input_client_certificate_enabled"></a> [client\_certificate\_enabled](#input\_client\_certificate\_enabled) | Should the function app use Client Certificates. | `bool` | `true` | no |
| <a name="input_client_certificate_mode"></a> [client\_certificate\_mode](#input\_client\_certificate\_mode) | The mode of the Function App's client certificates requirement for incoming requests. Possible values are Required, Optional, and OptionalInteractiveUser | `string` | `"Required"` | no |
| <a name="input_connection_string"></a> [connection\_string](#input\_connection\_string) | Database connection details for the function. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#connection_string | `map(string)` | `null` | no |
| <a name="input_cors_rule_enabled"></a> [cors\_rule\_enabled](#input\_cors\_rule\_enabled) | Is cors rule enabled? | `bool` | `false` | no |
| <a name="input_elastic_instance_minimum"></a> [elastic\_instance\_minimum](#input\_elastic\_instance\_minimum) | The number of minimum instances for this windows Function App. Only affects apps on Elastic Premium plans. | `number` | `null` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Is the Function App enabled?. | `bool` | `true` | no |
| <a name="input_health_check_path"></a> [health\_check\_path](#input\_health\_check\_path) | The path to be checked for this function app health. | `string` | `null` | no |
| <a name="input_http2_enabled"></a> [http2\_enabled](#input\_http2\_enabled) | Should the HTTP2 be enabled? | `bool` | `true` | no |
| <a name="input_ip_restriction"></a> [ip\_restriction](#input\_ip\_restriction) | IP Restriction for function app. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#ip_restriction | `map(any)` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure Region where the windows Function App should exist. Changing this forces a new windows Function App to be created. | `string` | n/a | yes |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | Should public network access be enabled for the Function App. | `bool` | `false` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the windows function App should exist. Changing this forces a new windows function App to be created. | `string` | n/a | yes |
| <a name="input_scm_ip_restriction"></a> [scm\_ip\_restriction](#input\_scm\_ip\_restriction) | SCM IP Restriction for function app. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#scm_ip_restriction | `map(any)` | `null` | no |
| <a name="input_service_plan_id"></a> [service\_plan\_id](#input\_service\_plan\_id) | The ID of the App Service Plan within which to create this Function App. | `string` | n/a | yes |
| <a name="input_storage_account"></a> [storage\_account](#input\_storage\_account) | storage account for function app. For more information see https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/windows_function_app#storage_account | `map(any)` | `null` | no |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | The backend storage account name which will be used by this Function App. | `string` | n/a | yes |
| <a name="input_support_credentials"></a> [support\_credentials](#input\_support\_credentials) | Whether CORS requests with credentials are allowed.Only needed when cors\_rule\_enabled is `true` | `bool` | `false` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(any)` | `null` | no |
| <a name="input_virtual_network_subnet_id"></a> [virtual\_network\_subnet\_id](#input\_virtual\_network\_subnet\_id) | The subnet id which will be used by this Function App for regional virtual network integration | `string` | `null` | no |
| <a name="input_zip_deploy_file"></a> [zip\_deploy\_file](#input\_zip\_deploy\_file) | The local path and filename of the zip packaged application to deploy to this windows Function App | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_custom_domain_verification_id"></a> [custom\_domain\_verification\_id](#output\_custom\_domain\_verification\_id) | The identifier used by App Service to perform domain ownership verification via DNS TXT record. |
| <a name="output_default_hostname"></a> [default\_hostname](#output\_default\_hostname) | The default hostname of the Windows Function App |
| <a name="output_id"></a> [id](#output\_id) | The ID of the Windows function app. |
| <a name="output_identity"></a> [identity](#output\_identity) | The Principal ID associated with this Managed Service Identity |
| <a name="output_kind"></a> [kind](#output\_kind) | The Kind value for this Windows Function App. |
| <a name="output_outbound_ip_address_list"></a> [outbound\_ip\_address\_list](#output\_outbound\_ip\_address\_list) | A list of outbound IP addresses - IE. 52.23.25.3, 52.143.43.12 |
| <a name="output_outbound_ip_addresses"></a> [outbound\_ip\_addresses](#output\_outbound\_ip\_addresses) | A comma separated list of outbound IP addresses - IE 52.23.25.3,52.143.43.12. |\n