# CHANGELOG (aligned to versions.tf)
## [1.0.4] - [2023-07-27]

- Added service endpoint policy ID support

## [1.0.3] - [2023-03-16]

- adjusted service_delegation_name

## [1.0.2] - [2022-12-02]

- init

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
