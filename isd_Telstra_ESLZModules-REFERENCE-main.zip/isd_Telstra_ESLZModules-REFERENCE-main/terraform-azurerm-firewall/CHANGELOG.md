# CHANGELOG (aligned to versions.tf)

## [1.0.7] - [2023-10-24]

### Added

- Make the optional variable "public_ip_address_id" the condition for the public ip resource block, if a variable value is passed into the module call then a blank map is used by the for_each loop suppressing the creation of new public ip resources

## [1.0.6] - [2023-10-24]

### Added

- Make "intrusion detection" optional as "standard" firewall policies do not have this option

## [1.0.5] - [2023-10-24]

### Added

- Ability to request N number of public IP addresses to be associated with firewall when using new variable "firewall_public_ip_count". NOTE: Its default is "1" so when provisioning multiple IP's variable "public_ip_address_id" must not be passed to module
- Optionally pass in a custom PIP prefix if using the above "firewall_public_ip_count" variable
- Added policy insights block, defaults to false (disabled)

### Changed

- Made passing in an external public IP Resource Id as optional. This is for backwards compatibility as this update has internalised the creation of N number of PIP's

## [1.0.4] - [2023-08-03]

### Added

- DNS block

### Changed

- Threat_intelligence_mode and Intrusion_detection_mode passed as variable.

## [1.0.3] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.3] - [2023-03-20]

### Fixed

- Moved Private IP range block from Firewall to Firewall policy

## [1.0.2] - [2022-02-06]

### Changed

- Aligned code as per design

## [1.0.1] - [2022-12-05]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
