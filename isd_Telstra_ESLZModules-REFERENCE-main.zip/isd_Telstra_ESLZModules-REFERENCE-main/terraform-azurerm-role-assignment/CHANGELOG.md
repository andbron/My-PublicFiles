# CHANGELOG (aligned to versions.tf)
## [2.0.0] - [2023-12-01]

### Changed

- Set `ignore_changes` for `role_definition_id` to avoid unnecessary changes.
- Removed `for_each` in order to support external loops.

## [1.0.3] - [2022-12-23]

### Changed

- Changed from using `"role_definition_name"` to `"role_definition_id"`. This will be able to do assignments even if there is a lag in replicating custom roles

## [1.0.2] - [2022-12-23]

### Changed

- Changed `"principal_id"` from string to list
- Added for_each loop to be able to deploy same assignments type for various principal_id(s)
- Output is full details of role assignments. Can be revisited to select specific details and in which format once a requirement is needed.

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
