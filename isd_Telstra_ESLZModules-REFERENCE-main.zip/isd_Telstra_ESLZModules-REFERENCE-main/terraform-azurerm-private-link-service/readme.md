<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | =3.25.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | =3.25.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_link_service.this](https://registry.terraform.io/providers/hashicorp/azurerm/3.25.0/docs/resources/private_link_service) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_auto_approval_subscription_ids"></a> [auto\_approval\_subscription\_ids](#input\_auto\_approval\_subscription\_ids) | A list of Subscription UUID/GUID's that will be automatically be able to use this Private Link Service. | `set(string)` | `null` | no |
| <a name="input_enable_proxy_protocol"></a> [enable\_proxy\_protocol](#input\_enable\_proxy\_protocol) | Should the Private Link Service support the Proxy Protocol? Defaults to false. | `bool` | `"false"` | no |
| <a name="input_fqdns"></a> [fqdns](#input\_fqdns) | List of FQDNs allowed for the Private Link Service. | `list(string)` | `null` | no |
| <a name="input_load_balancer_frontend_ip_configuration_ids"></a> [load\_balancer\_frontend\_ip\_configuration\_ids](#input\_load\_balancer\_frontend\_ip\_configuration\_ids) | A list of Frontend IP Configuration ID's from a Standard Load Balancer, where traffic from the Private Link Service should be routed. You can use Load Balancer Rules to direct this traffic to appropriate backend pools where your applications are running. | `list(string)` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. | `string` | n/a | yes |
| <a name="input_nat_ip_configuration_name"></a> [nat\_ip\_configuration\_name](#input\_nat\_ip\_configuration\_name) | Specifies the name which should be used for the NAT IP Configuration.. | `string` | n/a | yes |
| <a name="input_private_ip_address"></a> [private\_ip\_address](#input\_private\_ip\_address) | Specifies a Private Static IP Address for this IP Configuration. | `string` | n/a | yes |
| <a name="input_private_ip_address_version"></a> [private\_ip\_address\_version](#input\_private\_ip\_address\_version) | The version of the IP Protocol which should be used. At this time the only supported value is IPv4. Defaults to IPv4. | `string` | `"IPv4"` | no |
| <a name="input_private_link_service_name"></a> [private\_link\_service\_name](#input\_private\_link\_service\_name) | Specifies the name of this Private Link Service. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the Private Link Service should exist. | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The ID of the Subnet from which Private IP Addresses will be allocated for this Private Endpoint. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `null` | no |
| <a name="input_visibility_subscription_ids"></a> [visibility\_subscription\_ids](#input\_visibility\_subscription\_ids) | A list of Subscription UUID/GUID's that will be able to see this Private Link Service. | `set(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_alias"></a> [alias](#output\_alias) | A globally unique DNS Name for your Private Link Service. You can use this alias to request a connection to your Private Link Service. |
| <a name="output_id"></a> [id](#output\_id) | The ID of Private Link Service. |
<!-- END_TF_DOCS -->
