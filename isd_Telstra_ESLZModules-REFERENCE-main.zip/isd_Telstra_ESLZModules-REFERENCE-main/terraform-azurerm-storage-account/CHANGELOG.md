# CHANGELOG (aligned to versions.tf)

## [2.0.14] - [2024-01-23]

### Changed

- Automatically adds rotation policy for the keys getting created. Defined three variables rotation_policy_time_after_creation, rotation_policy_expire_after and rotation_policy_notify_before_expiry for rotation policy.

## [2.0.13] - [2023-12-20]

- Automatically adds new mandatory tag needed to enable Splunk logging 

## [2.0.12] - [2023-11-24]

### Changed

- Updated Allowed and Exposed headers default value  in variables.tf. [*] is not allowed

## [2.0.11] - [2023-11-17]

### Changed

- Added support for Splunk access via splunk_network_access var. This turns on public network access for specific IP addresses only
- Removed the ability to specifiy network rules

## [2.0.10] - [2023-10-20]

### Changed

- Re-added support for shared access keys, allowed for Azure Functions as per CSB https://confluence.tools.telstra.com/display/NCCS/Azure+Functions

- Updated examples to work with new sandbox

## [2.0.9] - [2023-08-25]

### Changed

- Updated to enforce Cloud Security Baseline removing the ability to change mandatory parameters through input variables
- Added missing tags on vault key resource
- Fixed bug so that http is disallowed for kerberos-based storage account

## [2.0.8] - [2023-08-14]

### Changed

- Added support for adls by adding hierachical namespace config.
- Minor update to adhere to the latest cloud service baseline.

## [2.0.7] - [2023-07-13]

### Changed

- Added lifecycle block to for CMK changes.

## [2.0.6] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for CMK changes such as key auto-rotation.

## [2.0.5] - [2023-06-21]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Enabling automated key rotation.

## [2.0.4] - [2023-06-07]

- Remove condition of public_network_access_enabled in resource azurerm_storage_account_network_rules

## [2.0.3] - [2023-05-16]

- Default Public network disabled
- Default SAS disbaled
- Removed role assignment given to Agents
- Removed Advanced Threat protection

## [2.0.2] - [2023-04-12]

### Changed

- Added condition on Blob_properties to not run for FileStorage kind of Storage Accounts

## [2.0.1] - [2023-04-06]

### Added

- Added Advance threat protection resource

## [2.0.0] - [2023-03-30]

### Changed

- SAS enabled to support Public Monitoring Zone

## [1.0.9] - [2023-03-28]

### Changed

- Added variables for expiration dates for key vault secrets and CMK

## [1.0.8] - [2023-03-27]

### Changed

- Fixed Kerberos
- Made CMK default

## [1.0.7] - [2023-03-07]

### Changed

- Integrated kerbos.

## [1.0.6] - [2023-02-15]

### Changed

- Removed the access policy resource.

## [1.0.5] - [2022-01-18]

### Added

- Remove tag from lifecycle ignore_changes.

## [1.0.4] - [2022-12-27]

### Added

- Implemented cloud security baseline.

## [1.0.3] - [2022-12-22]

### Added

- Added DependOn for cmk access issue.

## [1.0.2] - [2022-12-21]

### Changed

- Set secrets/keys expiration time for 1 year.

## [1.0.1] - [2022-12-2]

### Fixed

- Removed data source of keyvault.
