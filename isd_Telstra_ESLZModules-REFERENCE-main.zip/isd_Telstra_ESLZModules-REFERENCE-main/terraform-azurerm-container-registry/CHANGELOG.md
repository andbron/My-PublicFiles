# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-11-28]

### Added
- Modified code to support Encryption using CMK 
- Modified to default to Premium SKU as Mandate from Baseline


## [1.0.1] - [2022-12-20]

### Added
- Initialization
