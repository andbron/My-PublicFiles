<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.25 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.25 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall_policy_rule_collection_group.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy_rule_collection_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_firewall_policy_id"></a> [firewall\_policy\_id](#input\_firewall\_policy\_id) | The ID of the Firewall Policy where the Firewall Policy Rule Collection Group should exist. | `string` | n/a | yes |
| <a name="input_firewall_policy_rule_collection_group"></a> [firewall\_policy\_rule\_collection\_group](#input\_firewall\_policy\_rule\_collection\_group) | Map containing  Firewall Rule Collections | <pre>map(object({<br>    name     = string<br>    priority = number<br>    application_rule_collections = list(object({<br>      name     = string<br>      priority = number<br>      action   = string<br>      rules = list(object({<br>        protocols = list(object({<br>          type = string<br>          port = number<br>        }))<br>        name                  = string<br>        description           = string<br>        source_addresses      = list(string)<br>        source_ip_groups      = list(string)<br>        destination_addresses = list(string)<br>        destination_urls      = list(string)<br>        destination_fqdn_tags = list(string)<br>        destination_fqdns     = list(string)<br>        terminate_tls         = bool<br>        web_categories        = list(string)<br>      }))<br>    }))<br>    network_rule_collections = list(object({<br>      name     = string<br>      priority = number<br>      action   = string<br>      rules = list(object({<br>        name                  = string<br>        source_addresses      = list(string)<br>        source_ip_groups      = list(string)<br>        destination_addresses = list(string)<br>        destination_fqdns     = list(string)<br>        destination_ip_groups = list(string)<br>        destination_ports     = list(string)<br>        protocols             = list(string)<br>      }))<br>    }))<br>    nat_rule_collections = list(object({<br>      name     = string<br>      priority = number<br>      action   = string<br>      rules = list(object({<br>        name                = string<br>        source_addresses    = list(string)<br>        source_ip_groups    = list(string)<br>        destination_ports   = list(string)<br>        destination_address = string<br>        translated_port     = number<br>        translated_address  = string<br>        translated_fqdn     = string<br>        protocols           = list(string)<br>      }))<br>    }))<br>  }))</pre> | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
