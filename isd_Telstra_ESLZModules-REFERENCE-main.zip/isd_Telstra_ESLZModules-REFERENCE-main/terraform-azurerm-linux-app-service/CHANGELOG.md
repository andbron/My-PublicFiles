# CHANGELOG (aligned to versions.tf)
## [1.0.3] - [2023-11-15]
- Client certificate mode is parameterized with default as Optional
- Cors Validation is added to variable.tf  for not containing * as origin

### Added
- Security baseline changes are done
## [1.0.2] - [2022-01-18]

### Added
- Security baseline changes are done
## [1.0.1] - [2022-12-27]

### Added

### Added
- Initialization
