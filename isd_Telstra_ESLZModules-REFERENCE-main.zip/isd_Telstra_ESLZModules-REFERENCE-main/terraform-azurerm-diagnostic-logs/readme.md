<!-- BEGIN_TF_DOCS -->

## Requirements

| Name                                                                     | Version |
| ------------------------------------------------------------------------ | ------- |
| <a name="requirement_terraform"></a> [terraform](#requirement_terraform) | >=1.3.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement_azurerm)       | ~>3.25  |

## Providers

| Name                                                         | Version |
| ------------------------------------------------------------ | ------- |
| <a name="provider_azurerm"></a> [azurerm](#provider_azurerm) | ~>3.25  |

## Modules

No modules.

## Resources

| Name                                                                                                                                                           | Type        |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| [azurerm_monitor_diagnostic_setting.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting)          | resource    |
| [azurerm_monitor_diagnostic_categories.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/monitor_diagnostic_categories) | data source |

## Inputs

| Name                                                                                                                        | Description                                                                                                                                     | Type           | Default | Required |
| --------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | -------------- | ------- | :------: |
| <a name="input_eventhub_authorization_rule_id"></a> [eventhub_authorization_rule_id](#input_eventhub_authorization_rule_id) | Specifies the ID of an Event Hub Namespace Authorization Rule used to send Diagnostics Data. Changing this forces a new resource to be created. | `string`       | `null`  |    no    |
| <a name="input_eventhub_name"></a> [eventhub_name](#input_eventhub_name)                                                    | Specifies the name of the Event Hub where Diagnostics Data should be sent. Changing this forces a new resource to be created.                   | `string`       | `null`  |    no    |
| <a name="input_log_analytics_workspace_id"></a> [log_analytics_workspace_id](#input_log_analytics_workspace_id)             | Specifies the ID of a Log Analytics Workspace where Diagnostics Data should be sent.                                                            | `string`       | `null`  |    no    |
| <a name="input_logs_categories"></a> [logs_categories](#input_logs_categories)                                              | The name of a Diagnostic Log Category for this Resource.                                                                                        | `list(string)` | `null`  |    no    |
| <a name="input_logs_category_group"></a> [logs_category_group](#input_logs_category_group)                                  | The name of a Diagnostic Log Category Groups for this Resource.                                                                                 | `list(string)` | `null`  |    no    |
| <a name="input_metrics"></a> [metrics](#input_metrics)                                                                      | Metrics to add.                                                                                                                                 | `list(string)` | `null`  |    no    |
| <a name="input_name"></a> [name](#input_name)                                                                               | Specifies the name of the Diagnostic Setting. Changing this forces a new resource to be created.                                                | `string`       | n/a     |   yes    |
| <a name="input_storage_account_id"></a> [storage_account_id](#input_storage_account_id)                                     | The ID of the Storage Account where logs should be sent. Changing this forces a new resource to be created.                                     | `string`       | `null`  |    no    |
| <a name="input_target_resource_id"></a> [target_resource_id](#input_target_resource_id)                                     | The ID of an existing Resource on which to configure Diagnostic Settings. Changing this forces a new resource to be created.                    | `string`       | n/a     |   yes    |

## Outputs

| Name                                      | Description                       |
| ----------------------------------------- | --------------------------------- |
| <a name="output_id"></a> [id](#output_id) | The ID of the Diagnostic Setting. |

<!-- END_TF_DOCS -->
