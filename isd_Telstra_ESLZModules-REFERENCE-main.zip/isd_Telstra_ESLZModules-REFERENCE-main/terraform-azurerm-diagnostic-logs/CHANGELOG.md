# CHANGELOG (aligned to versions.tf)

## [1.0.7] - [2024-01-25]

### Changed

- Removed `retention_policy`

## [1.0.6] - [2023-08-14]

### Added

- Removed `retention_policy` Azure has removed the retention setting in `azurerm_monitor_diagnostic_setting` resource.

## [1.0.5] - [2023-07-13]

### Added

- Added `logs_category_groups` to support log category groups.
- Added `retention_policy` variable.

## [1.0.4] - [2023-04-17]

### Changed

- Updated code as `log` has been superseded by `enabled_log`.

## [1.0.3] - [2022-12-21]

### Changed

- Added version.tf file

## [1.0.2] - [2022-12-21]

### Changed

- Make Log Analytics Resource Id optional

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
