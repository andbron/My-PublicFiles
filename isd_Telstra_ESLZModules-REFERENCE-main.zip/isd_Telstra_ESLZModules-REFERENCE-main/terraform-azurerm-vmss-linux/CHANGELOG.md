# CHANGELOG (aligned to versions.tf)
# [1.0.3] - [2023-12-01]

### Added

- Added Secure boot setting and vTPM security setting.This needs VM image upgrade to Gen2
 

## [1.0.0] - [2023-06-22]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features