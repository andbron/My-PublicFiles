# CHANGELOG (aligned to versions.tf)

## [1.0.7] - [2024-02-12]

### Changed

- Automatically adds rotation policy for the keys getting created. Defined three variables rotation_policy_time_after_creation, rotation_policy_expire_after and rotation_policy_notify_before_expiry for rotation policy.
- Auto key rotation for disk encryption set can be enabled only with key vault key with a versionless ID.

## [1.0.6] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.6] - [2023-04-03]

### Added

- Added lifecycle ignore for tag.

## [1.0.5] - [2023-03-31]

### Added

- Added time_rotating resource for expiration date
- expiration_date parameter added

## [1.0.4] - [2023-02-27]

### Fixed

- No need to pass parameter for scope

## [1.0.3] - [2023-02-27]

### Fixed

- Key vault key , role assignment creation

## [1.0.2] - [2023-01-06]

### Fixed

- Azure key vault key functionality has been removed from the module.

## [1.0.1] - [2022-12-07]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
