# Changed
- disabled default classic application insight as it will be retired in feb 24
## [1.0.3] - [2024-02-16]


# CHANGELOG (aligned to versions.tf)

## [1.0.2] - [2023-11-30]

### Changed
- Disabled local Authentication as per Azure Baseline

- Initialization
## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added
### Changed
### Fixed
### Features
