# CHANGELOG (aligned to versions.tf)

## [1.0.1] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
