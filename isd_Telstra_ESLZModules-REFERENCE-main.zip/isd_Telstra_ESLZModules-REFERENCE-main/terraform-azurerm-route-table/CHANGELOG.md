# CHANGELOG (aligned to versions.tf)

## [1.0.1] - [2023-06-29]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.1] - [2023-03-23]

- added empty routes as default
-

## [1.0.1] - [yyyy-mm-dd]

### Added

- Initialization

### Added

### Changed

### Fixed

### Features
