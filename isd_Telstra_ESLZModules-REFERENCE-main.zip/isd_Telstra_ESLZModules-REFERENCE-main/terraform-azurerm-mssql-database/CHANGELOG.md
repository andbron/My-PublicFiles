# CHANGELOG (aligned to versions.tf)

## [1.0.7] - [2023-11-24]

### Changed

- Edited Auditing policy log retention to default to 0 (unlimited) as per Azure baseline

## [1.0.5] - [2023-07-07]

### Changed

- Removed lifecycle block to allow for updates for tags.
- Retained module version.

## [1.0.5] - [2023-05-08]

### Added

Fix bug with serverless local variable with SKUs without underscores (\_)

## [1.0.4] - [2023-02-23]

### Added

Removed data blocks from inside module

## [1.0.3] - [2023-02-21]

### Added

Added support for Serverless SKUs

## [1.0.2] - [2023-01-04]

### Added

Audit Log Settings

## [1.0.1] - [2023-01-03]

### Added

Initial base module
