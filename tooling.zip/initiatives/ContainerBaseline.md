# Initiative: ContainerInstanceBaseline

## Included Policies

The following policy definitions are already included in the existing Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\ContainerBaseline.json*]:

Security Principles | Name                 | Description          | Link
:------------------ | :---                 | :----------          | :---
[Incubation Governance] Monitoring | Enable logging by category group for Container instances (microsoft.containerinstance/containergroups) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Container instances (microsoft.containerinstance/containergroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f85779c9a-7fdf-4294-937c-ded183166fa8)
[Incubation Governance] Restrict Network Access | Azure Container Instance container group should deploy into a virtual network | Secure communication between your containers with Azure Virtual Networks. When you specify a virtual network, resources within the virtual network can securely and privately communicate with each other. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f8af8f826-edcb-4178-b35f-851ea6fea615)

### Security Principles Coverage

#### Included

Coverage of the following Security Principles was detected in this initiative. These  principles may still require additional controls to ensure full coverage.

- [Incubation Governance] Monitoring

- [Incubation Governance] Restrict Network Access

#### Not Included

Coverage of the following Security Principles was not detected in this initiative. These  principles may not be applicable, or may be addressed by some other means. Additional action may be required to ensure coverage of these principles.

- [Incubation Governance] Access Control

- [Incubation Governance] Encryption

- [Incubation Governance] Patching and Updates

- [Incubation Governance] Security Posture Management

## Recommended Policies

The following policy definitions are recommended for inclusion in the Policy Initiative. The recommendations are based on the following keyword searches [*public,private endpoint,private link,firewall,diagnostic,defender,logs,logging,DNS Zone,deploy into a virtual network*] in the following policy categories [*Security Center,Monitoring,Security Center - Granular Pricing,General*]:

Security Principles | Name | Description | Link
:------------------ | :--- | :---------- | :---
[Incubation Governance] Monitoring,[Incubation Governance] Patching and Updates | Configure diagnostics for container group to log analytics workspace | Appends the specified log analytics workspaceId and workspaceKey when any container group which is missing these fields is created or updated. Does not modify the fields of container groups created before this policy was applied until those resource groups are changed. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f21c469fa-a887-4363-88a9-60bfd6911a15)
[Incubation Governance] Monitoring,[Incubation Governance] Patching and Updates | Configure diagnostic settings for container groups to Log Analytics workspace | Deploys the diagnostic settings for Container Instance to stream resource logs to a Log Analytics workspace when any container instance which is missing this diagnostic settings is created or updated. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f41ebf9df-66cb-48e9-a8d0-98afb4e150ce)

## Other Policies

The following policy definitions are most likely related to the target service, but are not included in the automated recommendations. These policy definitions can be added manually to the Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\ContainerBaseline.json*] if required

Name | Description | Link
:--- | :---------- | :---
Azure Container Instance container group should use customer-managed key for encryption | Secure your containers with greater flexibility using customer-managed keys. When you specify a customer-managed key, that key is used to protect and control access to the key that encrypts your data. Using customer-managed keys provides additional capabilities to control rotation of the key encryption key or cryptographically erase data. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0aa61e00-0a01-4a3c-9945-e93cffedf0e6)

## Excluded Policies

The following policy definitions are excluded from the recommendations. The exclusions are based on the following keyword searches [*Deprecated,to Event Hub,Enable logging.*to storage*] and policy definitions [**].These policy definitions can be added manually to the Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\ContainerBaseline.json*] if required

Name | Description | Link
:--- | :---------- | :---
Enable logging by category group for Container instances (microsoft.containerinstance/containergroups) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Container instances (microsoft.containerinstance/containergroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f60ad0a9f-f760-45ff-ab94-4c64d7439f18)
Enable logging by category group for Container instances (microsoft.containerinstance/containergroups) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Container instances (microsoft.containerinstance/containergroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc600af08-49ff-4f7a-b5c9-0686749387b7)

## Resource Types

### Allowed

- Microsoft.ContainerInstance/containerGroups

- Microsoft.ContainerInstance/serviceAssociationLinks

- Microsoft.ContainerInstance/locations

- Microsoft.ContainerInstance/locations/capabilities

- Microsoft.ContainerInstance/locations/usages

- Microsoft.ContainerInstance/locations/operations

- Microsoft.ContainerInstance/locations/operationresults

- Microsoft.ContainerInstance/operations

- Microsoft.ContainerInstance/locations/cachedImages

- Microsoft.ContainerInstance/locations/validateDeleteVirtualNetworkOrSubnets

- Microsoft.ContainerInstance/locations/deleteVirtualNetworkOrSubnets

- Microsoft.ContainerInstance/containerGroupProfiles
