# Initiative: NetworkServicesBaseline

## Included Policies

The following policy definitions are already included in the existing Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\NetworkServicesBaseline.json*]:

Security Principles | Name                 | Description          | Link
:------------------ | :---                 | :----------          | :---
[Incubation Governance] Restrict Network Access | Azure Web Application Firewall should be enabled for Azure Front Door entry-points | Deploy Azure Web Application Firewall (WAF) in front of public facing web applications for additional inspection of incoming traffic. Web Application Firewall (WAF) provides centralized protection of your web applications from common exploits and vulnerabilities such as SQL injections, Cross-Site Scripting, local and remote file executions. You can also restrict access to your web applications by countries, IP address ranges, and other http(s) parameters via custom rules. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f055aa869-bc98-4af8-bafc-23f1ab6ffe2c)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.network/networksecurityperimeters to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.network/networksecurityperimeters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0ebe872d-7029-4292-88bc-ad3e2cf3772f)
[Incubation Governance] Monitoring | Enable logging by category group for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f1118afbc-c48d-43ae-931a-87b38956d40b)
[Incubation Governance] Restrict Network Access | Web Application Firewall (WAF) should use the specified mode for Application Gateway | Mandates the use of 'Detection' or 'Prevention' mode to be active on all Web Application Firewall policies for Application Gateway. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f12430be1-6cc8-4527-a9a8-e3d38f250096)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Enable logging by category group for Public IP addresses (microsoft.network/publicipaddresses) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Public IP addresses (microsoft.network/publicipaddresses). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f1513498c-3091-461a-b321-e9b433218d28)
[Incubation Governance] Monitoring | Enable logging by category group for Network Managers (microsoft.network/networkmanagers) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Network Managers (microsoft.network/networkmanagers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f23673f24-2594-43e9-9983-60a0be21bd76)
[Incubation Governance] Monitoring | Enable logging by category group for Virtual networks (microsoft.network/virtualnetworks) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Virtual networks (microsoft.network/virtualnetworks). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f3234ff41-8bec-40a3-b5cb-109c95f1c8ce)
[Incubation Governance] Restrict Network Access | Web Application Firewall (WAF) should use the specified mode for Azure Front Door Service | Mandates the use of 'Detection' or 'Prevention' mode to be active on all Web Application Firewall policies for Azure Front Door Service. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f425bea59-a659-4cbb-8d31-34499bd030b8)
[Incubation Governance] Restrict Network Access | Azure Web Application Firewall on Azure Front Door should have request body inspection enabled | Ensure that Web Application Firewalls associated to Azure Front Doors have request body inspection enabled. This allows the WAF to inspect properties within the HTTP body that may not be evaluated in the HTTP headers, cookies, or URI. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f4598f028-de1f-4694-8751-84dceb5f86b9)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.networkfunction/azuretrafficcollectors to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.networkfunction/azuretrafficcollectors. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f60579569-3633-42cb-ae6a-195080bf310d)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.network/networkmanagers/ipampools to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.network/networkmanagers/ipampools. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f6ee1c58c-a123-4cd6-8643-48b2f7ffb3e1)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Public IP addresses should have resource logs enabled for Azure DDoS Protection | Enable resource logs for public IP addressess in diagnostic settings to stream to a Log Analytics workspace. Get detailed visibility into attack traffic and actions taken to mitigate DDoS attacks via notifications, reports and flow logs. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f752154a7-1e0f-45c6-a880-ac75a7e4f648)
[Incubation Governance] Restrict Network Access | Network interfaces should not have public IPs | This policy denies the network interfaces which are configured with any public IP. Public IP addresses allow internet resources to communicate inbound to Azure resources, and Azure resources to communicate outbound to the internet. This should be reviewed by the network security team. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f83a86a26-fd1f-447c-b59d-e51f44264114)
[Incubation Governance] Monitoring | Enable logging by category group for Load balancers (microsoft.network/loadbalancers) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Load balancers (microsoft.network/loadbalancers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f889bfebf-7428-426e-a86f-79e2a7de2f71)
[Incubation Governance] Monitoring | Enable logging by category group for Application gateways (microsoft.network/applicationgateways) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Application gateways (microsoft.network/applicationgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f92012204-a7e4-4a95-bbe5-90d0d3e12735)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Enable logging by category group for Public IP Prefixes (microsoft.network/publicipprefixes) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Public IP Prefixes (microsoft.network/publicipprefixes). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb55f2e8e-dc76-4262-a0e3-45f02200ff0e)
[Incubation Governance] Monitoring | Enable logging by category group for Network security groups (microsoft.network/networksecuritygroups) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Network security groups (microsoft.network/networksecuritygroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fbaa4c6de-b7cf-4b12-b436-6e40ef44c8cb)
[Incubation Governance] Monitoring | Enable logging by category group for ExpressRoute circuits (microsoft.network/expressroutecircuits) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for ExpressRoute circuits (microsoft.network/expressroutecircuits). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc5ecf495-6caa-445c-b431-04fda56c555a)
[Incubation Governance] Restrict Network Access | Azure Web Application Firewall on Azure Application Gateway should have request body inspection enabled | Ensure that Web Application Firewalls associated to Azure Application Gateways have Request body inspection enabled. This allows the WAF to inspect properties within the HTTP body that may not be evaluated in the HTTP headers, cookies, or URI. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fca85ef9a-741d-461d-8b7a-18c2da82c666)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.network/p2svpngateways to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.network/p2svpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fcac9e1c5-c3cb-47fa-8d4c-88b8559262d2)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.network/vpngateways to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.network/vpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fd8624de8-47fe-47c0-bea0-2d8329b628fe)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.network/dnsresolverpolicies to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.network/dnsresolverpolicies. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fdc1b5908-da05-4eed-a988-c5e32fdb682d)
[Incubation Governance] Monitoring | Enable logging by category group for Front Door and CDN profiles (microsoft.network/frontdoors) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Front Door and CDN profiles (microsoft.network/frontdoors). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe9c56c41-d453-4a80-af93-2331afeb3d82)
[Incubation Governance] Monitoring | Enable logging by category group for Virtual network gateways (microsoft.network/virtualnetworkgateways) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Virtual network gateways (microsoft.network/virtualnetworkgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fed6ae75a-828f-4fea-88fd-dead1145f1dd)
[Incubation Governance] Monitoring | Enable logging by category group for Bastions (microsoft.network/bastionhosts) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Bastions (microsoft.network/bastionhosts). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ff8352124-56fa-4f94-9441-425109cdc14b)
[Incubation Governance] Restrict Network Access | [Preview]: All Internet traffic should be routed via your deployed Azure Firewall | Azure Security Center has identified that some of your subnets aren't protected with a next generation firewall. Protect your subnets from potential threats by restricting access to them with Azure Firewall or a supported next generation firewall | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ffc5e4038-4584-4632-8c85-c0448d374b2c)

### Security Principles Coverage

#### Included

Coverage of the following Security Principles was detected in this initiative. These  principles may still require additional controls to ensure full coverage.

- [Incubation Governance] Monitoring

- [Incubation Governance] Restrict Network Access

#### Not Included

Coverage of the following Security Principles was not detected in this initiative. These  principles may not be applicable, or may be addressed by some other means. Additional action may be required to ensure coverage of these principles.

- [Incubation Governance] Access Control

- [Incubation Governance] Encryption

- [Incubation Governance] Patching and Updates

- [Incubation Governance] Security Posture Management

## Recommended Policies

The following policy definitions are recommended for inclusion in the Policy Initiative. The recommendations are based on the following keyword searches [*public,private endpoint,private link,firewall,diagnostic,defender,logs,logging,DNS Zone,deploy into a virtual network*] in the following policy categories [*network,Security Center,Monitoring,Security Center - Granular Pricing,General*]:

Security Principles | Name | Description | Link
:------------------ | :--- | :---------- | :---
[Incubation Governance] Monitoring | Configure virtual networks to enforce workspace, storage account and retention interval for Flow logs and Traffic Analytics | If a virtual network already has traffic analytics enabled, then, this policy will overwrite its existing settings with the ones provided during policy creation. Traffic analytics is a cloud-based solution that provides visibility into user and application activity in cloud networks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f052c180e-287d-44c3-86ef-01aeae2d9774)
[Incubation Governance] Monitoring | Enable logging by category group for microsoft.networkanalytics/dataproducts to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.networkanalytics/dataproducts. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0e861bb0-d926-4cdb-b2d6-d59336b8f5b3)
[Incubation Governance] Monitoring | Network Watcher flow logs should have traffic analytics enabled | Traffic analytics analyzes flow logs to provide insights into traffic flow in your Azure cloud. It can be used to visualize network activity across your Azure subscriptions and identify hot spots, identify security threats, understand traffic flow patterns, pinpoint network misconfigurations and more. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2f080164-9f4d-497e-9db6-416dc9f7b48a)
[Incubation Governance] Restrict Network Access | Azure Firewall should be deployed to span multiple Availability Zones | For increased availability we recommend deploying your Azure Firewall to span multiple Availability Zones. This ensures that your Azure Firewall will remain available in the event of a zone failure. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f3e1f521a-d037-4709-bdd6-1f532f271a75)
[Incubation Governance] Restrict Network Access | Azure Firewall Policy should have DNS Proxy Enabled | Enabling DNS Proxy will make the Azure Firewall associated with this policy to listen on port 53 and forward the DNS requests to specified DNS server | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f3f84c9b0-8b64-4208-98d4-6ada96bb49c3)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Configure Azure Monitor Private Link Scope to use private DNS zones | Use private DNS zones to override the DNS resolution for a private endpoint. A private DNS zone links to your virtual network to resolve to Azure Monitor private link scope. Learn more at: https://docs.microsoft.com/azure/azure-monitor/logs/private-link-security#connect-to-a-private-endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f437914ee-c176-4fff-8986-7e05eb971365)
[Incubation Governance] Monitoring | Audit flow logs configuration for every virtual network | Audit for virtual network to verify if flow logs are configured. Enabling flow logs allows to log information about IP traffic flowing through virtual network. It can be used for optimizing network flows, monitoring throughput, verifying compliance, detecting intrusions and more. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f4c3c6c5f-0d47-4402-99b8-aa543dd8bcee)
[Incubation Governance] Restrict Network Access | Web Application Firewall (WAF) should be enabled for Application Gateway | Deploy Azure Web Application Firewall (WAF) in front of public facing web applications for additional inspection of incoming traffic. Web Application Firewall (WAF) provides centralized protection of your web applications from common exploits and vulnerabilities such as SQL injections, Cross-Site Scripting, local and remote file executions. You can also restrict access to your web applications by countries, IP address ranges, and other http(s) parameters via custom rules. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f564feb30-bf6a-4854-b4bb-0d2d2d1e6c66)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Enable logging by category group for Firewalls (microsoft.network/azurefirewalls) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Firewalls (microsoft.network/azurefirewalls). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f5fcf46f9-194c-47ff-8889-380f57ae4617)
[Incubation Governance] Restrict Network Access | Virtual Hubs should be protected with Azure Firewall | Deploy an Azure Firewall to your Virtual Hubs to protect and granularly control internet egress and ingress traffic. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f72923a3a-e567-46d3-b3f9-ffb2462a1c3a)
[Incubation Governance] Monitoring | Configure Packet Core Control Plane diagnostic access to use authentication type Microsoft EntraID | Authenticaton type must be Microsoft EntraID for packet core diagnostic access over local APIs | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f7508b186-60e2-4518-bf70-3d7fbaba1f3a)
[Incubation Governance] Restrict Network Access | Azure Firewall Classic Rules should be migrated to Firewall Policy | Migrate from Azure Firewall Classic Rules to Firewall Policy to utilize central management tools such as Azure Firewall Manager. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f794d77cc-fe65-4801-8514-230c0be387a8)
[Incubation Governance] Restrict Network Access | Azure Firewall Standard - Classic Rules should enable Threat Intelligence | Threat intelligence-based filtering can be enabled for your firewall to alert and deny traffic from/to known malicious IP addresses and domains. The IP addresses and domains are sourced from the Microsoft Threat Intelligence feed. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f7c591a93-c34c-464c-94ac-8f9f9a46e3d6)
[Incubation Governance] Monitoring | Audit diagnostic setting for selected resource types | Audit diagnostic setting for selected resource types. Be sure to select only resource types which support diagnostics settings. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f7f89b1eb-583c-429a-8828-af049802c1d9)
[Incubation Governance] Monitoring | Azure Application Gateway should have Resource logs enabled | Enable Resource logs for Azure Application Gateway (plus WAF) and stream to a Log Analytics workspace. Get detailed visibility into inbound web traffic and actions taken to mitigate attacks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f8a04f872-51e9-4313-97fb-fc1c3543011c)
[Incubation Governance] Monitoring | Azure Front Door should have Resource logs enabled | Enable Resource logs for Azure Front Door (plus WAF) and stream to a Log Analytics workspace. Get detailed visibility into inbound web traffic and actions taken to mitigate attacks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f8a04f872-51e9-4313-97fb-fc1c35430fd8)
[Incubation Governance] Restrict Network Access | Azure Firewall Standard should be upgraded to Premium for next generation protection | If you are looking for next generation protection like IDPS and TLS inspection, you should consider upgrading your Azure Firewall to Premium sku. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f8c19196d-7fd7-45b2-a9b4-7288f47c769a)
[Incubation Governance] Monitoring | Flow logs should be configured for every network security group | Audit for network security groups to verify if flow logs are configured. Enabling flow logs allows to log information about IP traffic flowing through network security group. It can be used for optimizing network flows, monitoring throughput, verifying compliance, detecting intrusions and more. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc251913d-7d24-4958-af87-478ed3b9ba41)
[Incubation Governance] Restrict Network Access | Azure Firewall Policy should enable Threat Intelligence | Threat intelligence-based filtering can be enabled for your firewall to alert and deny traffic from/to known malicious IP addresses and domains. The IP addresses and domains are sourced from the Microsoft Threat Intelligence feed. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fda79a7e2-8aa1-45ed-af81-ba050c153564)
[Incubation Governance] Restrict Network Access | Azure Firewall Policy Analytics should be Enabled | Enabling Policy Analytics provides enhanced visibility into traffic flowing through Azure Firewall, enabling the optimization of your firewall configuration without impacting your application performance | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fdfb5ac92-ce74-4dbc-81fa-87243e62d5d3)
[Incubation Governance] Monitoring,[Incubation Governance] Restrict Network Access | Enable resource specific logging by category group for Firewall (microsoft.network/azurefirewalls) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting  using a category group to route logs to a Log Analytics workspace with resource specific tables for Firewall (microsoft.network/azurefirewalls). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Management%2fmanagementGroups%2fcollaboration%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ffwDiagsResSpecDinePolicy)

## Other Policies

The following policy definitions are most likely related to the target service, but are not included in the automated recommendations. These policy definitions can be added manually to the Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\NetworkServicesBaseline.json*] if required

Name | Description | Link
:--- | :---------- | :---
Deploy a flow log resource with target network security group | Configures flow log for specific network security group. It will allow to log information about IP traffic flowing through an network security group. Flow log helps to identify unknown or undesired traffic, verify network isolation and compliance with enterprise access rules, analyze network flows from compromised IPs and network interfaces. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0db34a60-64f4-4bf6-bd44-f95c16cf34b9)
VPN gateways should use only Azure Active Directory (Azure AD) authentication for point-to-site users | Disabling local authentication methods improves security by ensuring that VPN Gateways use only Azure Active Directory identities for authentication. Learn more about Azure AD authentication at https://docs.microsoft.com/azure/vpn-gateway/openvpn-azure-ad-tenant | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f21a6bc25-125e-4d13-b82d-2e19b7208ab7)
All flow log resources should be in enabled state | Audit for flow log resources to verify if flow log status is enabled. Enabling flow logs allows to log information about IP traffic flowing. It can be used for optimizing network flows, monitoring throughput, verifying compliance, detecting intrusions and more. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f27960feb-a23c-4577-8d36-ef8b5f35e0be)
Bot Protection should be enabled for Azure Front Door WAF | This policy ensures that bot protection is enabled in all Azure Front Door Web Application Firewall (WAF) policies | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f27f7fb01-5fdb-44ad-954c-d582f8659533)
App Service apps should use a virtual network service endpoint | Use virtual network service endpoints to restrict access to your app from selected subnets from an Azure virtual network. To learn more about App Service service endpoints, visit https://aka.ms/appservice-vnet-service-endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2d21331d-a4c2-4def-a9ad-ee4e1e023beb)
Gateway subnets should not be configured with a network security group | This policy denies if a gateway subnet is configured with a network security group. Assigning a network security group to a gateway subnet will cause the gateway to stop functioning. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f35f9c03a-cc27-418e-9c0c-539ff999d010)
Configure virtual network to enable Flow Log and Traffic Analytics | Traffic analytics and Flow logs can be enabled for all virtual networks hosted in a particular region with the settings provided during policy creation. This policy does not overwrite current setting for virtual networks that already have these feature enabled. Traffic analytics is a cloud-based solution that provides visibility into user and application activity in cloud networks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f3e9965dc-cc13-47ca-8259-a4252fd0cf7b)
SIM Group should use customer-managed keys to encrypt data at rest | Use customer-managed keys to manage the encryption at rest of SIM secrets in a SIM Group. Customer-managed keys are commonly required to meet regulatory compliance standards and they enable the data to be encrypted with an Azure Key Vault key created and owned by you. You have full control and responsibility for the key lifecycle, including rotation and management. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f45c4e9bd-ad6b-4634-9566-c2dad2f03cbf)
A custom IPsec/IKE policy must be applied to all Azure virtual network gateway connections | This policy ensures that all Azure virtual network gateway connections use a custom Internet Protocol Security(Ipsec)/Internet Key Exchange(IKE) policy. Supported algorithms and key strengths - https://aka.ms/AA62kb0 | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f50b83b09-03da-41c1-b656-c293c914862b)
Configure network security groups to use specific workspace, storage account and flowlog retention policy for traffic analytics | If it already has traffic analytics enabled, then policy will overwrite its existing settings with the ones provided during policy creation. Traffic analytics is a cloud-based solution that provides visibility into user and application activity in cloud networks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f5e1cd26a-5090-4fdb-9d6a-84a90335e22d)
Storage Accounts should use a virtual network service endpoint | This policy audits any Storage Account not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f60d21c4f-21a3-4d94-85f4-b924e6aeeda4)
Migrate WAF from WAF Config to WAF Policy on Application Gateway | If you have WAF Config instead of WAF Policy, then you may want to move to the new WAF Policy. Going forward, the firewall policy will support WAF policy settings, managed rulesets, exclusions, and disabled rule-groups. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f882e19a6-996f-400e-a30f-c090887254f4)
Network interfaces should disable IP forwarding | This policy denies the network interfaces which enabled IP forwarding. The setting of IP forwarding disables Azure's check of the source and destination for a network interface. This should be reviewed by the network security team. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f88c0b9da-ce96-4b03-9635-f29a937e2900)
Virtual networks should be protected by Azure DDoS Protection | Protect your virtual networks against volumetric and protocol attacks with Azure DDoS Protection. For more information, visit https://aka.ms/ddosprotectiondocs. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f94de2ad3-e0c1-4caf-ad78-5d47bbc83d3d)
Deploy network watcher when virtual networks are created | This policy creates a network watcher resource in regions with virtual networks. You need to ensure existence of a resource group named networkWatcherRG, which will be used to deploy network watcher instances. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa9b99dd8-06c5-4317-8629-9d86a3c6e7d9)
SQL Server should use a virtual network service endpoint | This policy audits any SQL Server not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fae5d2f14-d830-42b6-9899-df6cfe9c71a3)
Network Watcher should be enabled | Network Watcher is a regional service that enables you to monitor and diagnose conditions at a network scenario level in, to, and from Azure. Scenario level monitoring enables you to diagnose problems at an end to end network level view. It is required to have a network watcher resource group to be created in every region where a virtual network is present. An alert is enabled if a network watcher resource group is not available in a particular region. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb6e2945c-0b7b-40f5-9233-7a5323b5cdc6)
[Preview]: Container Registry should use a virtual network service endpoint | This policy audits any Container Registry not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc4857be7-912a-4c75-87e6-e30292bcdf78)
Deploy a Flow Log resource with target virtual network | Configures flow log for specific virtual network. It will allow to log information about IP traffic flowing through an virtual network. Flow log helps to identify unknown or undesired traffic, verify network isolation and compliance with enterprise access rules, analyze network flows from compromised IPs and network interfaces. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fcd6f7aff-2845-4dab-99f2-6d1754a754b0)
Virtual machines should be connected to an approved virtual network | This policy audits any virtual machine connected to a virtual network that is not approved. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fd416745a-506c-48b6-8ab1-83cb814bcaa3)
Event Hub should use a virtual network service endpoint | This policy audits any Event Hub not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fd63edb4a-c612-454d-b47d-191a724fcbf0)
Cosmos DB should use a virtual network service endpoint | This policy audits any Cosmos DB not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe0a2b1a3-f7f9-4569-807f-2a9edebdf4d9)
Azure VPN gateways should not use 'basic' SKU | This policy ensures that VPN gateways do not use 'basic' SKU. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe345b6c3-24bd-4c93-9bbb-7e5e49a17b78)
Enable Rate Limit rule to protect against DDoS attacks on Azure Front Door WAF | The Azure Web Application Firewall (WAF) rate limit rule for Azure Front Door controls the number of requests allowed from a particular client IP address to the application during a rate limit duration. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe52e8487-4a97-48ac-b3e6-1c3cef45d298)
Configure network security groups to enable traffic analytics | Traffic analytics can be enabled for all network security groups hosted in a particular region with the settings provided during policy creation. If it already has Traffic analytics enabled, then policy does not overwrite its settings. Flow Logs are also enabled for the Network security groups that do not have it. Traffic analytics is a cloud-based solution that provides visibility into user and application activity in cloud networks. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe920df7f-9a64-4066-9b58-52684c02a091)
Key Vault should use a virtual network service endpoint | This policy audits any Key Vault not configured to use a virtual network service endpoint. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fea4d6841-2173-4317-9747-ff522a45120f)
Bot Protection should be enabled for Azure Application Gateway WAF | This policy ensures that bot protection is enabled in all Azure Application Gateway Web Application Firewall (WAF) policies | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2febea0d86-7fbd-42e3-8a46-27e7568c2525)
Virtual networks should use specified virtual network gateway | This policy audits any virtual network if the default route does not point to the specified virtual network gateway. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ff1776c76-f58c-4245-a8d0-2b207198dc8b)
Azure Application Gateway should be deployed with Azure WAF | Requires Azure Application Gateway resources to be deployed with Azure WAF.  | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fff1f1879-a60d-4f23-9641-41e7391ec19a)
Azure DDoS Protection should be enabled | DDoS protection should be enabled for all virtual networks with a subnet that is part of an application gateway with a public IP. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa7aca53f-2ed4-4466-a25e-0b45ade68efd)
Subnets should be associated with a Network Security Group | Protect your subnet from potential threats by restricting access to it with a Network Security Group (NSG). NSGs contain a list of Access Control List (ACL) rules that allow or deny network traffic to your subnet. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe71308d3-144b-4262-b144-efdc3cc90517)

## Excluded Policies

The following policy definitions are excluded from the recommendations. The exclusions are based on the following keyword searches [*microsoft.networkcloud,Deprecated,to Event Hub,Enable logging.*to storage*] and policy definitions [*/providers/Microsoft.Authorization/policyDefinitions/98a2e215-5382-489e-bd29-32e7190a39ba,/providers/Microsoft.Authorization/policyDefinitions/a4490248-cb97-4504-b7fb-f906afdb7437,/providers/Microsoft.Authorization/policyDefinitions/aec63c84-f9ea-46c7-9e66-ba567bae0f09,/providers/Microsoft.Authorization/policyDefinitions/c9c29499-c1d1-4195-99bd-2ec9e3a9dc89*].These policy definitions can be added manually to the Policy Initiative [*C:\repos\DefenceIncubator\platform\incubation\managementgroups\policies\initiatives\NetworkServicesBaseline.json*] if required

Name | Description | Link
:--- | :---------- | :---
Enable logging by category group for microsoft.networkcloud/storageappliances to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.networkcloud/storageappliances. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f005380e0-1f5b-467a-8ae8-8519938627f9)
Enable logging by category group for microsoft.network/p2svpngateways to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.network/p2svpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f00ec9865-beb6-4cfd-82ed-bd8f50756acd)
Enable logging by category group for Network security groups (microsoft.network/networksecuritygroups) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Network security groups (microsoft.network/networksecuritygroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0120ef84-66e7-4faf-aad8-14c36389697e)
Enable logging by category group for microsoft.networkcloud/storageappliances to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.networkcloud/storageappliances. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0b726841-c441-44ed-a2cc-d321e3be3ed7)
Enable logging by category group for microsoft.networkcloud/baremetalmachines to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.networkcloud/baremetalmachines. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0dac4c0b-0ca4-4c6e-9a09-61917873b3b0)
Enable logging by category group for microsoft.network/dnsresolverpolicies to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.network/dnsresolverpolicies. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f0fdc6116-c747-449c-b9cc-330fcd4c5c9c)
Enable logging by category group for Application gateways (microsoft.network/applicationgateways) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Application gateways (microsoft.network/applicationgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f11638078-a29c-4cf3-ad7f-775f78327425)
Enable logging by category group for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f14681907-c749-4d60-8eae-1038537fb8a3)
Enable logging by category group for microsoft.network/networksecurityperimeters to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.network/networksecurityperimeters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f20a921eb-1c4b-4bb7-a78f-6653ad293dba)
[Deprecated]: Service Bus should use a virtual network service endpoint | This policy audits any Service Bus not configured to use a virtual network service endpoint. The resource type Microsoft.ServiceBus/namespaces/virtualNetworkRules is deprecated in the latest API version. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f235359c5-7c52-4b82-9055-01c75cf9f60e)
Enable logging by category group for microsoft.network/networkmanagers/ipampools to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.network/networkmanagers/ipampools. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f28e2d787-b5f4-43cf-8cb7-11b54773d379)
[Deprecated]: SSH access from the Internet should be blocked | This policy is deprecated. This policy audits any network security rule that allows SSH access from Internet | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2c89a2e5-7285-40fe-afe0-ae8654b92fab)
Enable logging by category group for ExpressRoute circuits (microsoft.network/expressroutecircuits) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for ExpressRoute circuits (microsoft.network/expressroutecircuits). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2cb215be-a09b-4623-ac2f-dfc5012b1a5b)
Enable logging by category group for Public IP Prefixes (microsoft.network/publicipprefixes) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Public IP Prefixes (microsoft.network/publicipprefixes). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2cc39a57-5106-4d41-b872-55c2b9d7b729)
Enable logging by category group for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Traffic Manager profiles (microsoft.network/trafficmanagerprofiles). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f2db34cad-25ef-48e3-a787-c2cd36434cd7)
Enable logging by category group for Firewalls (microsoft.network/azurefirewalls) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Firewalls (microsoft.network/azurefirewalls). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f339855ce-39c1-4a70-adc9-103ea7aac99f)
Enable logging by category group for Public IP addresses (microsoft.network/publicipaddresses) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Public IP addresses (microsoft.network/publicipaddresses). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f39aa567d-69c2-4cc0-aaa9-76c6d4006b14)
Enable logging by category group for Load balancers (microsoft.network/loadbalancers) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Load balancers (microsoft.network/loadbalancers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f3ca36b5c-2f29-41a0-9b1d-80e2cdf2d947)
Enable logging by category group for Virtual networks (microsoft.network/virtualnetworks) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Virtual networks (microsoft.network/virtualnetworks). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f40ce1496-89c2-40cf-80e5-3c4687d2ee4b)
Enable logging by category group for microsoft.networkcloud/storageappliances to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.networkcloud/storageappliances. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f4f925033-4d52-4619-909c-9c47a687dc51)
Enable logging by category group for Firewalls (microsoft.network/azurefirewalls) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Firewalls (microsoft.network/azurefirewalls). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f50bdafe5-c7b6-4812-af5f-75dc00561aed)
Enable logging by category group for microsoft.networkfunction/azuretrafficcollectors to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.networkfunction/azuretrafficcollectors. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f50d96640-65c9-42de-b79a-95c1890c6ec8)
Enable logging by category group for microsoft.networkanalytics/dataproducts to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.networkanalytics/dataproducts. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f5360664a-5821-4f43-8988-3f0ed8f3f8a5)
Enable logging by category group for Network security groups (microsoft.network/networksecuritygroups) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Network security groups (microsoft.network/networksecuritygroups). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f601e350d-405c-41d0-a886-72c283f8fab2)
[Deprecated]: Firewall Policy Premium should enable all IDPS signature rules to monitor all inbound and outbound traffic flows | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall premium as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f610b6183-5f00-4d68-86d2-4ab4cb3a67a5)
[Deprecated]: Web Application Firewall (WAF) should enable all firewall rules for Application Gateway | This policy is deprecated because sometimes it is impractical to enable all WAF rules. Instead of continuing to use this policy, we recommend you instead assign this replacement policy with policy ID 564feb30-bf6a-4854-b4bb-0d2d2d1e6c66.  Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f632d3993-e2c0-44ea-a7db-2eca131f356d)
Enable logging by category group for microsoft.networkcloud/clusters to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.networkcloud/clusters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f63a8eb0d-f030-4bc6-a1e4-6998f23aa160)
[Deprecated]: Firewall Policy Premium should enable the Intrusion Detection and Prevention System (IDPS) | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall premium as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f6484db87-a62d-4327-9f07-80a2cbdf333a)
Enable logging by category group for microsoft.networkcloud/clusters to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.networkcloud/clusters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f64948b6b-409d-4af2-970f-3b80fea408c1)
Enable logging by category group for Bastions (microsoft.network/bastionhosts) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Bastions (microsoft.network/bastionhosts). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f6b2899d8-5fdf-4ade-ba59-f1f82664877b)
Enable logging by category group for Virtual network gateways (microsoft.network/virtualnetworkgateways) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Virtual network gateways (microsoft.network/virtualnetworkgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f6ccd32f6-0a9a-40cf-9c5b-6cfd6aba33e9)
[Deprecated]: Azure Firewall Premium should configure a valid intermediate certificate to enable TLS inspection | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall premium as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f711c24bb-7f18-4578-b192-81a6161e1f17)
Enable logging by category group for Network Managers (microsoft.network/networkmanagers) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Network Managers (microsoft.network/networkmanagers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f82333640-495e-4249-92bb-2a5e2d07b964)
Enable logging by category group for microsoft.network/networksecurityperimeters to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.network/networksecurityperimeters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f83089e56-9675-4bc8-ae7d-ca4547dc764b)
Enable logging by category group for Application gateways (microsoft.network/applicationgateways) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Application gateways (microsoft.network/applicationgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f887d1795-3d3d-4859-9ef4-9447392db2ea)
Enable logging by category group for Virtual networks (microsoft.network/virtualnetworks) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Virtual networks (microsoft.network/virtualnetworks). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f8d0e693f-1b54-41d1-880e-199c3caed23f)
Enable logging by category group for ExpressRoute circuits (microsoft.network/expressroutecircuits) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for ExpressRoute circuits (microsoft.network/expressroutecircuits). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f93319447-e347-406b-953f-618c3b599554)
Configure diagnostic settings for Azure Network Security Groups to Log Analytics workspace | Deploy diagnostic settings to Azure Network Security Groups to stream resource logs to a Log Analytics workspace. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2f98a2e215-5382-489e-bd29-32e7190a39ba)
Enable logging by category group for microsoft.network/networkmanagers/ipampools to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.network/networkmanagers/ipampools. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa08af17e-c2a3-478e-a819-94839ef02b32)
Enable logging by category group for Public IP Prefixes (microsoft.network/publicipprefixes) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Public IP Prefixes (microsoft.network/publicipprefixes). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa2361fd4-721d-4be2-9910-53be250b99ad)
Enable logging by category group for Firewall (microsoft.network/azurefirewalls) to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for Firewall (microsoft.network/azurefirewalls). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa4490248-cb97-4504-b7fb-f906afdb7437)
[Deprecated]: Azure firewall policy should enable TLS inspection within application rules | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa58ac66d-92cb-409c-94b8-8e48d7a96596)
Enable logging by category group for microsoft.networkfunction/azuretrafficcollectors to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.networkfunction/azuretrafficcollectors. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa6dd4d00-283d-4765-b3d1-44ace2ccacda)
Enable logging by category group for microsoft.networkcloud/baremetalmachines to Log Analytics | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Log Analytics workspace for microsoft.networkcloud/baremetalmachines. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fa9725bd4-a2ad-479f-a29b-5e163cada399)
Enable logging by category group for microsoft.networkanalytics/dataproducts to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.networkanalytics/dataproducts. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2faa78af66-1659-40aa-90b0-b35b616adbdc)
Packet Core Control Plane diagnostic access should only use Microsoft EntraID authentication type | Authenticaton type must be Microsoft EntraID for packet core diagnostic access over local APIs | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2faec63c84-f9ea-46c7-9e66-ba567bae0f09)
Enable logging by category group for Virtual network gateways (microsoft.network/virtualnetworkgateways) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Virtual network gateways (microsoft.network/virtualnetworkgateways). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb4a9c220-1d62-4163-a17b-30db7d5b7278)
Enable logging by category group for microsoft.network/dnsresolverpolicies to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.network/dnsresolverpolicies. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb79bf56e-c296-4829-afea-6ac9263e7687)
Enable logging by category group for microsoft.network/p2svpngateways to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.network/p2svpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb9b976cc-59ef-468a-807e-19afa2ebfd52)
Enable logging by category group for microsoft.networkcloud/clusters to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.networkcloud/clusters. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fb9d3f759-4cda-43cf-8f64-5b01aeb1c21a)
Enable logging by category group for Load balancers (microsoft.network/loadbalancers) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Load balancers (microsoft.network/loadbalancers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fba0ba89c-1137-407f-ae7a-19152ea7ae82)
[Deprecated]: Web Application Firewall should be enabled for Azure Front Door Service or Application Gateway | Requires Web Application Firewall on any Azure Front Door Service or Application Gateway. A Web Application Firewall provides greater security for your other Azure resources. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fbe7ed5c8-2660-4136-8216-e6f3412ba909)
Enable logging by category group for Bastions (microsoft.network/bastionhosts) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Bastions (microsoft.network/bastionhosts). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fbe9259e2-a221-4411-84fd-dd22c6691653)
Enable logging by category group for Network Managers (microsoft.network/networkmanagers) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Network Managers (microsoft.network/networkmanagers). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc29fe1b2-c0b0-4d92-a988-84b484801707)
Deploy Diagnostic Settings for Network Security Groups | This policy automatically deploys diagnostic settings to network security groups. A storage account with name '{storagePrefixParameter}{NSGLocation}' will be automatically created. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fc9c29499-c1d1-4195-99bd-2ec9e3a9dc89)
Enable logging by category group for microsoft.network/vpngateways to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for microsoft.network/vpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fca09affa-60d6-4cef-9037-b7372e1ac44f)
Enable logging by category group for Front Door and CDN profiles (microsoft.network/frontdoors) to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for Front Door and CDN profiles (microsoft.network/frontdoors). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fd147ba9f-3e17-40b1-9c23-3bca478ba804)
Enable logging by category group for microsoft.network/vpngateways to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.network/vpngateways. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe0f5ec01-8979-49bf-9fd7-2a4eff9fa8e0)
[Deprecated]: RDP access from the Internet should be blocked | This policy is deprecated. This policy audits any network security rule that allows RDP access from Internet | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe372f825-a257-4fb8-9175-797a8a8627d6)
Enable logging by category group for microsoft.networkcloud/baremetalmachines to Storage | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to a Storage Account for microsoft.networkcloud/baremetalmachines. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2fe6421995-539a-4ce3-854b-1c88534396cf)
Enable logging by category group for Front Door and CDN profiles (microsoft.network/frontdoors) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Front Door and CDN profiles (microsoft.network/frontdoors). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2feb5a4c26-04cb-4ab1-81cb-726dc58df772)
[Deprecated]: Subscription should configure the Azure Firewall Premium to provide additional layer of protection | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall premium as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ff2c2d0a6-e183-4fc8-bd8f-363c65d3bbbf)
[Deprecated]: Bypass list of Intrusion Detection and Prevention System (IDPS) should be empty in Firewall Policy Premium | This policy is deprecated because Microsoft 365 App Compliance Program no longer requires Azure Firewall premium as the only network security control solution. Learn more details about the latest M365 APP Compliance requirements about network security controls at aka.ms/acat-cert2-seg-ops-nsc. Learn more about policy definition deprecation at aka.ms/policydefdeprecation. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ff516dc7a-4543-4d40-aad6-98f76a706b50)
[Deprecated]: Web Application Firewall should be a set mode for Application Gateway and Azure Front Door Service | Mandates detect or prevent mode to be active on all Web Application Firewall policies for Azure Front Door and Application Gateway. Web Application Firewall policies can have a consistent mode configuration across a resource group. | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ff6b68e5a-7207-4638-a1fb-47d90404209e)
Enable logging by category group for Public IP addresses (microsoft.network/publicipaddresses) to Event Hub | Resource logs should be enabled to track activities and events that take place on your resources and give you visibility and insights into any changes that occur. This policy deploys a diagnostic setting using a category group to route logs to an Event Hub for Public IP addresses (microsoft.network/publicipaddresses). | [Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/%2fproviders%2fMicrosoft.Authorization%2fpolicyDefinitions%2ffc602c00-2ce3-4556-b615-fa4159517103)

## Resource Types

### Allowed

- Microsoft.Network/dnsResolvers

- Microsoft.Network/dnsResolvers/inboundEndpoints

- Microsoft.Network/dnsResolvers/outboundEndpoints

- Microsoft.Network/dnsForwardingRulesets

- Microsoft.Network/dnsForwardingRulesets/forwardingRules

- Microsoft.Network/dnsForwardingRulesets/virtualNetworkLinks

- Microsoft.Network/virtualNetworks/listDnsResolvers

- Microsoft.Network/virtualNetworks/listDnsForwardingRulesets

- Microsoft.Network/locations/dnsResolverOperationResults

- Microsoft.Network/locations/dnsResolverOperationStatuses

- Microsoft.Network/locations/dnsResolverPolicyOperationResults

- Microsoft.Network/locations/dnsResolverPolicyOperationStatuses

- Microsoft.Network/expressRouteProviderPorts

- Microsoft.Network/locations/hybridEdgeZone

- Microsoft.Network/firewallPolicies

- Microsoft.Network/ipGroups

- Microsoft.Network/azureWebCategories

- Microsoft.Network/locations/nfvOperations

- Microsoft.Network/locations/nfvOperationResults

- Microsoft.Network/virtualRouters

- Microsoft.Network/networkVirtualAppliances

- Microsoft.Network/networkVirtualApplianceSkus

- Microsoft.Network/networkManagers

- Microsoft.Network/networkManagerConnections

- Microsoft.Network/locations/perimeterAssociableResourceTypes

- Microsoft.Network/locations/queryNetworkSecurityPerimeter

- Microsoft.Network/virtualNetworks/listNetworkManagerEffectiveConnectivityConfigurations

- Microsoft.Network/virtualNetworks/listNetworkManagerEffectiveSecurityAdminRules

- Microsoft.Network/networkGroupMemberships

- Microsoft.Network/locations/commitInternalAzureNetworkManagerConfiguration

- Microsoft.Network/locations/internalAzureVirtualNetworkManagerOperation

- Microsoft.Network/networkManagers/verifierWorkspaces

- Microsoft.Network/locations/verifierWorkspaceOperationResults

- Microsoft.Network/copilot

- Microsoft.Network/trafficmanagerprofiles

- Microsoft.Network/trafficmanagerprofiles/heatMaps

- Microsoft.Network/trafficmanagerprofiles/azureendpoints

- Microsoft.Network/trafficmanagerprofiles/externalendpoints

- Microsoft.Network/trafficmanagerprofiles/nestedendpoints

- Microsoft.Network/checkTrafficManagerNameAvailability

- Microsoft.Network/checkTrafficManagerNameAvailabilityV2

- Microsoft.Network/trafficManagerUserMetricsKeys

- Microsoft.Network/trafficManagerGeographicHierarchies

- Microsoft.Network/virtualNetworkGateways

- Microsoft.Network/localNetworkGateways

- Microsoft.Network/connections

- Microsoft.Network/applicationGateways

- Microsoft.Network/expressRouteCircuits

- Microsoft.Network/expressRouteServiceProviders

- Microsoft.Network/applicationGatewayAvailableWafRuleSets

- Microsoft.Network/applicationGatewayAvailableSslOptions

- Microsoft.Network/applicationGatewayAvailableServerVariables

- Microsoft.Network/applicationGatewayAvailableRequestHeaders

- Microsoft.Network/applicationGatewayAvailableResponseHeaders

- Microsoft.Network/routeFilters

- Microsoft.Network/bgpServiceCommunities

- Microsoft.Network/vpnSites

- Microsoft.Network/vpnServerConfigurations

- Microsoft.Network/virtualHubs

- Microsoft.Network/vpnGateways

- Microsoft.Network/p2sVpnGateways

- Microsoft.Network/expressRouteGateways

- Microsoft.Network/expressRoutePortsLocations

- Microsoft.Network/expressRoutePorts

- Microsoft.Network/securityPartnerProviders

- Microsoft.Network/azureFirewalls

- Microsoft.Network/azureFirewallFqdnTags

- Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies

- Microsoft.Network/locations/ApplicationGatewayWafDynamicManifests

- Microsoft.Network/virtualWans

- Microsoft.Network/bastionHosts

- Microsoft.Network/queryExpressRoutePortsBandwidth

- Microsoft.Network/dnszones

- Microsoft.Network/dnsOperationResults

- Microsoft.Network/dnsOperationStatuses

- Microsoft.Network/getDnsResourceReference

- Microsoft.Network/internalNotify

- Microsoft.Network/dnszones/A

- Microsoft.Network/dnszones/AAAA

- Microsoft.Network/dnszones/CNAME

- Microsoft.Network/dnszones/PTR

- Microsoft.Network/dnszones/MX

- Microsoft.Network/dnszones/TXT

- Microsoft.Network/dnszones/SRV

- Microsoft.Network/dnszones/SOA

- Microsoft.Network/dnszones/NS

- Microsoft.Network/dnszones/CAA

- Microsoft.Network/dnszones/DS

- Microsoft.Network/dnszones/TLSA

- Microsoft.Network/dnszones/NAPTR

- Microsoft.Network/dnszones/recordsets

- Microsoft.Network/dnszones/all

- Microsoft.Network/dnszones/dnssecConfigs

- Microsoft.Network/privateDnsZones

- Microsoft.Network/privateDnsZones/virtualNetworkLinks

- Microsoft.Network/privateDnsOperationResults

- Microsoft.Network/privateDnsOperationStatuses

- Microsoft.Network/privateDnsZonesInternal

- Microsoft.Network/privateDnsZones/A

- Microsoft.Network/privateDnsZones/AAAA

- Microsoft.Network/privateDnsZones/CNAME

- Microsoft.Network/privateDnsZones/PTR

- Microsoft.Network/privateDnsZones/MX

- Microsoft.Network/privateDnsZones/TXT

- Microsoft.Network/privateDnsZones/SRV

- Microsoft.Network/privateDnsZones/SOA

- Microsoft.Network/privateDnsZones/all

- Microsoft.Network/virtualNetworks/privateDnsZoneLinks

- Microsoft.Network/frontdoorOperationResults

- Microsoft.Network/checkFrontdoorNameAvailability

- Microsoft.Network/frontdoors

- Microsoft.Network/frontdoors/frontendEndpoints

- Microsoft.Network/frontdoors/frontendEndpoints/customHttpsConfiguration

- Microsoft.Network/frontdoorWebApplicationFirewallPolicies

- Microsoft.Network/frontdoorWebApplicationFirewallManagedRuleSets

- Microsoft.Network/networkExperimentProfiles

- Microsoft.Network/virtualNetworks

- Microsoft.Network/virtualNetworks/taggedTrafficConsumers

- Microsoft.Network/natGateways

- Microsoft.Network/publicIPAddresses

- Microsoft.Network/internalPublicIpAddresses

- Microsoft.Network/customIpPrefixes

- Microsoft.Network/networkInterfaces

- Microsoft.Network/dscpConfigurations

- Microsoft.Network/privateEndpoints

- Microsoft.Network/privateEndpoints/privateLinkServiceProxies

- Microsoft.Network/privateEndpointRedirectMaps

- Microsoft.Network/loadBalancers

- Microsoft.Network/networkSecurityGroups

- Microsoft.Network/applicationSecurityGroups

- Microsoft.Network/serviceEndpointPolicies

- Microsoft.Network/networkIntentPolicies

- Microsoft.Network/routeTables

- Microsoft.Network/publicIPPrefixes

- Microsoft.Network/networkWatchers

- Microsoft.Network/networkWatchers/connectionMonitors

- Microsoft.Network/networkWatchers/flowLogs

- Microsoft.Network/networkWatchers/pingMeshes

- Microsoft.Network/locations

- Microsoft.Network/locations/operations

- Microsoft.Network/locations/operationResults

- Microsoft.Network/locations/CheckDnsNameAvailability

- Microsoft.Network/locations/setLoadBalancerFrontendPublicIpAddresses

- Microsoft.Network/cloudServiceSlots

- Microsoft.Network/locations/usages

- Microsoft.Network/locations/virtualNetworkAvailableEndpointServices

- Microsoft.Network/locations/availableDelegations

- Microsoft.Network/locations/serviceTags

- Microsoft.Network/locations/availablePrivateEndpointTypes

- Microsoft.Network/locations/availableServiceAliases

- Microsoft.Network/locations/checkPrivateLinkServiceVisibility

- Microsoft.Network/locations/autoApprovedPrivateLinkServices

- Microsoft.Network/locations/batchValidatePrivateEndpointsForResourceMove

- Microsoft.Network/locations/batchNotifyPrivateEndpointsForResourceMove

- Microsoft.Network/locations/supportedVirtualMachineSizes

- Microsoft.Network/locations/setAzureNetworkManagerConfiguration

- Microsoft.Network/locations/publishResources

- Microsoft.Network/locations/getAzureNetworkManagerConfiguration

- Microsoft.Network/locations/checkAcceleratedNetworkingSupport

- Microsoft.Network/locations/validateResourceOwnership

- Microsoft.Network/locations/setResourceOwnership

- Microsoft.Network/locations/effectiveResourceOwnership

- Microsoft.Network/operations

- Microsoft.Network/virtualNetworkTaps

- Microsoft.Network/privateLinkServices

- Microsoft.Network/locations/privateLinkServices

- Microsoft.Network/ddosProtectionPlans

- Microsoft.Network/networkProfiles

- Microsoft.Network/locations/bareMetalTenants

- Microsoft.Network/ipAllocations

- Microsoft.Network/locations/serviceTagDetails

- Microsoft.Network/locations/dataTasks

- Microsoft.Network/locations/startPacketTagging

- Microsoft.Network/locations/deletePacketTagging

- Microsoft.Network/locations/getPacketTagging

- Microsoft.Network/locations/rnmEffectiveRouteTable

- Microsoft.Network/locations/rnmEffectiveNetworkSecurityGroups
