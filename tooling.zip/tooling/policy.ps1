<#
.DESCRIPTION
    This script is used to generate policy initiatives for services in Azure. The script will search for policy definitions that match the service name, 
    resource providers, and other keywords. The script will then generate a report of the policy definitions that match the search terms. The script 
    will then generate a policy initiative file that includes the policy definitions that match the search terms. The script will also update the 
    Allowed Services Policy Initiative with the resource types that are allowed for the target service.

#>
Function ServicePolicyInitiative {

    [CmdletBinding()]
    param (
        # The Name of the initiative being created eg. "KeyvaultBaseline"
        [Parameter(Mandatory=$true)]
        [string]
        $initiativeName,

        # The Name of the service being targeted eg. "Key Vault"
        [Parameter(Mandatory=$true)]
        [string]
        $targetServiceName,

        # The Resource Providers that the service is associated with. Multiple Resource providers can be listed. eg. @("Microsoft.KeyVault") or 
        [Parameter(Mandatory=$true)]
        [array]
        $targetResourceProviders,

        #Other names that service maybe known by, additional services to include in this initiative. These keywords will be used to search existing policy definitions to find applicable policies.
        [Parameter()]
        [array]
        $otherKeywords,

        # Only Azure Policy Definitions that match these categories will be considered for inclusion in the policy initiative
        [Parameter()]
        [array]
        $initiativeCategoriesOfInterest = @(),

        # Policy Definitions that match these keywords will be put in the "Recommended" policy list
        [Parameter()]
        [array]
        $initiativeKeywordsToIncludeInRecommendations = @(),

        # Policy Definitions that match these keywords will be put in the "Excluded" policy list
        [Parameter()]
        [array]
        $initiativeKeywordsToExcludeFromRecommendations = @(),

        # Policy Definitions that match these Policy Definition Ids will be put in the "Excluded" policy list eg @("/providers/Microsoft.Authorization/policyDefinitions/c9c29499-c1d1-4195-99bd-2ec9e3a9dc89")
        [Parameter()]
        [array]
        $initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(),

        # The name of the file that contains the Allowed Services Policy Initiative. This will be updated with allowed resources for the target service.
        [Parameter()]
        [string]
        $AllowedServicesPolicyInitiativeFileName = "AllowedServicesBaseline.json",

        # The list of resource types that are not allowed for the target service. eg. @("Microsoft.KeyVault/managedHSMs") These items will be added to the "Not Allowed Resource Types" policy definition in the Allowed Services Policy Initiative.
        $NotAllowedResourceTypes = @(),

        # The name of the file that contains the existing policy initiative. If this file exists, the script will add recommendations to this file. If the file does not exist, a new policy initiative will be created.
        [Parameter()]
        [string]
        $policyInitiativeFileName,

        # If this is set to true, the script will add recommendations to the existing policy initiative. If this is set to false, the script will only list policy Recommendation on the report, which can then be actioned manually if desired.
        [Parameter()]
        [boolean]
        $addRecommendationsToExistingPolicy = $false,

        # The list of all policy definitions in the tenant. Provide the output of the Get-AzPolicyDefinition cmdlet.
        [Parameter()]
        [Array]
        $allPolicies,

        # The list of all providers in the tenant. Provide the output of the Get-AzResourceProvider cmdlet.
        [Parameter()]
        [Array]
        $allProviders,

        # The list of categories of interest for the baseline policy initiative. These categories will be used to filter policy definitions for the baseline policy initiative.
        [Parameter()]
        [Array]
        $baselineCategoriesOfInterest,
        
        # The list of keywords to include in the recommendations for the baseline policy initiative. These keywords will be used to search for policy definitions that match the baseline policy initiative.
        [Parameter()]
        [Array]
        $baselineKeywordsToIncludeInRecommendations,
        
        # The list of keywords to exclude from the recommendations for the baseline policy initiative. These keywords will be used to filter out policy definitions that match the baseline policy initiative.
        [Parameter()]
        [Array]
        $baselineKeywordsToExcludeFromRecommendations,

        # The list of policy groups for the baseline policy initiative. These policy groups will be used to group policy definitions in the policy initiative. eg. @{"[Incubation Governance] Restrict Network Access" = @("public", "private endpoint","private link", "firewall", "deploy into a virtual network")}
        $baselinePolicyGroups

    )

    $existingPolicyInitiativePath = Resolve-Path (Join-Path $PSScriptRoot "..\initiatives")

    $categoriesOfInterest = $initiativeCategoriesOfInterest + $baselineCategoriesOfInterest
    $keywordsToIncludeInRecommendations = $initiativeKeywordsToIncludeInRecommendations + $baselineKeywordsToIncludeInRecommendations
    $keywordsToExcludeFromRecommendations = $initiativeKeywordsToExcludeFromRecommendations + $baselineKeywordsToExcludeFromRecommendations

    #Policy Grouping  - (Aligned to Organisation Security Principles)
    $policyGroups = $baselinePolicyGroups

    $policyReportFileName = $policyInitiativeFileName -replace (".json", "")

    "Working on service [$targetServiceName]..."

    "Looking for existing Policy Initiative File"
    $targetPolicyFile = Join-Path $existingPolicyInitiativePath $policyInitiativeFileName
    if (Test-Path $targetPolicyFile) {
        "Existing Policy Initiative File Found"
        $existingPolicy = Get-Content $targetPolicyFile |ConvertFrom-Json -depth 20
    } else {
        $existingPolicy = @{}
        $generateNewPolicy = $true
        $addRecommendationsToExistingPolicy = $true
        "Existing Policy Initiative File Not Found"
    }

    #Combine Search Terms
    [array]$searchTerms = [array]$targetServiceName + $otherKeywords + $targetResourceProviders

    $hasTheServiceBeenIRAPAssessed = "unknown"

    ###############TODO - Get Existing Built in initiatives - there may be preexisting stuff to utilise....eg. ISM Initiative

    #region ResourceProviderDiscovery
    $allResourceTypes = Foreach ($rp in $allProviders) {
        $rp.ResourceTypes | ForEach-Object {$rp.ProviderNamespace + "/" + $_.ResourceTypeName}
    }

    "Finding matching resource providers for target service..."
    [array]$matchingResourceProviders =  $null
    Foreach ($term in $searchTerms) {
        $matchingResourceProviders += $allProviders.ProviderNamespace | Where-Object {$_ -match ".*$term.*"}
    }
    $matchingResourceProviders = $matchingResourceProviders | Select-Object -Unique

    "Finding resource types for target service..."
    [array]$matchingResourceTypes =  $null
    Foreach ($rp in $matchingResourceProviders) {
        $matchingResourceTypes += $allResourceTypes |Where-Object { $_ -match ".*$rp.*" }
    }
    $matchingResourceTypes = $matchingResourceTypes 

    #endregion

    "Filtering policy definitions to categories of interest..."
    [array]$categoryMatchingPolicies =  $null
    Foreach ($term in $searchTerms) {
        $categoryMatchingPolicies += $allPolicies | Where-Object {$_.Properties.Metadata.category -match ".*$term.*" }
    }
    Foreach ($category in $initiativeCategoriesOfInterest) {
        $categoryMatchingPolicies += $allPolicies | Where-Object {$_.Properties.Metadata.category -match ".*$category.*" }
    }
    $categoryMatchingPolicies = $categoryMatchingPolicies | Sort-object -Property PolicyDefinitionId -Unique


    "Filtering policy definitions matching other Keywords..."
    [array]$otherMatchingPolicies =  $null
    Foreach ($term in $searchTerms) {
        $otherMatchingPolicies += $allPolicies | Where-Object {$_.Properties.DisplayName -match ".*$term.*" `
                                                            -or $_.Properties.Description -match ".*$term.*" `
                                                            -or $($_.Properties.PolicyRule.if |ConvertTo-Json -depth 20) -match ".*$term.*" #this one might not be useful
                                                        }
    }
    $otherMatchingPolicies = $otherMatchingPolicies | Sort-object -Property PolicyDefinitionId -Unique
    $otherMatchingPolicies = Compare-Object -ReferenceObject $categoryMatchingPolicies -DifferenceObject $otherMatchingPolicies -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "=>" }

    $otherMatchingPoliciesInCategoriesOfInterest = $otherMatchingPolicies |Where-Object { $_.Properties.Metadata.Category -in $categoriesOfInterest }

    # $otherMatchingPoliciesInCategoriesOfInterest.Properties.DisplayName

    $policiesToReview = $categoryMatchingPolicies + $otherMatchingPoliciesInCategoriesOfInterest
    
    #Add Category Grouping (Aligned to Organisation Security Principles)
    "Add Policy Group Information to all policy definitions under review..."
    Foreach ($group in $policyGroups.keys) {
        foreach ($term in $policyGroups[$group]) {
            $policiesToReview | Where-Object {$_.Properties.DisplayName -match ".*$term.*" `
                    -or $_.Properties.Description -match ".*$term.*"
                } | ForEach-Object {$_ | Add-Member -MemberType NoteProperty -Name PolicyGroups -Value $(@([array]$group + [array]$_.policyGroups)| Sort-Object -Unique) -Force}
        }
    }

    "Determine policy definitions that are already included in the existing policy initiative..."
    [array]$existingIncludedPolicies = @()
    Foreach ($definition in $existingPolicy.policyDefinitions.policyDefinitionId) {
        $existingIncludedPolicies += $allPolicies | Where-Object {$_.policyDefinitionId -eq $definition}
    }
    $existingIncludedPolicies = @($existingIncludedPolicies | Sort-object -Property PolicyDefinitionId -Unique)

    "Removing policy definitions from policies under review based on exclusion keywords..."
    [array]$policiesToExclude =  @()
    Foreach ($keyword in $keywordsToExcludeFromRecommendations) {
        $policiesToExclude += $policiesToReview | Where-Object {$_.properties.displayname -match ".*$keyword.*"}
    }
    Foreach ($id in $initiativePolicyDefinitionIdsToExcludeFromRecommendations) {
        $policiesToExclude += $policiesToReview | Where-Object {$_.PolicyDefinitionId -eq $id}
    }
    $policiesToExclude = @($policiesToExclude | Sort-object -Property PolicyDefinitionId -Unique)

    #Recommended POlicies
    "Adding policy definitions to recommendations based on inclusion keywords..."
    [array]$policiesToRecommend =  @()
    Foreach ($keyword in $keywordsToIncludeInRecommendations) {
        $policiesToRecommend += $policiesToReview | Where-Object {$_.properties.displayname -match ".*$keyword.*"}
    }
    $policiesToRecommend = @($policiesToRecommend | Sort-object -Property PolicyDefinitionId -Unique)
    $policiesToRecommend = Compare-Object -ReferenceObject $policiesToRecommend -DifferenceObject $policiesToExclude -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "<=" }
    $policiesToRecommend = Compare-Object -ReferenceObject $policiesToRecommend -DifferenceObject $existingIncludedPolicies -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "<=" }
    $policiesToRecommend = @($policiesToRecommend|Select-Object)

    #Other Policies That do not match the recommendation keywords but are still related to the service
    "Collating remaining policy definitions..."
    $policiesToConsider = Compare-Object -ReferenceObject $policiesToReview  -DifferenceObject $policiesToExclude -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "<=" }
    $policiesToConsider = Compare-Object -ReferenceObject $policiesToConsider  -DifferenceObject $policiesToRecommend -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "<=" }
    $policiesToConsider = Compare-Object -ReferenceObject $policiesToConsider  -DifferenceObject $existingIncludedPolicies -Property PolicyDefinitionId -PassThru |Where-Object { $_.SideIndicator -eq "<=" }
    $policiesToConsider = @($policiesToConsider|Select-Object)

    #region Generate a report
    "Generating Policy Initiative Report..."
    Install-Module -Name 'PSDocs' -Repository PSGallery;

    $inputObject = @{
        targetService = $initiativeName
        hasTheServiceBeenIRAPAssessed = $hasTheServiceBeenIRAPAssessed
        matchingResourceTypes = $matchingResourceTypes
        notAllowedResourceTypes = $NotAllowedResourceTypes
        existingPolicy = $targetPolicyFile
        policiesIncluded = ($addRecommendationsToExistingPolicy) ? $($existingIncludedPolicies + $policiesToRecommend) : $existingIncludedPolicies 
        policiesToRecommend = ($addRecommendationsToExistingPolicy) ? @() : $policiesToRecommend
        policiesToConsider = $policiesToConsider
        policiesToExclude = $policiesToExclude
        policyGroups = $policyGroups.keys
        categoriesOfInterest = $categoriesOfInterest -join ","
        keywordsToIncludeInRecommendations = $keywordsToIncludeInRecommendations -join ","
        keywordsToExcludeFromRecommendations = $keywordsToExcludeFromRecommendations -join ","
        policiesToExcludeFromRecommendations = $initiativePolicyDefinitionIdsToExcludeFromRecommendations -join ","
        # keywordsToExcludeFromRecommendations = @($keywordsToExcludeFromRecommendations + $initiativePolicyDefinitionIdsToExcludeFromRecommendations) -join ","
        searchTerms = $searchTerms -join ","

    }

    $templateFile = Join-Path -Path $PSScriptRoot -ChildPath "policyReport.doc.ps1"
    Invoke-PSDocument -Path $templateFile -OutputPath $existingPolicyInitiativePath -InputObject $inputObject -InstanceName $policyReportFileName
    #endregion

    #region Generate POlicy Initiative
    "Generate/Update policy initiative JSON..."
    if ($generateNewPolicy -ne $true) {
        $policyInitiative = $existingPolicy
        $updatePolicyGroupNames = @($policyInitiative.policyDefinitionGroups + $policyGroups.Keys |Sort-Object -Unique)
        $policyInitiative.policyDefinitionGroups = $updatePolicyGroupNames
    } else {
        "generating new Policy Initiative..."
        #create a new POlicy Initiative
        $policyInitiative = [ordered]@{
            type = "Microsoft.Authorization/policySetDefinitions"
            name = $initiativeName
            description = "description"
            displayName = "[Incubation Governance] $targetServiceName"
            metadata = @{
                category = "Incubation Governance"
                targetService = $targetServiceName
            }
            parameters = @{}
            policyDefinitions = @()
            policyDefinitionGroups = $policyGroups.Keys
        }
    }


    #Add policies to the initiative
    if ($generateNewPolicy -eq $true -or $addRecommendationsToExistingPolicy -eq $true){
        foreach ($policy in $policiesToRecommend) {
            $parameters = @{}
            $keys = ($policy.properties.Parameters|Get-Member -Type NoteProperty).name
            ForEach ($param in $keys) {
                $AllowedValues = ($policy.properties.parameters.$param.allowedValues.Count -gt 0) ? "Allowed: $($policy.properties.parameters.$param.allowedValues -join "/")" : "(Allowed: NoValuesDetected)"
                $defaultValue = ($policy.properties.parameters.$param.defaultValue) ? "Default: $($policy.properties.parameters.$param.defaultValue)" : "Default: NoDefault"
                $description = ($policy.properties.parameters.$param.metadata.description) ? "Description: $($policy.properties.parameters.$param.metadata.description)" : "Description: No Description refer to documentation"

                $parameters.$param = @{
                    value = "UPDATE_BEFORE_COMMIT $DefaultValue,$AllowedValues,$description"
                }
            }

            $policyInitiative.policyDefinitions += [array]@{
                policyDefinitionId = $policy.PolicyDefinitionId
                policyDefinitionReferenceId = $policy.Properties.DisplayName
                parameters = $parameters
                groupNames = [array]$policy.PolicyGroups
            } 
        }

        $policyInitiative | ConvertTo-Json -Depth 20 | Out-File -FilePath $targetPolicyFile -Force

        "Recommended Policy Definitions have been added to the policy initiative file"
        "View the git diff to review changes in the policy initiative file"
        "Add Parameters to the policy definitions as required"
        "Customise Policy Groups as required"
    } else {
        "Open the policy Report"
    }
    #endregion


    #region AllowedServicesPolicy
    "Updating Allowed Services Policy Initiative..."
    $AllowedServicesPolicyInitiativePath = Join-Path $existingPolicyInitiativePath $AllowedServicesPolicyInitiativeFileName
    $AllowedServicesPolicyInitiative = Get-Content $AllowedServicesPolicyInitiativePath |ConvertFrom-Json -depth 20

    $AllowedServicesPolicyInitiative.policydefinitions | Where-Object { $_.policyDefinitionReferenceId -eq "Allowed Resource Types"} | ForEach-Object {
        $_.parameters.listOfResourceTypesAllowed.value += $(@($matchingResourceTypes) |Sort-Object -Unique)
        $_.parameters.listOfResourceTypesAllowed.value = $($_.parameters.listOfResourceTypesAllowed.value |Sort-Object -Unique)
    }

    if ($NotAllowedResourceTypes.Count -gt 0) {
        if ($AllowedServicesPolicyInitiative.policydefinitions.policyDefinitionReferenceId -contains "Not Allowed Resource Types - $targetServiceName"){
            $AllowedServicesPolicyInitiative.policydefinitions | Where-Object { $_.policyDefinitionReferenceId -eq "Not Allowed Resource Types - $targetServiceName"} | ForEach-Object {
                [array]$_.parameters.listOfResourceTypesNotAllowed.value += $(@($NotAllowedResourceTypes) |Sort-Object -Unique)
                [array]$_.parameters.listOfResourceTypesNotAllowed.value = $($_.parameters.listOfResourceTypesNotAllowed.value |Sort-Object -Unique)
            }
        } else {
            #Add new policy
            [array]$AllowedServicesPolicyInitiative.policyDefinitions += [array]@{
                policyDefinitionId = "/providers/Microsoft.Authorization/policyDefinitions/6c112d4e-5bc7-47ae-a041-ea2d9dccd749"
                policyDefinitionReferenceId = "Not Allowed Resource Types - $targetServiceName"
                parameters = @{
                    listOfResourceTypesNotAllowed = @{
                        value = $(@($NotAllowedResourceTypes |Sort-Object -Unique))
                    }
                }
            }
        }  
    } else {
        #Remove policy if it exists
        $AllowedServicesPolicyInitiative.policydefinitions = $AllowedServicesPolicyInitiative.policydefinitions | Where-Object { $_.policyDefinitionReferenceId -ne "Not Allowed Resource Types - $targetServiceName"}
    }

    $AllowedServicesPolicyInitiative | ConvertTo-Json -depth 20 |Set-Content $AllowedServicesPolicyInitiativePath 

    #endregion

    "NOTE: If this is a new service, you may also have to add a policy assignment to the terraform file."
}

######################################################
#region Add Baseline resources to allowed services list

$baselineResourceProvidersToAllow = @(
    "Microsoft.Advisor",
    "Microsoft.AlertsManagement",
    "Microsoft.Authorization",
    "Microsoft.Billing",
    "Microsoft.Consumption",
    "Microsoft.CostManagement",
    "Microsoft.Diagnostics",
    "Microsoft.Features",
    "Microsoft.Insights",
    "Microsoft.Kusto",
    "Microsoft.Maintenance",
    "Microsoft.ManagedIdentity",
    "Microsoft.Management",
    "Microsoft.MarketplaceOrdering",
    "Microsoft.OperationalInsights",
    "Microsoft.PolicyInsights",
    "Microsoft.Portal",
    "Microsoft.ResourceGraph",
    "Microsoft.ResourceNotifications",
    "Microsoft.Resources",
    "Microsoft.Security",
    "Microsoft.SerialConsole",
    "Microsoft.Support"
)

# if a service does not require a policy initiative, enable it in this list
$additionalResourceProvidersToAllow = @(
    "Microsoft.DevCenter"
)

[array]$combinedResourceProvidersToAllow = $baselineResourceProvidersToAllow + $additionalResourceProvidersToAllow

$allResourceProviders = Get-AZResourceProvider
$allowedBaselineResourceTypes = foreach ($rpname in $combinedResourceProvidersToAllow) {
    $rp = $allResourceProviders | Where-Object { $_.ProviderNamespace -eq $rpname }
    foreach ($rt in $rp.ResourceTypes) {
        @($rp.ProviderNameSpace,$rt.ResourceTypeName) -join "/"
    }
}

"Updating Allowed Services Policy Initiative with baseline services..."
$AllowedServicesPolicyInitiativePath = Join-Path $PSScriptRoot "../initiatives/AllowedServicesBaseline.json"
$AllowedServicesPolicyInitiative = Get-Content $AllowedServicesPolicyInitiativePath |ConvertFrom-Json -depth 20

$AllowedServicesPolicyInitiative.policydefinitions | Where-Object { $_.policyDefinitionReferenceId -eq "Allowed Resource Types"} | ForEach-Object {
    $_.parameters.listOfResourceTypesAllowed.value += $(@($allowedBaselineResourceTypes) |Sort-Object -Unique)
    $_.parameters.listOfResourceTypesAllowed.value = $($_.parameters.listOfResourceTypesAllowed.value |Sort-Object -Unique)
}

$AllowedServicesPolicyInitiative | ConvertTo-Json -depth 20 |Set-Content $AllowedServicesPolicyInitiativePath

#endregion

######################################################

"Getting Policy Definitions from Azure..."

# THe object structure returned by Get-AzPolicyDefinition is different between versions 6 and 7 of the Az.Resources module. This block of code will determine the version of the module and get the policy definitions accordingly.
if ((get-module -Name az.resources).version.major -gt 6) {
    $allPolicies = $(Get-AzPolicyDefinition -BackwardCompatible)
} else {
    $allPolicies = $(Get-AzPolicyDefinition)
}

$baselineArguments = @{
    baselineCategoriesOfInterest = @("Security Center", "Monitoring", "Security Center - Granular Pricing", "General")
    baselineKeywordsToIncludeInRecommendations = @("public", "private endpoint","private link", "firewall", "diagnostic","defender","logs","logging","DNS Zone", "deploy into a virtual network")
    baselineKeywordsToExcludeFromRecommendations = @("Deprecated","to Event Hub","Enable logging.*to storage")
    baselinePolicyGroups = @{
        "[Incubation Governance] Restrict Network Access" = @("public", "private endpoint","private link", "firewall", "deploy into a virtual network")
        "[Incubation Governance] Monitoring" = @("diagnostic","logs","logging")
        "[Incubation Governance] Encryption" = @()
        "[Incubation Governance] Security Posture Management" = @("defender","Antimalware")
        "[Incubation Governance] Access Control" = @("Shared.Key")
        "[Incubation Governance] Patching and Updates" = @("update","updates","patch","patching")
    }
}


"Getting Provider information from Azure..."
$allProviders = $(Get-AzResourceProvider)

$Arguments = $baselineArguments + @{
    initiativeName = "AppServiceBaseline"
    policyInitiativeFileName = "AppServiceBaseline.json"
    targetServiceName = "AppService"
    targetResourceProviders = @("Microsoft.Web")
    otherKeywords = @("App Service","Web App","Web Site","WebApp", "Function App","App Service Environment")
    initiativeCategoriesOfInterest = @("App Service")
    initiativeKeywordsToIncludeInRecommendations = @()
    initiativeKeywordsToExcludeFromRecommendations = @()
    initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(
    )
    allPolicies = $allPolicies
    allProviders = $allProviders
	# addRecommendationsToExistingPolicy = $true
    NotAllowedResourceTypes = @()
}
ServicePolicyInitiative @Arguments

# $Arguments = $baselineArguments + @{
#     initiativeName = "StorageBaseline"
#     policyInitiativeFileName = "StorageBaseline.json"
#     targetServiceName = "Storage Accounts"
#     targetResourceProviders = @("Microsoft.Storage")
#     otherKeywords = @("storage account","storageAccount")
#     initiativeCategoriesOfInterest = @("storage")
#     initiativeKeywordsToIncludeInRecommendations = @()
#     initiativeKeywordsToExcludeFromRecommendations = @("Netapp","Storage.*Classic","SQL","Azure.File.Sync", "HPC.Caches","storagemover")
#     initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(
#         "/providers/Microsoft.Authorization/policyDefinitions/c9c29499-c1d1-4195-99bd-2ec9e3a9dc89",
#         "/providers/Microsoft.Authorization/policyDefinitions/0c4bd2e8-8872-4f37-a654-03f6f38ddc76",
#         "/providers/Microsoft.Authorization/policyDefinitions/f7f89b1eb-583c-429a-8828-af049802c1d9",
#         "/providers/Microsoft.Authorization/policyDefinitions/fa298e57-9444-42ba-bf04-86e8470e32c7",
#         "/providers/Microsoft.Authorization/policyDefinitions/fbb99e8e-e444-4da0-9ff1-75c92f5a85b2",
#         "/providers/Microsoft.Authorization/policyDefinitions/7f89b1eb-583c-429a-8828-af049802c1d9",
#         "/providers/Microsoft.Authorization/policyDefinitions/9f766f00-8d11-464e-80e1-4091d7874074",
#         "/providers/Microsoft.Authorization/policyDefinitions/a06d0189-92e8-4dba-b0c4-08d7669fce7d"
#         )
#     allPolicies = $allPolicies
#     allProviders = $allProviders
#     # addRecommendationsToExistingPolicy = $true
#     NotAllowedResourceTypes = @()
# }
# ServicePolicyInitiative @Arguments

# $Arguments = $baselineArguments + @{
#     initiativeName = "KeyvaultBaseline"
#     policyInitiativeFileName = "KeyvaultBaseline.json"
#     targetServiceName = "Key Vault"
#     targetResourceProviders = @("Microsoft.KeyVault")
#     otherKeywords = @("keyvault")
#     initiativeCategoriesOfInterest = @()
#     initiativeKeywordsToIncludeInRecommendations = @()
#     initiativeKeywordsToExcludeFromRecommendations = @("Managed HSM")
#     initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(
#         "/providers/Microsoft.Authorization/policyDefinitions/951af2fa-529b-416e-ab6e-066fd85ac459",
#         "/providers/Microsoft.Authorization/policyDefinitions/1f68a601-6e6d-4e42-babf-3f643a047ea2"
#     )
#     allPolicies = $allPolicies
#     allProviders = $allProviders
#     NotAllowedResourceTypes = @("Microsoft.KeyVault/managedHSMs")
# }
# ServicePolicyInitiative @Arguments

# $Arguments = $baselineArguments + @{
#     initiativeName = "ContainerInstanceBaseline"
#     policyInitiativeFileName = "ContainerBaseline.json"
#     targetServiceName = "Container Instance"
#     targetResourceProviders = @("Microsoft.ContainerInstance")
#     otherKeywords = @("ContainerInstance")
#     initiativeCategoriesOfInterest = @()
#     initiativeKeywordsToIncludeInRecommendations = @()
#     initiativeKeywordsToExcludeFromRecommendations = @()
#     initiativePolicyDefinitionIdsToExcludeFromRecommendations = @()
#     allPolicies = $allPolicies
#     allProviders = $allProviders
#     NotAllowedResourceTypes = @()
# }
# ServicePolicyInitiative @Arguments

# $Arguments = $baselineArguments + @{
#     initiativeName = "NetworkServicesBaseline"
#     policyInitiativeFileName = "NetworkServicesBaseline.json"
#     targetServiceName = "Network Services"
#     targetResourceProviders = @("Microsoft.Network")
#     otherKeywords = @()
#     initiativeCategoriesOfInterest = @("network")
#     initiativeKeywordsToIncludeInRecommendations = @()
#     initiativeKeywordsToExcludeFromRecommendations = @(
#         "microsoft.networkcloud"
#     )
#     initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(
#         "/providers/Microsoft.Authorization/policyDefinitions/98a2e215-5382-489e-bd29-32e7190a39ba",
#         "/providers/Microsoft.Authorization/policyDefinitions/a4490248-cb97-4504-b7fb-f906afdb7437",
#         "/providers/Microsoft.Authorization/policyDefinitions/aec63c84-f9ea-46c7-9e66-ba567bae0f09",
#         "/providers/Microsoft.Authorization/policyDefinitions/c9c29499-c1d1-4195-99bd-2ec9e3a9dc89"
#     )
#     allPolicies = $allPolicies
#     allProviders = $allProviders
#     NotAllowedResourceTypes = @()
# }
# ServicePolicyInitiative @Arguments

# $Arguments = $baselineArguments + @{
#     initiativeName = "ComputeBaseline"
#     policyInitiativeFileName = "ComputeBaseline.json"
#     targetServiceName = "Compute"
#     targetResourceProviders = @("Microsoft.Compute","Microsoft.VirtualMachineImages")
#     otherKeywords = @("Virtual Machine", "VM")
#     initiativeCategoriesOfInterest = @("Compute","VM Image Builder", "Azure Update Manager")
#     initiativeKeywordsToIncludeInRecommendations = @("update","updates","patch","Antimalware","patching")
#     initiativeKeywordsToExcludeFromRecommendations = @()
#     initiativePolicyDefinitionIdsToExcludeFromRecommendations = @(
#     )
#     allPolicies = $allPolicies
#     allProviders = $allProviders
#     NotAllowedResourceTypes = @()
# }
# ServicePolicyInitiative @Arguments




