Document PolicyReport {

    Title "Initiative: $($TargetObject.targetService)"

    Section "Included Policies" {
        "The following policy definitions are already included in the existing Policy Initiative [*$($TargetObject.existingPolicy)*]:"
        
        $TargetObject.policiesIncluded | Table -Property @{ Name = 'Security Principles'; Expression = { ($_.policyGroups -ne $null) ? $($_.policyGroups  -join ",") : "none" }; Alignment = 'Left';},@{ Name = 'Name'; Expression = { $_.properties.displayname }; Alignment = 'Left';Width = 20},@{ Name = 'Description'; Expression = { $_.properties.Description }; Alignment = 'Left'; Width = 20},@{ Name = 'Link'; Expression = { "[Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/$([System.Web.HttpUtility]::UrlEncode($_.PolicyDefinitionId)))"}; Alignment = 'Left';};
    
            Section "Security Principles Coverage" {
                Section "Included" {
                    "Coverage of the following Security Principles was detected in this initiative. These  principles may still require additional controls to ensure full coverage."
                    $TargetObject.policiesIncluded.policyGroups | Sort-Object -Unique | ForEach-Object {"- $_"}
                }

                Section "Not Included" {
                    "Coverage of the following Security Principles was not detected in this initiative. These  principles may not be applicable, or may be addressed by some other means. Additional action may be required to ensure coverage of these principles."
                    $included = $TargetObject.policiesIncluded.policyGroups | Sort-Object -Unique 
                    $TargetObject.policyGroups | Where-Object { $included -notcontains $_ } | Sort-Object -Unique | ForEach-Object {"- $_"}
                }
            }
        
    }

    Section "Recommended Policies" {
        "The following policy definitions are recommended for inclusion in the Policy Initiative. The recommendations are based on the following keyword searches [*$($TargetObject.keywordsToIncludeInRecommendations)*] in the following policy categories [*$($TargetObject.categoriesOfInterest)*]:"

        $TargetObject.policiesToRecommend | Table -Property @{ Name = 'Security Principles'; Expression = { $($_.policyGroups  -join ",")}; Alignment = 'Left';},@{ Name = 'Name'; Expression = { $_.properties.displayname }; Alignment = 'Left';},@{ Name = 'Description'; Expression = { $_.properties.Description }; Alignment = 'Left'; },@{ Name = 'Link'; Expression = { "[Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/$([System.Web.HttpUtility]::UrlEncode($_.PolicyDefinitionId)))"}; Alignment = 'Left';};
    }

    Section "Other Policies" {
        "The following policy definitions are most likely related to the target service, but are not included in the automated recommendations. These policy definitions can be added manually to the Policy Initiative [*$($TargetObject.existingPolicy)*] if required"
        
        $TargetObject.policiesToConsider | Table -Property @{ Name = 'Name'; Expression = { $_.properties.displayname }; Alignment = 'Left';},@{ Name = 'Description'; Expression = { $_.properties.Description }; Alignment = 'Left'; },@{ Name = 'Link'; Expression = { "[Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/$([System.Web.HttpUtility]::UrlEncode($_.PolicyDefinitionId)))"}; Alignment = 'Left';};
    }

    Section "Excluded Policies" {
        "The following policy definitions are excluded from the recommendations. The exclusions are based on the following keyword searches [*$($TargetObject.keywordsToExcludeFromRecommendations)*] and policy definitions [*$($TargetObject.policiesToExcludeFromRecommendations)*].These policy definitions can be added manually to the Policy Initiative [*$($TargetObject.existingPolicy)*] if required"
        
        $TargetObject.policiesToExclude | Table -Property @{ Name = 'Name'; Expression = { $_.properties.displayname }; Alignment = 'Left';},@{ Name = 'Description'; Expression = { $_.properties.Description }; Alignment = 'Left'; },@{ Name = 'Link'; Expression = { "[Link](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetail.ReactView/id/$([System.Web.HttpUtility]::UrlEncode($_.PolicyDefinitionId)))"}; Alignment = 'Left';};
    }

    Section "Resource Types" {

        Section "Allowed" {
            $TargetObject.matchingResourceTypes| Where-Object {$TargetObject.notAllowedResourceTypes -notcontains $_} | ForEach-Object {"- $_"}
        }
        
        Section "Not Allowed" {
            $TargetObject.notAllowedResourceTypes | ForEach-Object {"- $_"}
        }
    }
   
}